import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Product,
  Category,
  WebsiteSettings,
  Enquiry,
  CustomOrder,
  GalleryItem,
  Testimonial,
  SectionVisibility,
  WebsiteCustomization,
  NavItem,
  BannerItem,
  SEOSettings,
  HeroSettings,
  AboutSettings,
  WhyChooseUsCard
} from '../types/furniture';
import {
  INITIAL_PRODUCTS,
  INITIAL_CATEGORIES,
  INITIAL_SETTINGS,
  INITIAL_ENQUIRIES,
  INITIAL_CUSTOM_ORDERS,
  INITIAL_GALLERY,
  INITIAL_TESTIMONIALS
} from '../data/furnitureData';

interface AdminUser {
  email: string;
  name: string;
  role: 'super_admin' | 'manager';
}

interface DataContextType {
  // Products
  products: Product[];
  addProduct: (productData: Omit<Product, 'id' | 'createdAt' | 'updatedAt'>) => Product;
  updateProduct: (id: string, updates: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
  deleteProductsBulk: (ids: string[]) => void;
  setProductsStatusBulk: (ids: string[], status: 'active' | 'inactive') => void;
  setProductsFeaturedBulk: (ids: string[], featured: boolean) => void;
  getProductById: (id: string) => Product | undefined;

  // Categories
  categories: Category[];
  addCategory: (categoryData: Omit<Category, 'id' | 'createdAt'>) => Category;
  updateCategory: (id: string, updates: Partial<Category>) => void;
  deleteCategory: (id: string) => { success: boolean; message?: string; productCount?: number };
  getCategoryById: (id: string) => Category | undefined;
  getProductsInCategoryCount: (categoryId: string) => number;

  // Enquiries
  enquiries: Enquiry[];
  addEnquiry: (enquiry: Omit<Enquiry, 'id' | 'date' | 'status'>) => Enquiry;
  updateEnquiryStatus: (id: string, status: Enquiry['status']) => void;
  deleteEnquiry: (id: string) => void;

  // Custom Orders
  customOrders: CustomOrder[];
  addCustomOrder: (order: Omit<CustomOrder, 'id' | 'date' | 'status'>) => CustomOrder;
  updateCustomOrderStatus: (id: string, status: CustomOrder['status']) => void;
  deleteCustomOrder: (id: string) => void;

  // Gallery
  gallery: GalleryItem[];
  addGalleryItem: (item: Omit<GalleryItem, 'id'>) => GalleryItem;
  updateGalleryItem: (id: string, updates: Partial<GalleryItem>) => void;
  deleteGalleryItem: (id: string) => void;

  // Testimonials
  testimonials: Testimonial[];
  addTestimonial: (item: Omit<Testimonial, 'id'>) => Testimonial;
  updateTestimonial: (id: string, updates: Partial<Testimonial>) => void;
  deleteTestimonial: (id: string) => void;

  // Website Settings & Section Visibility
  settings: WebsiteSettings;
  updateSettings: (updates: Partial<WebsiteSettings>) => void;
  updateSectionVisibility: (sectionKey: keyof SectionVisibility, isVisible: boolean) => void;
  updateCustomization: (updates: Partial<WebsiteCustomization>) => void;
  updateSectionOrder: (newOrder: string[]) => void;
  updateNavigation: (items: NavItem[]) => void;
  updateBanners: (banners: BannerItem[]) => void;
  updateSEO: (updates: Partial<SEOSettings>) => void;
  updateHeroSettings: (updates: Partial<HeroSettings>) => void;
  updateAboutSettings: (updates: Partial<AboutSettings>) => void;
  updateWhyChooseUs: (cards: WhyChooseUsCard[]) => void;

  // Recent Content Activity
  recentUpdates: { id: string; title: string; category: string; timestamp: string }[];
  recordContentUpdate: (title: string, category: string) => void;

  // Admin Auth
  adminUser: AdminUser | null;
  isAdminAuthenticated: boolean;
  loginAdmin: (email: string, password: string) => { success: boolean; message?: string };
  logoutAdmin: () => void;

  // Utility
  resetToDefaultData: () => void;
}

const DataContext = createContext<DataContextType | null>(null);

const STORAGE_KEYS = {
  PRODUCTS: 'afurn_db_products',
  CATEGORIES: 'afurn_db_categories',
  SETTINGS: 'afurn_db_settings',
  ENQUIRIES: 'afurn_db_enquiries',
  CUSTOM_ORDERS: 'afurn_db_custom_orders',
  GALLERY: 'afurn_db_gallery',
  TESTIMONIALS: 'afurn_db_testimonials',
  ADMIN_SESSION: 'afurn_db_admin_session',
};

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Load Products
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.PRODUCTS);
      return stored ? JSON.parse(stored) : INITIAL_PRODUCTS;
    } catch {
      return INITIAL_PRODUCTS;
    }
  });

  // Load Categories
  const [categories, setCategories] = useState<Category[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.CATEGORIES);
      return stored ? JSON.parse(stored) : INITIAL_CATEGORIES;
    } catch {
      return INITIAL_CATEGORIES;
    }
  });

  // Load Settings
  const [settings, setSettings] = useState<WebsiteSettings>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.SETTINGS);
      return stored ? JSON.parse(stored) : INITIAL_SETTINGS;
    } catch {
      return INITIAL_SETTINGS;
    }
  });

  // Load Enquiries
  const [enquiries, setEnquiries] = useState<Enquiry[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.ENQUIRIES);
      return stored ? JSON.parse(stored) : INITIAL_ENQUIRIES;
    } catch {
      return INITIAL_ENQUIRIES;
    }
  });

  // Load Custom Orders
  const [customOrders, setCustomOrders] = useState<CustomOrder[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.CUSTOM_ORDERS);
      return stored ? JSON.parse(stored) : INITIAL_CUSTOM_ORDERS;
    } catch {
      return INITIAL_CUSTOM_ORDERS;
    }
  });

  // Load Gallery
  const [gallery, setGallery] = useState<GalleryItem[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.GALLERY);
      return stored ? JSON.parse(stored) : INITIAL_GALLERY;
    } catch {
      return INITIAL_GALLERY;
    }
  });

  // Load Testimonials
  const [testimonials, setTestimonials] = useState<Testimonial[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.TESTIMONIALS);
      return stored ? JSON.parse(stored) : INITIAL_TESTIMONIALS;
    } catch {
      return INITIAL_TESTIMONIALS;
    }
  });

  // Load Admin Session
  const [adminUser, setAdminUser] = useState<AdminUser | null>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.ADMIN_SESSION);
      return stored ? JSON.parse(stored) : null;
    } catch {
      return null;
    }
  });

  // Load Recent Updates Activity
  const [recentUpdates, setRecentUpdates] = useState<{ id: string; title: string; category: string; timestamp: string }[]>(() => {
    try {
      const stored = localStorage.getItem('afurn_recent_updates');
      return stored ? JSON.parse(stored) : [
        { id: '1', title: 'Luxury Living Room Hero Visual & Headlines', category: 'Homepage', timestamp: 'Today' },
        { id: '2', title: 'Teak & Sandstone Brand Color Palette', category: 'Customization', timestamp: 'Today' },
        { id: '3', title: 'Sagwan Teakwood 6-Seater Dining Set', category: 'Products', timestamp: 'Yesterday' },
        { id: '4', title: 'Showroom Navigation Menu Links', category: 'Navigation', timestamp: '2 days ago' },
      ];
    } catch {
      return [
        { id: '1', title: 'Luxury Living Room Hero Visual & Headlines', category: 'Homepage', timestamp: 'Today' },
        { id: '2', title: 'Teak & Sandstone Brand Color Palette', category: 'Customization', timestamp: 'Today' },
        { id: '3', title: 'Sagwan Teakwood 6-Seater Dining Set', category: 'Products', timestamp: 'Yesterday' },
        { id: '4', title: 'Showroom Navigation Menu Links', category: 'Navigation', timestamp: '2 days ago' },
      ];
    }
  });

  // Sync to localStorage whenever states change
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(categories));
  }, [categories]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ENQUIRIES, JSON.stringify(enquiries));
  }, [enquiries]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CUSTOM_ORDERS, JSON.stringify(customOrders));
  }, [customOrders]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.GALLERY, JSON.stringify(gallery));
  }, [gallery]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.TESTIMONIALS, JSON.stringify(testimonials));
  }, [testimonials]);

  useEffect(() => {
    if (adminUser) {
      localStorage.setItem(STORAGE_KEYS.ADMIN_SESSION, JSON.stringify(adminUser));
    } else {
      localStorage.removeItem(STORAGE_KEYS.ADMIN_SESSION);
    }
  }, [adminUser]);

  // Product Operations
  const addProduct = (productData: Omit<Product, 'id' | 'createdAt' | 'updatedAt'>): Product => {
    const slug = productData.slug || productData.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
    const newProduct: Product = {
      ...productData,
      id: `afurn-prod-${Date.now()}`,
      slug,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    setProducts((prev) => [newProduct, ...prev]);
    return newProduct;
  };

  const updateProduct = (id: string, updates: Partial<Product>) => {
    setProducts((prev) =>
      prev.map((p) => {
        if (p.id === id) {
          const updated = {
            ...p,
            ...updates,
            updatedAt: new Date().toISOString(),
          };
          if (updates.name && !updates.slug) {
            updated.slug = updates.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
          }
          return updated;
        }
        return p;
      })
    );
  };

  const deleteProduct = (id: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== id));
  };

  const deleteProductsBulk = (ids: string[]) => {
    setProducts((prev) => prev.filter((p) => !ids.includes(p.id)));
  };

  const setProductsStatusBulk = (ids: string[], status: 'active' | 'inactive') => {
    setProducts((prev) =>
      prev.map((p) => (ids.includes(p.id) ? { ...p, status, updatedAt: new Date().toISOString() } : p))
    );
  };

  const setProductsFeaturedBulk = (ids: string[], featured: boolean) => {
    setProducts((prev) =>
      prev.map((p) => (ids.includes(p.id) ? { ...p, featured, updatedAt: new Date().toISOString() } : p))
    );
  };

  const getProductById = (id: string) => {
    return products.find((p) => p.id === id);
  };

  // Category Operations
  const addCategory = (categoryData: Omit<Category, 'id' | 'createdAt'>): Category => {
    const slug = categoryData.slug || categoryData.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
    const newCat: Category = {
      ...categoryData,
      id: slug || `cat-${Date.now()}`,
      slug,
      createdAt: new Date().toISOString(),
    };
    setCategories((prev) => [...prev, newCat]);
    return newCat;
  };

  const updateCategory = (id: string, updates: Partial<Category>) => {
    setCategories((prev) =>
      prev.map((cat) => {
        if (cat.id === id) {
          return { ...cat, ...updates };
        }
        return cat;
      })
    );
  };

  const getProductsInCategoryCount = (categoryId: string): number => {
    return products.filter((p) => p.categoryId === categoryId).length;
  };

  const deleteCategory = (id: string): { success: boolean; message?: string; productCount?: number } => {
    const matchingCount = getProductsInCategoryCount(id);
    if (matchingCount > 0) {
      return {
        success: false,
        message: `This category contains ${matchingCount} product${matchingCount === 1 ? '' : 's'}. Please move these products to another category before deleting.`,
        productCount: matchingCount,
      };
    }
    setCategories((prev) => prev.filter((cat) => cat.id !== id));
    return { success: true };
  };

  const getCategoryById = (id: string) => {
    return categories.find((cat) => cat.id === id);
  };

  // Enquiries Operations
  const addEnquiry = (enquiryData: Omit<Enquiry, 'id' | 'date' | 'status'>): Enquiry => {
    const newEnquiry: Enquiry = {
      ...enquiryData,
      id: `enq-${Date.now()}`,
      date: new Date().toISOString(),
      status: 'NEW',
    };
    setEnquiries((prev) => [newEnquiry, ...prev]);
    return newEnquiry;
  };

  const updateEnquiryStatus = (id: string, status: Enquiry['status']) => {
    setEnquiries((prev) =>
      prev.map((e) => (e.id === id ? { ...e, status } : e))
    );
  };

  const deleteEnquiry = (id: string) => {
    setEnquiries((prev) => prev.filter((e) => e.id !== id));
  };

  // Custom Orders Operations
  const addCustomOrder = (orderData: Omit<CustomOrder, 'id' | 'date' | 'status'>): CustomOrder => {
    const newOrder: CustomOrder = {
      ...orderData,
      id: `co-${Date.now()}`,
      date: new Date().toISOString(),
      status: 'NEW',
    };
    setCustomOrders((prev) => [newOrder, ...prev]);
    return newOrder;
  };

  const updateCustomOrderStatus = (id: string, status: CustomOrder['status']) => {
    setCustomOrders((prev) =>
      prev.map((o) => (o.id === id ? { ...o, status } : o))
    );
  };

  const deleteCustomOrder = (id: string) => {
    setCustomOrders((prev) => prev.filter((o) => o.id !== id));
  };

  // Gallery Operations
  const addGalleryItem = (itemData: Omit<GalleryItem, 'id'>): GalleryItem => {
    const newItem: GalleryItem = {
      ...itemData,
      id: `gal-${Date.now()}`,
    };
    setGallery((prev) => [newItem, ...prev]);
    return newItem;
  };

  const updateGalleryItem = (id: string, updates: Partial<GalleryItem>) => {
    setGallery((prev) =>
      prev.map((g) => (g.id === id ? { ...g, ...updates } : g))
    );
  };

  const deleteGalleryItem = (id: string) => {
    setGallery((prev) => prev.filter((g) => g.id !== id));
  };

  // Testimonial Operations
  const addTestimonial = (itemData: Omit<Testimonial, 'id'>): Testimonial => {
    const newItem: Testimonial = {
      ...itemData,
      id: `test-${Date.now()}`,
    };
    setTestimonials((prev) => [...prev, newItem]);
    return newItem;
  };

  const updateTestimonial = (id: string, updates: Partial<Testimonial>) => {
    setTestimonials((prev) =>
      prev.map((t) => (t.id === id ? { ...t, ...updates } : t))
    );
  };

  const deleteTestimonial = (id: string) => {
    setTestimonials((prev) => prev.filter((t) => t.id !== id));
  };

  // Settings Operations
  const updateSettings = (updates: Partial<WebsiteSettings>) => {
    setSettings((prev) => ({
      ...prev,
      ...updates,
      sections: updates.sections ? { ...prev.sections, ...updates.sections } : prev.sections,
    }));
  };

  const updateSectionVisibility = (sectionKey: keyof SectionVisibility, isVisible: boolean) => {
    setSettings((prev) => ({
      ...prev,
      sections: {
        ...prev.sections,
        [sectionKey]: isVisible,
      },
    }));
  };

  const updateCustomization = (updates: Partial<WebsiteCustomization>) => {
    setSettings((prev) => ({
      ...prev,
      customization: {
        ...prev.customization,
        ...updates,
      },
    }));
    recordContentUpdate('Website Colors & Typography', 'Customization');
  };

  const updateSectionOrder = (newOrder: string[]) => {
    setSettings((prev) => ({
      ...prev,
      sectionOrder: newOrder,
    }));
    recordContentUpdate('Homepage Section Arrangement', 'Homepage');
  };

  const updateNavigation = (items: NavItem[]) => {
    setSettings((prev) => ({
      ...prev,
      navigation: items,
    }));
    recordContentUpdate('Storefront Navigation Menu', 'Navigation');
  };

  const updateBanners = (banners: BannerItem[]) => {
    setSettings((prev) => ({
      ...prev,
      banners: banners,
    }));
    recordContentUpdate('Promotional Banners & Announcements', 'Banners');
  };

  const updateSEO = (updates: Partial<SEOSettings>) => {
    setSettings((prev) => ({
      ...prev,
      seo: {
        ...prev.seo,
        ...updates,
      },
    }));
    recordContentUpdate('SEO Meta Tags & Social Share Cards', 'SEO');
  };

  const updateHeroSettings = (updates: Partial<HeroSettings>) => {
    setSettings((prev) => ({
      ...prev,
      hero: {
        ...prev.hero,
        ...updates,
      },
    }));
    recordContentUpdate('Hero Showcase Headlines & Image', 'Homepage');
  };

  const updateAboutSettings = (updates: Partial<AboutSettings>) => {
    setSettings((prev) => ({
      ...prev,
      about: {
        ...prev.about,
        ...updates,
      },
    }));
    recordContentUpdate('About AFURN & 15+ Years Story', 'Homepage');
  };

  const updateWhyChooseUs = (cards: WhyChooseUsCard[]) => {
    setSettings((prev) => ({
      ...prev,
      whyChooseUsCards: cards,
    }));
    recordContentUpdate('Why Choose Us Value Propositions', 'Homepage');
  };

  const recordContentUpdate = (title: string, category: string) => {
    const item = {
      id: Date.now().toString(),
      title,
      category,
      timestamp: 'Just now',
    };
    setRecentUpdates((prev) => {
      const next = [item, ...prev.slice(0, 7)];
      try {
        localStorage.setItem('afurn_recent_updates', JSON.stringify(next));
      } catch {}
      return next;
    });
  };

  // Admin Authentication
  const loginAdmin = (email: string, pass: string): { success: boolean; message?: string } => {
    const cleanEmail = email.trim().toLowerCase();
    // Default admin credentials: admin@afurn.com / admin123
    // Or user email craftsofa277@gmail.com / admin123
    if (
      (cleanEmail === 'admin@afurn.com' && pass === 'admin123') ||
      (cleanEmail === 'craftsofa277@gmail.com' && pass === 'admin123') ||
      (cleanEmail === 'admin' && pass === 'admin123')
    ) {
      const user: AdminUser = {
        email: cleanEmail,
        name: cleanEmail === 'craftsofa277@gmail.com' ? 'AFURN Store Master' : 'AFURN Administrator',
        role: 'super_admin',
      };
      setAdminUser(user);
      return { success: true };
    }
    return { success: false, message: 'Invalid email or password. Please use admin@afurn.com and admin123' };
  };

  const logoutAdmin = () => {
    setAdminUser(null);
    localStorage.removeItem(STORAGE_KEYS.ADMIN_SESSION);
  };

  // Reset to initial sample state if needed
  const resetToDefaultData = () => {
    setProducts(INITIAL_PRODUCTS);
    setCategories(INITIAL_CATEGORIES);
    setSettings(INITIAL_SETTINGS);
    setEnquiries(INITIAL_ENQUIRIES);
    setCustomOrders(INITIAL_CUSTOM_ORDERS);
    setGallery(INITIAL_GALLERY);
    setTestimonials(INITIAL_TESTIMONIALS);
    localStorage.removeItem(STORAGE_KEYS.PRODUCTS);
    localStorage.removeItem(STORAGE_KEYS.CATEGORIES);
    localStorage.removeItem(STORAGE_KEYS.SETTINGS);
    localStorage.removeItem(STORAGE_KEYS.ENQUIRIES);
    localStorage.removeItem(STORAGE_KEYS.CUSTOM_ORDERS);
    localStorage.removeItem(STORAGE_KEYS.GALLERY);
    localStorage.removeItem(STORAGE_KEYS.TESTIMONIALS);
  };

  return (
    <DataContext.Provider
      value={{
        products,
        addProduct,
        updateProduct,
        deleteProduct,
        deleteProductsBulk,
        setProductsStatusBulk,
        setProductsFeaturedBulk,
        getProductById,

        categories,
        addCategory,
        updateCategory,
        deleteCategory,
        getCategoryById,
        getProductsInCategoryCount,

        enquiries,
        addEnquiry,
        updateEnquiryStatus,
        deleteEnquiry,

        customOrders,
        addCustomOrder,
        updateCustomOrderStatus,
        deleteCustomOrder,

        gallery,
        addGalleryItem,
        updateGalleryItem,
        deleteGalleryItem,

        testimonials,
        addTestimonial,
        updateTestimonial,
        deleteTestimonial,

        settings,
        updateSettings,
        updateSectionVisibility,
        updateCustomization,
        updateSectionOrder,
        updateNavigation,
        updateBanners,
        updateSEO,
        updateHeroSettings,
        updateAboutSettings,
        updateWhyChooseUs,
        recentUpdates,
        recordContentUpdate,

        adminUser,
        isAdminAuthenticated: !!adminUser,
        loginAdmin,
        logoutAdmin,

        resetToDefaultData,
      }}
    >
      {children}
    </DataContext.Provider>
  );
};

export const useData = () => {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};
