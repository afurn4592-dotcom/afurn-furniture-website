import { useState, FormEvent, ChangeEvent } from 'react';
import { Send, CheckCircle2, MessageCircle, Ruler, Hammer, Sparkles, Building2, Upload, X } from 'lucide-react';
import { useData } from '../context/DataContext';
import { CustomFurnitureForm } from '../types/furniture';
import { optimizeImageFile } from '../utils/imageUpload';

export default function CustomFurnitureStudio() {
  const { settings, addCustomOrder } = useData();

  if (settings.sections && settings.sections.customFurniture === false) {
    return null;
  }

  const [formData, setFormData] = useState<CustomFurnitureForm>({
    furnitureType: 'Sofa / Sectional',
    roomType: 'Living Room',
    dimensions: '',
    materialPreference: 'Solid Sagwan Teak Wood',
    frameType: 'Solid Teak Frame',
    upholsteryType: 'Premium Textured Linen / Bouclé',
    budgetRange: '₹30,000 - ₹60,000',
    customerName: '',
    customerPhone: '',
    customerEmail: '',
    city: 'Ahmedabad',
    projectType: 'Homeowner',
    notes: '',
    referenceImage: '',
  });

  const [submitted, setSubmitted] = useState(false);
  const [uploadingImage, setUploadingImage] = useState(false);

  const handleImageUpload = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setUploadingImage(true);
      const optimized = await optimizeImageFile(file, 1200, 1200, 0.8);
      setFormData((prev) => ({ ...prev, referenceImage: optimized }));
    } catch (err) {
      console.error(err);
    } finally {
      setUploadingImage(false);
    }
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setSubmitted(true);

    // Save to unified persistent database
    addCustomOrder({
      customerName: formData.customerName,
      phone: formData.customerPhone,
      email: formData.customerEmail,
      furnitureType: formData.furnitureType,
      size: formData.dimensions || 'Standard room dimensions',
      material: formData.materialPreference,
      color: formData.upholsteryType,
      quantity: 1,
      budgetRange: formData.budgetRange,
      city: formData.city,
      projectType: formData.projectType,
      referenceImage: formData.referenceImage,
      message: `${formData.roomType} | ${formData.notes || 'Looking for custom quote & samples'}`,
    });

    // Format WhatsApp message
    const message = encodeURIComponent(
      `*CUSTOM FURNITURE INQUIRY - ${settings.businessName || 'AFURN'}*\n` +
      `---------------------------------\n` +
      `*Client:* ${formData.customerName}\n` +
      `*Phone:* ${formData.customerPhone}\n` +
      `*Role:* ${formData.projectType}\n` +
      `*City:* ${formData.city}\n` +
      `*Furniture:* ${formData.furnitureType} (${formData.roomType})\n` +
      `*Dimensions:* ${formData.dimensions || 'Standard or as per discussion'}\n` +
      `*Material:* ${formData.materialPreference}\n` +
      `*Frame:* ${formData.frameType}\n` +
      `*Upholstery:* ${formData.upholsteryType}\n` +
      `*Budget:* ${formData.budgetRange}\n` +
      `*Notes:* ${formData.notes || 'Looking for custom quote & catalog'}\n` +
      `---------------------------------\n` +
      `Please provide an estimate and timber/fabric samples for Ahmedabad delivery.`
    );

    // Open WhatsApp in new tab
    window.open(`https://wa.me/91${settings.phone}?text=${message}`, '_blank');
  };

  return (
    <section id="custom" className="py-16 sm:py-24 bg-[#F7F3EE] border-t border-[#E3CAAB]/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <p className="text-[11px] tracking-[0.25em] font-semibold text-[#B08A62] uppercase mb-2">
            BESPOKE ARCHITECTURAL MANUFACTURING
          </p>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-medium text-[#292522] tracking-tight">
            Custom Furniture Studio
          </h2>
          <p className="mt-3 text-sm sm:text-base text-[#473C38]/80 leading-relaxed font-normal">
            Whether you are a homeowner furnishing a villa or an architect with exacting blueprints, {settings.businessName || 'AFURN'} manufactures one-of-a-kind furniture to your exact specifications.
          </p>
        </div>

        {/* 3 Pillars of AFURN Custom Craftsmanship */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <div className="bg-white p-6 border border-[#E3CAAB]/60">
            <Ruler className="w-6 h-6 text-[#B08A62] mb-3" />
            <h3 className="font-serif text-lg font-medium text-[#292522]">
              Millimeter-Precise Sizing
            </h3>
            <p className="text-xs text-[#473C38]/75 mt-2 leading-relaxed">
              Every room has unique dimensions. We adjust sofa lengths, dining heights, and swing widths to fit your architectural alcoves seamlessly.
            </p>
          </div>

          <div className="bg-white p-6 border border-[#E3CAAB]/60">
            <Hammer className="w-6 h-6 text-[#B08A62] mb-3" />
            <h3 className="font-serif text-lg font-medium text-[#292522]">
              Direct Factory Wood & Metal
            </h3>
            <p className="text-xs text-[#473C38]/75 mt-2 leading-relaxed">
              Hand-selected seasoned Sagwan (Teak), Sheesham, natural cane, and precision laser-cut steel with electrostatic powder coating.
            </p>
          </div>

          <div className="bg-white p-6 border border-[#E3CAAB]/60">
            <Sparkles className="w-6 h-6 text-[#B08A62] mb-3" />
            <h3 className="font-serif text-lg font-medium text-[#292522]">
              Architect & B2B Collaboration
            </h3>
            <p className="text-xs text-[#473C38]/75 mt-2 leading-relaxed">
              We work directly from CAD drawings, 3D renders, and mood boards for restaurants, cafes, luxury villas, and corporate offices.
            </p>
          </div>
        </div>

        {/* Interactive Custom Order Form */}
        <div className="bg-white border border-[#E3CAAB] shadow-sm p-6 sm:p-10">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center justify-between pb-6 mb-8 border-b border-[#E3CAAB]/50">
              <div>
                <h4 className="text-xl sm:text-2xl font-serif font-medium text-[#473C38]">
                  Build Your Custom Order Request
                </h4>
                <p className="text-xs text-[#473C38]/70 mt-1">
                  Fill in your requirements below. Our workshop master will review and provide a direct manufacturer quote on WhatsApp within hours.
                </p>
              </div>
              <div className="hidden sm:flex items-center gap-1.5 text-xs font-semibold text-[#B08A62] uppercase tracking-wider">
                <Building2 className="w-4 h-4" />
                <span>Danilimda Factory</span>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              
              {/* Row 1: Who are you & Furniture Category */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-2">
                    I am a:
                  </label>
                  <select
                    value={formData.projectType}
                    onChange={(e) => setFormData({ ...formData, projectType: e.target.value as any })}
                    className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/60 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38] cursor-pointer"
                  >
                    <option value="Homeowner">Homeowner</option>
                    <option value="Interior Designer">Interior Designer</option>
                    <option value="Architect">Architect</option>
                    <option value="Commercial / Cafe / Hotel">Commercial / Cafe / Hotel Owner</option>
                    <option value="Other">Corporate Office / Retail Client</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-2">
                    Furniture Type:
                  </label>
                  <select
                    value={formData.furnitureType}
                    onChange={(e) => setFormData({ ...formData, furnitureType: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/60 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38] cursor-pointer"
                  >
                    <option value="Sofa / Curved Sectional">Sofa / Curved Sectional</option>
                    <option value="Dining Table & Chairs Set">Dining Table & Chairs Set</option>
                    <option value="Lounge / Accent Chair">Lounge / Accent Chair</option>
                    <option value="Centre & Coffee Table">Centre & Coffee Table</option>
                    <option value="Wooden Swing (Jhula)">Handcrafted Wooden Swing (Jhula)</option>
                    <option value="Executive Study Desk / Table">Executive Study Desk / Table</option>
                    <option value="Bar Stools & Cafe Seating">Bar Stools & Cafe Seating</option>
                    <option value="Bespoke Metal Furniture">Bespoke Metal & Wood Furniture</option>
                    <option value="Complete Home / Project Package">Complete Home / Project Package</option>
                  </select>
                </div>
              </div>

              {/* Row 2: Dimensions & Materials */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-2">
                    Preferred Dimensions or Room Space:
                  </label>
                  <input
                    type="text"
                    value={formData.dimensions}
                    onChange={(e) => setFormData({ ...formData, dimensions: e.target.value })}
                    placeholder="e.g. 7ft x 3ft dining table or 8ft L-Shape sofa"
                    className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/60 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-2">
                    Wood / Metal Preference:
                  </label>
                  <select
                    value={formData.materialPreference}
                    onChange={(e) => setFormData({ ...formData, materialPreference: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/60 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38] cursor-pointer"
                  >
                    <option value="Solid Sagwan Teak Wood">Solid Sagwan (CP Teak Wood)</option>
                    <option value="Sheesham (Indian Rosewood)">Solid Sheesham Wood</option>
                    <option value="Heavy Gauge Mild Steel + Teak">Heavy Gauge Mild Steel + Teak Top</option>
                    <option value="Natural Cane Webbing + Teak">Natural Cane Webbing + Teak</option>
                    <option value="Marble / Travertine + Wood Base">Marble / Travertine + Wood Base</option>
                    <option value="Not Sure - Need Recommendation">Not Sure - Need Recommendation</option>
                  </select>
                </div>
              </div>

              {/* Row 3: Upholstery & Budget Range */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-2">
                    Upholstery / Finish:
                  </label>
                  <select
                    value={formData.upholsteryType}
                    onChange={(e) => setFormData({ ...formData, upholsteryType: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/60 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38] cursor-pointer"
                  >
                    <option value="Premium Textured Linen / Bouclé">Premium Textured Linen / Bouclé</option>
                    <option value="Breathable Leatherette / Suede">Breathable Leatherette / Suede</option>
                    <option value="Natural Matte Polyurethane Seal">Natural Matte Polyurethane Seal (Raw Wood)</option>
                    <option value="High Gloss / Walnut Dark Stain">High Gloss / Walnut Dark Stain</option>
                    <option value="Commercial Stain-Resistant Fabric">Commercial Stain-Resistant Fabric</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-2">
                    Estimated Budget:
                  </label>
                  <select
                    value={formData.budgetRange}
                    onChange={(e) => setFormData({ ...formData, budgetRange: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/60 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38] cursor-pointer"
                  >
                    <option value="Under ₹25,000">Under ₹25,000</option>
                    <option value="₹25,000 - ₹50,000">₹25,000 - ₹50,000</option>
                    <option value="₹50,000 - ₹1,00,000">₹50,000 - ₹1,00,000</option>
                    <option value="₹1,00,000 - ₹2,50,000">₹1,00,000 - ₹2,50,000 (Multi-Room / Set)</option>
                    <option value="₹2,50,000+">₹2,50,000+ (Full Home / Commercial Bulk)</option>
                  </select>
                </div>
              </div>

              {/* Row 4: Customer Details */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-2">
                    Your Name: *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.customerName}
                    onChange={(e) => setFormData({ ...formData, customerName: e.target.value })}
                    placeholder="Enter your name"
                    className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/60 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-2">
                    WhatsApp / Phone: *
                  </label>
                  <input
                    type="tel"
                    required
                    value={formData.customerPhone}
                    onChange={(e) => setFormData({ ...formData, customerPhone: e.target.value })}
                    placeholder="e.g. 7069469407"
                    className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/60 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-2">
                    City / Area in Ahmedabad:
                  </label>
                  <input
                    type="text"
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    placeholder="e.g. Satellite, Ahmedabad"
                    className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/60 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
                  />
                </div>
              </div>

              {/* Reference Image Attachment */}
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-2">
                  Attach Reference Image or Sketch (Optional):
                </label>
                <div className="flex items-center gap-3">
                  {formData.referenceImage && (
                    <div className="relative">
                      <img
                        src={formData.referenceImage}
                        alt="Reference"
                        className="w-16 h-16 object-cover border border-[#E3CAAB]"
                      />
                      <button
                        type="button"
                        onClick={() => setFormData({ ...formData, referenceImage: '' })}
                        className="absolute -top-1.5 -right-1.5 p-0.5 bg-red-600 text-white rounded-full"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  )}
                  <label className="flex-1 border border-dashed border-[#E3CAAB] hover:border-[#B08A62] p-3 text-center cursor-pointer bg-[#F7F3EE]/40 flex items-center justify-center gap-2">
                    <Upload className="w-4 h-4 text-[#B08A62]" />
                    <span className="text-xs font-medium text-[#473C38]">
                      {formData.referenceImage ? 'Replace Photo' : 'Upload photo / floorplan image'}
                    </span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="hidden"
                    />
                  </label>
                </div>
                {uploadingImage && (
                  <p className="text-[10px] text-[#B08A62] mt-1">Preparing image...</p>
                )}
              </div>

              {/* Row 5: Notes & CAD / Sketch mention */}
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-2">
                  Project Notes / Reference Links / Special Requests:
                </label>
                <textarea
                  rows={3}
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  placeholder="Describe your design, cushion firmness, brass finishes, or mention if you have CAD drawings to send via WhatsApp..."
                  className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/60 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
                />
              </div>

              {/* Submit CTA */}
              <div className="pt-4 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="text-xs text-[#473C38]/70">
                  <span className="font-semibold text-[#473C38]">Direct Contact:</span> Instant review by our master craftsmen at {settings.address || '309, Sahkar Estate, Danilimda'}.
                </div>

                <button
                  type="submit"
                  className="w-full sm:w-auto px-8 py-3.5 bg-[#473C38] text-white hover:bg-[#B08A62] text-xs font-semibold tracking-wider flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>GET INSTANT WHATSAPP QUOTE</span>
                </button>
              </div>

            </form>

            {submitted && (
              <div className="mt-6 p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-3">
                <CheckCircle2 className="w-5 h-5 shrink-0 text-emerald-600" />
                <span>
                  Thank you! Your custom inquiry has been recorded and WhatsApp is opening now directly to {settings.businessName || 'AFURN'} (+91 {settings.phone}).
                </span>
              </div>
            )}

          </div>
        </div>

      </div>
    </section>
  );
}
