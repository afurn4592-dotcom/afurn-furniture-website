import { Check, Shield, MapPin } from 'lucide-react';
import { IMAGES } from '../data/furnitureData';
import { useData } from '../context/DataContext';

export default function AboutSection() {
  const { settings } = useData();

  if (settings.sections && settings.sections.aboutSection === false) {
    return null;
  }

  const highlights = [
    {
      label: `${settings.experience || '15+ Years'} Mastery`,
      detail: `Over a decade and a half of dedicated furniture manufacturing in ${settings.city || 'Ahmedabad'}.`
    },
    {
      label: 'Direct Manufacturer',
      detail: 'Zero retail middlemen markups. You get genuine workshop pricing.'
    },
    {
      label: 'Seasoned Wood & Solid Steel',
      detail: 'Kiln-dried Sagwan (Teak), Sheesham, and industrial heavy-gauge metal frames.'
    },
    {
      label: 'Professional Hand-Finishing',
      detail: 'Multi-stage sanding, polyurethane seals, and master carpenter joinery.'
    }
  ];

  return (
    <section id="about" className="py-16 sm:py-24 bg-[#F7F3EE] border-t border-[#E3CAAB]/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column: Workshop Image Grid with Showroom Aesthetic */}
          <div className="lg:col-span-6 relative">
            <div className="relative aspect-[4/3] bg-[#E3CAAB]/20 overflow-hidden shadow-xl border border-[#E3CAAB]">
              <img
                src={IMAGES.dining}
                alt="AFURN Woodworking & Metal Craftsmanship Workshop"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover object-center"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#473C38]/40 via-transparent to-transparent pointer-events-none" />
            </div>

            {/* Experience Floating Callout */}
            <div className="absolute -bottom-6 -right-4 sm:bottom-6 sm:right-6 bg-[#473C38] text-white p-5 sm:p-6 shadow-2xl max-w-xs border border-[#B08A62]">
              <p className="text-3xl sm:text-4xl font-serif font-bold text-[#E3CAAB]">15+</p>
              <p className="text-xs uppercase tracking-[0.16em] font-semibold text-white/90 mt-1">
                {settings.experience || 'Years of Master Craftsmanship'}
              </p>
              <p className="text-[11px] text-white/70 mt-1">
                {settings.city || 'Danilimda Workshop, Ahmedabad'}
              </p>
            </div>
          </div>

          {/* Right Column: Story & Quality Commitment */}
          <div className="lg:col-span-6 flex flex-col justify-center">
            <span className="text-[11px] tracking-[0.25em] font-semibold text-[#B08A62] uppercase">
              {settings.aboutUsTitle || 'ABOUT AFURN'}
            </span>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-medium text-[#292522] tracking-tight mt-1">
              {settings.aboutUsHeading || 'Rooted in Ahmedabad, Built for Generations'}
            </h2>

            <p className="mt-5 text-sm sm:text-base text-[#473C38]/85 leading-relaxed font-normal">
              {settings.aboutUsText1 || `Founded on the bedrock of authentic Indian craftsmanship, ${settings.businessName || 'AFURN'} has spent over 15 years shaping living rooms, dining spaces, and architectural interiors across Gujarat.`}
            </p>

            <p className="mt-3 text-xs sm:text-sm text-[#473C38]/75 leading-relaxed font-normal">
              {settings.aboutUsText2 || `Unlike generic retail showrooms that sell imported composite boards, our factory at Danilimda, Ahmedabad works exclusively with seasoned natural wood and structural heavy-gauge steel. From heritage Gujarat swings (Jhulas) with solid brass chains to sculptural Italian-inspired curved sectionals, every piece is built to endure decades of real family life.`}
            </p>

            {/* 4 Feature Badges */}
            <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 gap-4">
              {highlights.map((item) => (
                <div key={item.label} className="p-3.5 bg-white border border-[#E3CAAB]/60">
                  <div className="flex items-center gap-2 text-xs font-semibold text-[#473C38]">
                    <Check className="w-4 h-4 text-[#B08A62] shrink-0" />
                    <span>{item.label}</span>
                  </div>
                  <p className="text-[11px] text-[#473C38]/70 mt-1 pl-6">
                    {item.detail}
                  </p>
                </div>
              ))}
            </div>

            {/* Location & Contact reassurance */}
            <div className="mt-8 pt-6 border-t border-[#E3CAAB]/50 flex flex-wrap items-center gap-6 text-xs text-[#473C38]/80">
              <div className="flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-[#B08A62]" />
                <span>{settings.address || '309 Sahkar Estate, Danilimda, Ahmedabad'}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Shield className="w-4 h-4 text-[#B08A62]" />
                <span>Direct Factory Warranty</span>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
