import { MessageCircle, Phone, MapPin, Mail, ArrowUp, Lock } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useData } from '../context/DataContext';

interface FooterProps {
  onSelectCategory?: (catId: string) => void;
}

export default function Footer({ onSelectCategory }: FooterProps) {
  const { categories, settings } = useData();

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const activeCategories = categories
    .filter((c) => c.status === 'active')
    .sort((a, b) => (a.displayOrder || 0) - (b.displayOrder || 0));

  return (
    <footer className="bg-[#473C38] text-[#F7F3EE] pt-16 pb-12 border-t border-[#B08A62]/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 lg:gap-8 pb-12 border-b border-[#E3CAAB]/20">
          
          {/* Brand & Philosophy (Col 1-4) */}
          <div className="lg:col-span-4 space-y-4">
            <span className="text-3xl font-serif tracking-[0.2em] font-semibold text-[#FFFFFF] block">
              {settings.businessName || 'AFURN'}
            </span>
            <p className="text-xs text-[#E3CAAB]/90 tracking-[0.16em] uppercase font-semibold">
              {settings.city || 'Ahmedabad'} • {settings.experience || '15+ Years Direct Manufacturing'}
            </p>
            <p className="text-xs sm:text-sm text-[#F7F3EE]/80 leading-relaxed font-light">
              {settings.businessDescription || 'Crafting solid teakwood sofas, dining suites, architectural tables, and traditional Gujarat swings with uncompromised structural integrity and timeless design.'}
            </p>
            <div className="pt-2 flex items-center gap-3">
              <a
                href={settings.whatsappUrl || `https://wa.me/91${settings.phone}`}
                target="_blank"
                rel="noreferrer"
                className="px-4 py-2 bg-[#B08A62] text-white hover:bg-[#E3CAAB] hover:text-[#473C38] text-xs font-semibold tracking-wider flex items-center gap-1.5 transition-colors"
              >
                <MessageCircle className="w-3.5 h-3.5 fill-current" />
                <span>CHAT ON WHATSAPP</span>
              </a>
              <a
                href={`tel:${settings.phone}`}
                className="px-4 py-2 border border-[#E3CAAB]/50 text-[#F7F3EE] hover:bg-white hover:text-[#473C38] text-xs font-semibold tracking-wider flex items-center gap-1.5 transition-colors"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>CALL DIRECT</span>
              </a>
            </div>
          </div>

          {/* Categories (Col 5-7) */}
          <div className="lg:col-span-3 space-y-3">
            <p className="text-xs tracking-[0.2em] font-semibold uppercase text-[#E3CAAB]">
              COLLECTIONS
            </p>
            <ul className="space-y-2 text-xs text-[#F7F3EE]/80 font-light">
              {activeCategories.slice(0, 8).map((cat) => (
                <li key={cat.id}>
                  <button
                    onClick={() => {
                      onSelectCategory?.(cat.id);
                      document.getElementById('shop')?.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className="hover:text-[#E3CAAB] transition-colors cursor-pointer text-left uppercase"
                  >
                    {cat.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Quick Links & Services (Col 8-9) */}
          <div className="lg:col-span-2 space-y-3">
            <p className="text-xs tracking-[0.2em] font-semibold uppercase text-[#E3CAAB]">
              NAVIGATION
            </p>
            <ul className="space-y-2 text-xs text-[#F7F3EE]/80 font-light">
              <li>
                <a href="#home" className="hover:text-[#E3CAAB] transition-colors">Home</a>
              </li>
              <li>
                <a href="#shop" className="hover:text-[#E3CAAB] transition-colors">Shop Catalog</a>
              </li>
              <li>
                <a href="#categories" className="hover:text-[#E3CAAB] transition-colors">Categories</a>
              </li>
              <li>
                <a href="#custom" className="hover:text-[#E3CAAB] transition-colors">Custom Furniture</a>
              </li>
              <li>
                <a href="#about" className="hover:text-[#E3CAAB] transition-colors">About Us</a>
              </li>
              <li>
                <a href="#gallery" className="hover:text-[#E3CAAB] transition-colors">Gallery</a>
              </li>
              <li>
                <a href="#contact" className="hover:text-[#E3CAAB] transition-colors">Contact Workshop</a>
              </li>
              <li className="pt-2 border-t border-[#E3CAAB]/20">
                <Link
                  to="/admin/login"
                  className="text-[#E3CAAB] hover:text-white font-semibold flex items-center gap-1.5 transition-colors"
                >
                  <Lock className="w-3.5 h-3.5 text-[#B08A62]" />
                  <span>ADMIN LOGIN</span>
                </Link>
              </li>
            </ul>
          </div>

          {/* Factory Location & Direct Contact (Col 10-12) */}
          <div className="lg:col-span-3 space-y-3">
            <p className="text-xs tracking-[0.2em] font-semibold uppercase text-[#E3CAAB]">
              FACTORY & SHOWROOM
            </p>
            <div className="space-y-2.5 text-xs text-[#F7F3EE]/80 font-light">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-[#E3CAAB] shrink-0 mt-0.5" />
                <span>
                  {settings.address || '309, Sahkar Estate, Opp. Chandola Petrol Pump, Chandola Lake, Danilimda, Ahmedabad - 380028, Gujarat, India'}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-[#E3CAAB] shrink-0" />
                <a href={`tel:${settings.phone}`} className="hover:text-[#E3CAAB]">
                  +91 {settings.phone}
                </a>
              </div>
              <div className="flex items-center gap-2">
                <MessageCircle className="w-4 h-4 text-[#E3CAAB] shrink-0" />
                <a href={settings.whatsappUrl || `https://wa.me/91${settings.phone}`} target="_blank" rel="noreferrer" className="hover:text-[#E3CAAB]">
                  WhatsApp: {settings.whatsappNumber || settings.phone}
                </a>
              </div>
              {settings.email && (
                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4 text-[#E3CAAB] shrink-0" />
                  <span>{settings.email}</span>
                </div>
              )}
              <div className="pt-2 text-[11px] text-[#E3CAAB]">
                {settings.deliveryPromise || 'Delivery & Setup across Ahmedabad & Gujarat'}
              </div>
            </div>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-xs text-[#F7F3EE]/60 gap-4">
          <p>© {new Date().getFullYear()} {settings.businessName || 'AFURN'} Furniture. All rights reserved. Direct Manufacturer in {settings.city || 'Ahmedabad'}.</p>

          <div className="flex items-center gap-4">
            {/* Direct Admin Login Link */}
            <Link
              to="/admin/login"
              className="px-3.5 py-1.5 bg-[#B08A62] text-white hover:bg-white hover:text-[#473C38] text-[11px] font-semibold tracking-wider uppercase border border-[#B08A62] transition-colors flex items-center gap-1.5 shadow-sm"
              title="Open Admin Panel"
            >
              <Lock className="w-3.5 h-3.5" />
              <span>ADMIN LOGIN</span>
            </Link>

            <button
              onClick={scrollToTop}
              aria-label="Scroll to top"
              className="flex items-center gap-1.5 hover:text-[#E3CAAB] transition-colors cursor-pointer"
            >
              <span>Back to top</span>
              <ArrowUp className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
}
