import { ArrowUpRight } from 'lucide-react';
import { useData } from '../context/DataContext';

interface CategoriesProps {
  onSelectCategory: (categoryId: string) => void;
}

export default function Categories({ onSelectCategory }: CategoriesProps) {
  const { categories, products, settings } = useData();

  if (settings.sections && settings.sections.categories === false) {
    return null;
  }

  // Only active categories, sorted by displayOrder
  const activeCategories = categories
    .filter((c) => c.status === 'active')
    .sort((a, b) => (a.displayOrder || 0) - (b.displayOrder || 0));

  return (
    <section id="categories" className="py-16 sm:py-24 bg-[#F7F3EE] border-t border-[#E3CAAB]/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-12 sm:mb-16">
          <p className="text-[11px] tracking-[0.25em] font-semibold text-[#B08A62] uppercase mb-2">
            CURATED COLLECTIONS
          </p>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-medium text-[#292522] tracking-tight">
            SHOP BY CATEGORY
          </h2>
          <p className="mt-3 text-sm sm:text-base text-[#473C38]/80 leading-relaxed font-normal">
            Explore furniture designed for every corner of your home.
          </p>
        </div>

        {/* Category Grid: Dynamic from Database */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 sm:gap-8">
          {activeCategories.map((cat, idx) => {
            const isFeatured = idx === 0 || idx === 1;
            const itemCount = products.filter((p) => p.categoryId === cat.id && p.status === 'active').length;

            return (
              <div
                key={cat.id}
                onClick={() => onSelectCategory(cat.id)}
                className={`group relative overflow-hidden bg-white border border-[#E3CAAB]/50 cursor-pointer transition-all duration-300 hover:shadow-xl hover:border-[#B08A62]/60 ${
                  isFeatured ? 'sm:col-span-1 lg:col-span-2' : ''
                }`}
              >
                {/* Image Container */}
                <div className={`overflow-hidden bg-[#F7F3EE] ${isFeatured ? 'aspect-[16/10]' : 'aspect-[4/3]'}`}>
                  <img
                    src={cat.image}
                    alt={cat.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover object-center transition-transform duration-700 group-hover:scale-105"
                  />
                  {/* Scrim for text legibility */}
                  <div className="absolute inset-0 bg-gradient-to-t from-[#473C38]/70 via-[#473C38]/20 to-transparent opacity-80 group-hover:opacity-90 transition-opacity" />
                </div>

                {/* Card Floating Content */}
                <div className="absolute inset-0 p-6 flex flex-col justify-end text-white">
                  <div className="flex items-end justify-between">
                    <div>
                      <p className="text-[10px] tracking-[0.2em] uppercase text-[#E3CAAB] font-semibold">
                        {itemCount > 0 ? `${itemCount}+ Designs Available` : 'Bespoke Collection'}
                      </p>
                      <h3 className="text-xl sm:text-2xl font-serif font-medium tracking-wide mt-1 uppercase">
                        {cat.name}
                      </h3>
                      {cat.description && (
                        <p className="text-xs text-white/80 mt-1 max-w-xs font-light line-clamp-1">
                          {cat.description}
                        </p>
                      )}
                    </div>

                    <div className="w-9 h-9 bg-white/20 backdrop-blur-md rounded-none flex items-center justify-center text-white group-hover:bg-[#B08A62] group-hover:text-white transition-colors shrink-0">
                      <ArrowUpRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Custom Furniture Prompt Bar */}
        <div className="mt-12 bg-[#E3CAAB]/30 border border-[#E3CAAB] p-6 sm:p-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <h4 className="text-lg font-serif font-semibold text-[#473C38]">
              Looking for something tailored to your exact floorplan?
            </h4>
            <p className="text-xs sm:text-sm text-[#292522]/80 mt-1">
              {settings.businessName || 'AFURN'} crafts custom wooden swings, sectionals, dining sets & metal furniture in our Danilimda workshop.
            </p>
          </div>
          <a
            href="#custom"
            className="px-6 py-2.5 bg-[#473C38] text-white text-xs font-semibold tracking-wider hover:bg-[#B08A62] transition-colors whitespace-nowrap cursor-pointer"
          >
            CUSTOMIZE FURNITURE
          </a>
        </div>

      </div>
    </section>
  );
}
