import { X, Trash2, ShoppingBag, Heart } from 'lucide-react';
import { Product } from '../types/furniture';

interface WishlistDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  wishlist: Product[];
  onRemoveFromWishlist: (productId: string) => void;
  onAddToCart: (product: Product) => void;
}

export default function WishlistDrawer({
  isOpen,
  onClose,
  wishlist,
  onRemoveFromWishlist,
  onAddToCart,
}: WishlistDrawerProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/60 backdrop-blur-sm animate-fade-in">
      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-[#F7F3EE] shadow-2xl flex flex-col justify-between border-l border-[#E3CAAB]">
          
          {/* Header */}
          <div className="p-6 border-b border-[#E3CAAB]/60 flex items-center justify-between bg-white">
            <div className="flex items-center gap-2">
              <Heart className="w-5 h-5 text-red-500 fill-current" />
              <h2 className="font-serif text-xl font-medium text-[#292522]">
                Saved Favorites
              </h2>
              <span className="text-xs text-[#B08A62] font-semibold tabular-nums">
                ({wishlist.length})
              </span>
            </div>
            <button
              onClick={onClose}
              aria-label="Close wishlist"
              className="p-2 text-[#473C38] hover:text-[#B08A62] transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* List */}
          <div className="p-6 flex-1 overflow-y-auto">
            {wishlist.length === 0 ? (
              <div className="py-20 text-center">
                <Heart className="w-12 h-12 text-[#E3CAAB] mx-auto stroke-[1.2]" />
                <h3 className="font-serif text-lg text-[#473C38] mt-4">Your wishlist is empty</h3>
                <p className="text-xs text-[#473C38]/60 mt-1 max-w-xs mx-auto">
                  Click the heart icon on any sofa, dining suite, or table to save it here.
                </p>
                <button
                  onClick={onClose}
                  className="mt-6 px-6 py-2.5 bg-[#473C38] text-white text-xs font-semibold tracking-wider hover:bg-[#B08A62] transition-colors cursor-pointer"
                >
                  DISCOVER DESIGNS
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {wishlist.map((product) => (
                  <div
                    key={product.id}
                    className="p-3 bg-white border border-[#E3CAAB]/60 flex gap-4 items-center"
                  >
                    <img
                      src={(product.images && product.images[0]) || product.image}
                      alt={product.name}
                      referrerPolicy="no-referrer"
                      className="w-16 h-16 object-cover bg-[#F7F3EE] shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <h4 className="text-xs font-serif font-medium text-[#292522] truncate">
                        {product.name}
                      </h4>
                      <p className="text-xs font-semibold text-[#473C38] mt-0.5 tabular-nums">
                        ₹{product.price.toLocaleString('en-IN')}
                      </p>
                      <div className="mt-2 flex items-center gap-2">
                        <button
                          onClick={() => {
                            onAddToCart(product);
                            onRemoveFromWishlist(product.id);
                          }}
                          className="px-2.5 py-1 bg-[#473C38] text-white hover:bg-[#B08A62] text-[10px] font-semibold tracking-wider flex items-center gap-1 transition-colors cursor-pointer"
                        >
                          <ShoppingBag className="w-3 h-3" />
                          <span>MOVE TO BAG</span>
                        </button>
                        <button
                          onClick={() => onRemoveFromWishlist(product.id)}
                          className="p-1 text-[#473C38]/50 hover:text-red-600 transition-colors"
                          title="Remove from favorites"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="p-6 bg-white border-t border-[#E3CAAB]/60">
            <button
              onClick={onClose}
              className="w-full py-3 border border-[#473C38] text-[#473C38] hover:bg-[#473C38] hover:text-white text-xs font-semibold tracking-wider transition-colors cursor-pointer"
            >
              CONTINUE BROWSING
            </button>
          </div>

        </div>
      </div>
    </div>
  );
}
