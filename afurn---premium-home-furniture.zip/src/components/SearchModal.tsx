import { useState, useEffect, useRef } from 'react';
import { Search, X, ArrowRight } from 'lucide-react';
import { Product } from '../types/furniture';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  onSelectProduct: (product: Product) => void;
}

export default function SearchModal({
  isOpen,
  onClose,
  products,
  onSelectProduct,
}: SearchModalProps) {
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    } else {
      setQuery('');
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const results = query.trim() === ''
    ? []
    : products.filter(
        (p) =>
          p.name.toLowerCase().includes(query.toLowerCase()) ||
          (p.categoryLabel && p.categoryLabel.toLowerCase().includes(query.toLowerCase())) ||
          (p.material && p.material.toLowerCase().includes(query.toLowerCase())) ||
          (p.materials && p.materials.toLowerCase().includes(query.toLowerCase())) ||
          (p.description && p.description.toLowerCase().includes(query.toLowerCase())) ||
          (p.sku && p.sku.toLowerCase().includes(query.toLowerCase()))
      );

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex items-start justify-center p-4 sm:p-6 pt-16 sm:pt-24 animate-fade-in">
      <div className="relative w-full max-w-2xl bg-[#F7F3EE] shadow-2xl border border-[#E3CAAB] overflow-hidden">
        
        {/* Search Input Bar */}
        <div className="p-4 sm:p-5 bg-white border-b border-[#E3CAAB]/60 flex items-center gap-3">
          <Search className="w-5 h-5 text-[#B08A62] shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search sofas, teak dining tables, swings, chairs, centre tables..."
            className="w-full bg-transparent text-sm sm:text-base text-[#292522] focus:outline-none placeholder:text-[#473C38]/40"
          />
          <button
            onClick={onClose}
            aria-label="Close search"
            className="p-1.5 text-[#473C38] hover:text-[#B08A62] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Results Area */}
        <div className="max-h-[60vh] overflow-y-auto p-4 sm:p-6">
          {query.trim() === '' ? (
            <div>
              <p className="text-[11px] tracking-widest uppercase font-semibold text-[#B08A62] mb-3">
                POPULAR SEARCHES
              </p>
              <div className="flex flex-wrap gap-2">
                {[
                  'Curved 3-Seater Sofa',
                  'Teak Dining Table',
                  'Ahmedabad Wooden Swing (Jhula)',
                  'Cognac Leather Lounge',
                  'Nesting Centre Table',
                  'Study Table',
                  'Cane Dining Chairs',
                ].map((term) => (
                  <button
                    key={term}
                    onClick={() => setQuery(term)}
                    className="px-3 py-1.5 bg-white border border-[#E3CAAB]/70 text-xs text-[#473C38] hover:bg-[#473C38] hover:text-white transition-colors cursor-pointer"
                  >
                    {term}
                  </button>
                ))}
              </div>
            </div>
          ) : results.length === 0 ? (
            <div className="text-center py-10">
              <p className="font-serif text-lg text-[#473C38]">No furniture matches for "{query}"</p>
              <p className="text-xs text-[#473C38]/60 mt-1">
                Looking for custom dimensions? We can manufacture any piece in our Danilimda workshop.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              <p className="text-[11px] tracking-widest uppercase font-semibold text-[#B08A62] mb-2">
                {results.length} PIECES FOUND
              </p>
              {results.map((product) => (
                <div
                  key={product.id}
                  onClick={() => {
                    onSelectProduct(product);
                    onClose();
                  }}
                  className="p-3 bg-white border border-[#E3CAAB]/60 flex items-center justify-between hover:border-[#B08A62] transition-colors cursor-pointer group"
                >
                  <div className="flex items-center gap-3">
                    <img
                      src={(product.images && product.images[0]) || product.image}
                      alt={product.name}
                      referrerPolicy="no-referrer"
                      className="w-14 h-14 object-cover bg-[#F7F3EE] shrink-0"
                    />
                    <div>
                      <span className="text-[10px] tracking-wider uppercase text-[#B08A62] font-semibold">
                        {product.categoryLabel}
                      </span>
                      <h4 className="text-xs sm:text-sm font-serif font-medium text-[#292522] group-hover:text-[#B08A62] transition-colors">
                        {product.name}
                      </h4>
                      <p className="text-xs font-semibold text-[#473C38] mt-0.5 tabular-nums">
                        ₹{product.price.toLocaleString('en-IN')}
                      </p>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-[#473C38]/40 group-hover:text-[#B08A62] transition-colors shrink-0" />
                </div>
              ))}
            </div>
          )}
        </div>

      </div>
    </div>
  );
}
