import { Star } from 'lucide-react';
import { useData } from '../context/DataContext';

export default function TestimonialsSection() {
  const { testimonials, settings } = useData();

  if (settings.sections && settings.sections.testimonials === false) {
    return null;
  }

  const activeTestimonials = testimonials.filter((t) => t.status === 'active');
  if (activeTestimonials.length === 0) return null;

  return (
    <section id="testimonials" className="py-16 sm:py-24 bg-[#E3CAAB]/20 border-t border-[#E3CAAB]/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="text-center max-w-2xl mx-auto mb-12 sm:mb-16">
          <p className="text-[11px] tracking-[0.25em] font-semibold text-[#B08A62] uppercase mb-2">
            PROVEN SATISFACTION
          </p>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-medium text-[#292522] tracking-tight">
            Trusted Across Gujarat
          </h2>
          <p className="mt-3 text-sm text-[#473C38]/80 leading-relaxed font-normal">
            Real feedback from Ahmedabad homeowners, architects, and hospitality creators who rely on {settings.businessName || 'AFURN'}.
          </p>
        </div>

        {/* Testimonials Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {activeTestimonials.map((t) => (
            <div
              key={t.id}
              className="bg-white p-7 border border-[#E3CAAB] shadow-sm flex flex-col justify-between"
            >
              <div>
                {/* Star Rating */}
                <div className="flex items-center space-x-1 mb-4 text-[#B08A62]">
                  {[...Array(t.rating || 5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-current" />
                  ))}
                </div>

                {/* Quote */}
                <p className="text-xs sm:text-sm text-[#473C38]/85 leading-relaxed italic">
                  "{t.quote}"
                </p>
              </div>

              {/* Attribution */}
              <div className="mt-6 pt-5 border-t border-[#E3CAAB]/50">
                <p className="text-sm font-semibold text-[#292522]">
                  {t.name}
                </p>
                <p className="text-xs text-[#B08A62] font-medium">
                  {t.role}
                </p>
                <div className="mt-1 flex items-center justify-between text-[11px] text-[#473C38]/60">
                  <span>{t.location}</span>
                  {t.project && (
                    <span className="text-[10px] text-[#473C38]/40 truncate max-w-[140px]">{t.project}</span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Adjacency Trust Metric Bar */}
        <div className="mt-12 bg-white border border-[#E3CAAB] p-6 sm:p-8 grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          <div>
            <p className="font-serif text-3xl sm:text-4xl font-semibold text-[#473C38]">
              {settings.experience ? settings.experience.split(' ')[0] : '15+'}
            </p>
            <p className="text-xs text-[#473C38]/70 uppercase tracking-wider mt-1">Years Manufacturing</p>
          </div>
          <div>
            <p className="font-serif text-3xl sm:text-4xl font-semibold text-[#473C38]">3,500+</p>
            <p className="text-xs text-[#473C38]/70 uppercase tracking-wider mt-1">Homes Furnished</p>
          </div>
          <div>
            <p className="font-serif text-3xl sm:text-4xl font-semibold text-[#473C38]">180+</p>
            <p className="text-xs text-[#473C38]/70 uppercase tracking-wider mt-1">Architect Projects</p>
          </div>
          <div>
            <p className="font-serif text-3xl sm:text-4xl font-semibold text-[#473C38]">100%</p>
            <p className="text-xs text-[#473C38]/70 uppercase tracking-wider mt-1">Direct Factory Pricing</p>
          </div>
        </div>

      </div>
    </section>
  );
}
