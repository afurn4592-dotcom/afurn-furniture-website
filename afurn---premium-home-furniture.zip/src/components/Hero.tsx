import { ArrowRight } from 'lucide-react';
import { IMAGES } from '../data/furnitureData';
import { useData } from '../context/DataContext';

interface HeroProps {
  onShopClick: () => void;
  onExploreClick: () => void;
}

export default function Hero({ onShopClick, onExploreClick }: HeroProps) {
  const { settings } = useData();

  if (settings.sections && settings.sections.hero === false) {
    return null;
  }

  // Handle multi-line hero heading
  const headingLines = (settings.heroHeading || 'FURNITURE THAT\nMAKES YOUR SPACE\nFEEL LIKE HOME.')
    .split('\n');

  return (
    <section id="home" className="relative overflow-hidden bg-[#F7F3EE] pt-6 pb-16 lg:py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
          
          {/* Left Column: Text & Intent */}
          <div className="lg:col-span-6 flex flex-col justify-center">
            {/* Small Label */}
            <div className="inline-flex items-center space-x-2 text-[11px] sm:text-xs tracking-[0.25em] font-semibold text-[#B08A62] uppercase mb-4">
              <span>{settings.heroLabel || 'CRAFTED FOR MODERN LIVING'}</span>
            </div>

            {/* Large Heading */}
            <h1 className="text-4xl sm:text-5xl lg:text-[3.5rem] font-serif font-medium leading-[1.12] text-[#292522] tracking-tight text-balance">
              {headingLines.map((line, idx) => (
                <span key={idx}>
                  {line}
                  {idx < headingLines.length - 1 && <br />}
                </span>
              ))}
            </h1>

            {/* Supporting Text */}
            <p className="mt-6 text-base sm:text-lg text-[#473C38]/85 leading-relaxed max-w-xl font-normal">
              {settings.heroDescription || 'Discover beautifully crafted furniture designed for comfort, durability and timeless style.'}
            </p>

            {/* Action Buttons */}
            <div className="mt-8 flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
              <button
                onClick={onShopClick}
                className="px-7 py-3.5 bg-[#473C38] text-white text-xs sm:text-sm font-semibold tracking-[0.14em] uppercase hover:bg-[#B08A62] transition-colors duration-200 text-center flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>{settings.heroButton1Text || 'SHOP FURNITURE'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={onExploreClick}
                className="px-7 py-3.5 border border-[#473C38] text-[#473C38] text-xs sm:text-sm font-semibold tracking-[0.14em] uppercase hover:bg-[#E3CAAB]/30 transition-colors duration-200 text-center cursor-pointer"
              >
                <span>{settings.heroButton2Text || 'EXPLORE COLLECTION'}</span>
              </button>
            </div>

            {/* Trust Statement */}
            <div className="mt-10 pt-6 border-t border-[#E3CAAB]/50">
              <div className="text-[11px] sm:text-xs tracking-[0.18em] font-semibold text-[#473C38]/80 uppercase">
                {settings.heroTrustStatement || '15+ YEARS OF EXPERIENCE • PREMIUM QUALITY • CUSTOM DESIGNS'}
              </div>
              <div className="mt-2 text-xs text-[#473C38]/60 flex items-center gap-2">
                <span>Direct Manufacturer</span>
                <span aria-hidden="true">·</span>
                <span>{settings.city || 'Danilimda, Ahmedabad'}</span>
                <span aria-hidden="true">·</span>
                <span>{settings.deliveryPromise || 'Delivery across Gujarat'}</span>
              </div>
            </div>
          </div>

          {/* Right Column: Hero Image Showcase */}
          <div className="lg:col-span-6 relative">
            <div className="relative overflow-hidden shadow-2xl bg-[#E3CAAB]/20 aspect-[16/11] lg:aspect-[16/12]">
              <img
                src={IMAGES.hero}
                alt="AFURN Luxury Living Room Furniture Collection"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover object-center transition-transform duration-700 hover:scale-[1.02]"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#473C38]/30 via-transparent to-transparent pointer-events-none" />

              <div className="absolute bottom-4 left-4 sm:bottom-6 sm:left-6 bg-white/95 backdrop-blur-md px-4 py-2.5 shadow-lg border border-[#E3CAAB]/60">
                <p className="text-[10px] tracking-[0.16em] uppercase text-[#B08A62] font-semibold">
                  {settings.city ? `${settings.city.toUpperCase()} WORKSHOP` : 'AHMEDABAD WORKSHOP'}
                </p>
                <p className="text-xs sm:text-sm font-serif font-semibold text-[#292522]">
                  Handcrafted Solid Teak & Steel
                </p>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
