import { useState } from 'react';
import { Eye, X } from 'lucide-react';
import { useData } from '../context/DataContext';
import { GalleryItem } from '../types/furniture';

export default function GallerySection() {
  const { gallery, settings } = useData();
  const [activePhoto, setActivePhoto] = useState<GalleryItem | null>(null);

  if (settings.sections && settings.sections.gallery === false) {
    return null;
  }

  const activeGallery = gallery
    .filter((g) => g.status === 'active')
    .sort((a, b) => (a.displayOrder || 0) - (b.displayOrder || 0));

  if (activeGallery.length === 0) {
    return null;
  }

  return (
    <section id="gallery" className="py-16 sm:py-24 bg-[#F7F3EE] border-t border-[#E3CAAB]/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="text-center max-w-2xl mx-auto mb-12 sm:mb-16">
          <p className="text-[11px] tracking-[0.25em] font-semibold text-[#B08A62] uppercase mb-2">
            SPACE INSPIRATION
          </p>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-medium text-[#292522] tracking-tight">
            Craftsmanship in Real Spaces
          </h2>
          <p className="mt-3 text-sm text-[#473C38]/80 leading-relaxed font-normal">
            Take a look at recent furniture installations in Ahmedabad villas, apartments, and modern dining rooms.
          </p>
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {activeGallery.map((item) => (
            <div
              key={item.id}
              onClick={() => setActivePhoto(item)}
              className="group relative overflow-hidden bg-white border border-[#E3CAAB]/50 aspect-[4/3] cursor-pointer shadow-sm hover:shadow-xl transition-all duration-300"
            >
              <img
                src={item.image}
                alt={item.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover object-center transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#473C38]/80 via-transparent to-transparent opacity-80 group-hover:opacity-95 transition-opacity" />

              <div className="absolute inset-x-0 bottom-0 p-5 text-white flex items-end justify-between">
                <div>
                  <span className="text-[10px] tracking-widest uppercase text-[#E3CAAB] font-semibold">
                    {item.category}
                  </span>
                  <h3 className="font-serif text-lg font-medium mt-0.5">
                    {item.title}
                  </h3>
                  {item.details && (
                    <p className="text-xs text-white/80 line-clamp-1 mt-0.5">
                      {item.details}
                    </p>
                  )}
                </div>
                <div className="w-8 h-8 bg-white/20 backdrop-blur-md flex items-center justify-center text-white group-hover:bg-[#B08A62] transition-colors shrink-0">
                  <Eye className="w-4 h-4" />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Lightbox Modal */}
        {activePhoto && (
          <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 animate-fade-in">
            <div className="relative max-w-4xl w-full bg-[#F7F3EE] overflow-hidden border border-[#E3CAAB] shadow-2xl">
              <button
                onClick={() => setActivePhoto(null)}
                aria-label="Close photo"
                className="absolute top-4 right-4 z-10 p-2 bg-white/80 hover:bg-white text-[#473C38] cursor-pointer transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
              <div className="aspect-[16/10] bg-black">
                <img
                  src={activePhoto.image}
                  alt={activePhoto.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-6 bg-white border-t border-[#E3CAAB]/60 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <span className="text-[10px] tracking-widest uppercase text-[#B08A62] font-semibold">
                    {activePhoto.category}
                  </span>
                  <h3 className="font-serif text-2xl text-[#292522] mt-1">
                    {activePhoto.title}
                  </h3>
                  <p className="text-xs text-[#473C38]/70 mt-1">
                    {activePhoto.details}
                  </p>
                </div>
                <a
                  href="#custom"
                  onClick={() => setActivePhoto(null)}
                  className="px-6 py-2.5 bg-[#473C38] text-white hover:bg-[#B08A62] text-xs font-semibold tracking-wider whitespace-nowrap text-center transition-colors"
                >
                  REQUEST THIS DESIGN
                </a>
              </div>
            </div>
          </div>
        )}

      </div>
    </section>
  );
}
