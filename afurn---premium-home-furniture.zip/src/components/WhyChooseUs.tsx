import React from 'react';
import {
  Award,
  Sparkles,
  TreeDeciduous,
  Ruler,
  Building,
  ShieldCheck,
  Truck,
  CheckCircle2
} from 'lucide-react';
import { useData } from '../context/DataContext';

const ICON_MAP: Record<string, React.ElementType> = {
  Award,
  TreeDeciduous,
  Ruler,
  Building,
  ShieldCheck,
  Truck,
  Sparkles,
};

export default function WhyChooseUs() {
  const { settings } = useData();

  if (settings.sections && settings.sections.whyChooseUs === false) {
    return null;
  }

  const cards = (settings.whyChooseUsCards || []).filter((c) => c.isVisible !== false);

  if (cards.length === 0) {
    return null;
  }

  return (
    <section id="why-us" className="py-16 sm:py-20 bg-white border-t border-[#E3CAAB]/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-12 sm:mb-16">
          <span className="text-[11px] sm:text-xs tracking-[0.25em] font-semibold text-[#B08A62] uppercase">
            WHY AFURN
          </span>
          <h2 className="text-3xl sm:text-4xl font-serif font-medium text-[#292522] tracking-tight mt-1">
            Built on Integrity, Crafted for Generations
          </h2>
          <p className="mt-3 text-sm sm:text-base text-[#473C38]/80 leading-relaxed font-normal">
            Direct Ahmedabad manufacturing with 15+ years of master woodworking and structural steel craftsmanship.
          </p>
        </div>

        {/* 6 Grid Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {cards.map((card) => {
            const IconComponent = (card.icon && ICON_MAP[card.icon]) || Award;

            return (
              <div
                key={card.id}
                className="p-6 sm:p-7 border border-[#E3CAAB]/70 bg-[#F7F3EE]/30 hover:bg-[#F7F3EE] transition-all duration-300 group hover:border-[#B08A62] hover:shadow-xs flex flex-col justify-between"
              >
                <div>
                  <div className="w-12 h-12 bg-white border border-[#E3CAAB] flex items-center justify-center text-[#B08A62] group-hover:bg-[#473C38] group-hover:text-white group-hover:border-[#473C38] transition-colors duration-200 mb-5 shadow-xs">
                    <IconComponent className="w-6 h-6 stroke-[1.8]" />
                  </div>

                  <h3 className="font-serif text-base font-semibold text-[#292522] tracking-wide mb-2 group-hover:text-[#473C38]">
                    {card.title}
                  </h3>

                  <p className="text-xs sm:text-[13px] text-[#473C38]/80 leading-relaxed">
                    {card.description}
                  </p>
                </div>

                <div className="pt-4 mt-4 border-t border-[#E3CAAB]/40 flex items-center gap-1.5 text-[11px] font-semibold text-[#B08A62]">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Guaranteed Standard</span>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
