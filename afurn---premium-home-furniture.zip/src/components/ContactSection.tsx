import { useState, FormEvent } from 'react';
import { MapPin, Phone, MessageCircle, Mail, Clock, Send, CheckCircle2, Navigation } from 'lucide-react';
import { useData } from '../context/DataContext';

export default function ContactSection() {
  const { settings, addEnquiry } = useData();

  if (settings.sections && settings.sections.contactSection === false) {
    return null;
  }

  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    subject: 'Workshop Visit & Consultation',
    message: '',
  });
  const [sent, setSent] = useState(false);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setSent(true);

    // Save inquiry to unified persistent database
    addEnquiry({
      customerName: formData.name,
      phone: formData.phone,
      email: formData.email,
      type: 'Contact Form',
      message: `[${formData.subject}] ${formData.message}`,
    });

    const text = encodeURIComponent(
      `*NEW INQUIRY - ${settings.businessName || 'AFURN'} AHMEDABAD*\n` +
      `---------------------------------\n` +
      `*Name:* ${formData.name}\n` +
      `*Phone:* ${formData.phone}\n` +
      `*Email:* ${formData.email || 'N/A'}\n` +
      `*Subject:* ${formData.subject}\n` +
      `*Message:* ${formData.message}\n` +
      `---------------------------------\n` +
      `Requesting assistance from AFURN showroom/workshop.`
    );

    window.open(`https://wa.me/91${settings.phone}?text=${text}`, '_blank');
  };

  return (
    <section id="contact" className="py-16 sm:py-24 bg-[#F7F3EE] border-t border-[#E3CAAB]/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="text-center max-w-2xl mx-auto mb-14">
          <p className="text-[11px] tracking-[0.25em] font-semibold text-[#B08A62] uppercase mb-2">
            CONNECT WITH {settings.businessName || 'AFURN'}
          </p>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-medium text-[#292522] tracking-tight">
            Visit Our {settings.city || 'Ahmedabad'} Factory
          </h2>
          <p className="mt-3 text-sm text-[#473C38]/80 leading-relaxed font-normal">
            Step into our workshop in Danilimda, touch raw seasoned teakwood, test cushion densities, and collaborate with master craftsmen.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          
          {/* Left Column: Workshop Details & Info */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* Address Card */}
            <div className="bg-white p-6 border border-[#E3CAAB] shadow-sm">
              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-[#B08A62] shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-serif text-lg font-medium text-[#292522]">
                    Factory & Experience Centre
                  </h3>
                  <p className="mt-2 text-xs sm:text-sm text-[#473C38]/85 leading-relaxed">
                    {settings.address || '309, Sahkar Estate, Opp. Chandola Petrol Pump, Chandola Lake, Danilimda, Ahmedabad - 380028, Gujarat, India'}
                  </p>
                  <a
                    href="https://maps.google.com/?q=Chandola+Lake+Danilimda+Ahmedabad+380028"
                    target="_blank"
                    rel="noreferrer"
                    className="mt-3 inline-flex items-center gap-1.5 text-xs font-semibold text-[#B08A62] hover:text-[#473C38] transition-colors"
                  >
                    <Navigation className="w-3.5 h-3.5" />
                    <span>Get Directions on Google Maps</span>
                  </a>
                </div>
              </div>
            </div>

            {/* Direct Contact Numbers */}
            <div className="bg-white p-6 border border-[#E3CAAB] shadow-sm space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 bg-[#F7F3EE] flex items-center justify-center text-[#B08A62] shrink-0">
                  <Phone className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-[10px] tracking-wider uppercase text-[#473C38]/60 font-semibold">
                    Phone / Call
                  </p>
                  <a
                    href={`tel:${settings.phone}`}
                    className="text-sm font-semibold text-[#292522] hover:text-[#B08A62] transition-colors"
                  >
                    {settings.displayPhone || settings.phone}
                  </a>
                </div>
              </div>

              <div className="flex items-center gap-3 pt-3 border-t border-[#E3CAAB]/40">
                <div className="w-9 h-9 bg-[#F7F3EE] flex items-center justify-center text-emerald-700 shrink-0">
                  <MessageCircle className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-[10px] tracking-wider uppercase text-[#473C38]/60 font-semibold">
                    WhatsApp (Fastest Response)
                  </p>
                  <a
                    href={settings.whatsappUrl || `https://wa.me/91${settings.phone}`}
                    target="_blank"
                    rel="noreferrer"
                    className="text-sm font-semibold text-[#292522] hover:text-[#B08A62] transition-colors"
                  >
                    +91 {settings.whatsappNumber || settings.phone}
                  </a>
                </div>
              </div>

              {settings.email && (
                <div className="flex items-center gap-3 pt-3 border-t border-[#E3CAAB]/40">
                  <div className="w-9 h-9 bg-[#F7F3EE] flex items-center justify-center text-[#B08A62] shrink-0">
                    <Mail className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="text-[10px] tracking-wider uppercase text-[#473C38]/60 font-semibold">
                      Email
                    </p>
                    <a
                      href={`mailto:${settings.email}`}
                      className="text-sm font-semibold text-[#292522] hover:text-[#B08A62] transition-colors"
                    >
                      {settings.email}
                    </a>
                  </div>
                </div>
              )}

              <div className="flex items-center gap-3 pt-3 border-t border-[#E3CAAB]/40">
                <div className="w-9 h-9 bg-[#F7F3EE] flex items-center justify-center text-[#B08A62] shrink-0">
                  <Clock className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-[10px] tracking-wider uppercase text-[#473C38]/60 font-semibold">
                    Working Hours
                  </p>
                  <p className="text-xs text-[#292522] font-medium">
                    {settings.workingHours}
                  </p>
                </div>
              </div>
            </div>

            {/* Quick Action Buttons */}
            <div className="grid grid-cols-2 gap-3">
              <a
                href={settings.whatsappUrl || `https://wa.me/91${settings.phone}`}
                target="_blank"
                rel="noreferrer"
                className="py-3 bg-[#473C38] text-white hover:bg-[#B08A62] text-xs font-semibold tracking-wider flex items-center justify-center gap-1.5 transition-colors"
              >
                <MessageCircle className="w-4 h-4" />
                <span>CHAT WHATSAPP</span>
              </a>
              <a
                href={`tel:${settings.phone}`}
                className="py-3 border border-[#473C38] text-[#473C38] hover:bg-white text-xs font-semibold tracking-wider flex items-center justify-center gap-1.5 transition-colors"
              >
                <Phone className="w-4 h-4" />
                <span>CALL NOW</span>
              </a>
            </div>

          </div>

          {/* Right Column: Inquiry / Visit Request Form */}
          <div className="lg:col-span-7 bg-white p-6 sm:p-8 border border-[#E3CAAB] shadow-sm">
            <h3 className="font-serif text-2xl font-medium text-[#292522]">
              Schedule a Factory Visit or Inquiry
            </h3>
            <p className="mt-1 text-xs text-[#473C38]/70">
              Leave your details below. We will coordinate your visit or send product catalogs.
            </p>

            <form onSubmit={handleSubmit} className="mt-6 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1.5">
                    Your Name: *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Full name"
                    className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/60 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1.5">
                    Phone / WhatsApp: *
                  </label>
                  <input
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="e.g. 7069469407"
                    className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/60 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1.5">
                  I am interested in:
                </label>
                <select
                  value={formData.subject}
                  onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/60 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38] cursor-pointer"
                >
                  <option value="Workshop Visit & Consultation">Workshop Visit & Consultation</option>
                  <option value="Living Room Sofa / Sectional Pricing">Living Room Sofa / Sectional Pricing</option>
                  <option value="Solid Teak Dining Table & Chairs">Solid Teak Dining Table & Chairs</option>
                  <option value="Heritage Wooden Swing (Jhula)">Heritage Wooden Swing (Jhula)</option>
                  <option value="Custom Furniture Manufacturing">Custom Furniture Manufacturing</option>
                  <option value="Architect / Interior Designer Partnership">Architect / Interior Designer Partnership</option>
                  <option value="Commercial / Restaurant Bulk Order">Commercial / Restaurant Bulk Order</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1.5">
                  Message / Room Details:
                </label>
                <textarea
                  rows={4}
                  required
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  placeholder="Share details of what you are looking for, preferred date of visit, or delivery area in Ahmedabad..."
                  className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/60 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3.5 bg-[#473C38] text-white hover:bg-[#B08A62] text-xs font-semibold tracking-wider flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <Send className="w-4 h-4" />
                <span>SEND DIRECT MESSAGE</span>
              </button>
            </form>

            {sent && (
              <div className="mt-4 p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Your inquiry has been submitted and saved in our system. Opening WhatsApp to connect with our master craftsmen!</span>
              </div>
            )}
          </div>

        </div>

      </div>
    </section>
  );
}
