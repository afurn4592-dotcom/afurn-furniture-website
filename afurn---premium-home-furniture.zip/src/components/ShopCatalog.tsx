import { useState, useMemo } from 'react';
import { Heart, Eye, ShoppingBag, MessageCircle, SlidersHorizontal, Check } from 'lucide-react';
import { Product } from '../types/furniture';
import { useData } from '../context/DataContext';

interface ShopCatalogProps {
  products: Product[];
  selectedCategory: string;
  onSelectCategory: (catId: string) => void;
  onOpenQuickView: (product: Product) => void;
  onAddToCart: (product: Product) => void;
  onToggleWishlist: (product: Product) => void;
  isInWishlist: (productId: string) => boolean;
}

export default function ShopCatalog({
  products,
  selectedCategory,
  onSelectCategory,
  onOpenQuickView,
  onAddToCart,
  onToggleWishlist,
  isInWishlist,
}: ShopCatalogProps) {
  const { categories, settings } = useData();

  if (settings.sections && settings.sections.featuredProducts === false) {
    return null;
  }

  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc'>('featured');
  const [searchFilter, setSearchFilter] = useState('');
  const [addedNotice, setAddedNotice] = useState<string | null>(null);

  // Active categories for filter tabs
  const activeCategories = useMemo(() => {
    return categories
      .filter((c) => c.status === 'active')
      .sort((a, b) => (a.displayOrder || 0) - (b.displayOrder || 0));
  }, [categories]);

  // Only display ACTIVE products to customers
  const filteredProducts = useMemo(() => {
    return products
      .filter((p) => {
        // Exclude inactive
        if (p.status === 'inactive') return false;

        const pCat = p.categoryId || (p as any).category;
        const matchesCategory = selectedCategory === 'all' || pCat === selectedCategory;
        const matchesSearch =
          searchFilter === '' ||
          p.name.toLowerCase().includes(searchFilter.toLowerCase()) ||
          (p.material && p.material.toLowerCase().includes(searchFilter.toLowerCase())) ||
          (p.materials && p.materials.toLowerCase().includes(searchFilter.toLowerCase())) ||
          (p.description && p.description.toLowerCase().includes(searchFilter.toLowerCase())) ||
          p.sku.toLowerCase().includes(searchFilter.toLowerCase());

        return matchesCategory && matchesSearch;
      })
      .sort((a, b) => {
        if (sortBy === 'price-asc') return a.price - b.price;
        if (sortBy === 'price-desc') return b.price - a.price;
        // Default: featured first, then bestsellers
        if (a.featured && !b.featured) return -1;
        if (!a.featured && b.featured) return 1;
        return 0;
      });
  }, [products, selectedCategory, searchFilter, sortBy]);

  const handleQuickAdd = (product: Product) => {
    onAddToCart(product);
    setAddedNotice(product.id);
    setTimeout(() => setAddedNotice(null), 2000);
  };

  const getWhatsAppProductUrl = (product: Product) => {
    const text = encodeURIComponent(
      `Hello ${settings.businessName || 'AFURN'}, I am interested in ordering/inquiring about the "${product.name}" (Price: ₹${product.price.toLocaleString('en-IN')}). Could you please share delivery details for Ahmedabad?`
    );
    return `https://wa.me/91${settings.phone}?text=${text}`;
  };

  return (
    <section id="shop" className="py-16 sm:py-24 bg-[#F7F3EE]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="flex flex-col md:flex-row md:items-end justify-between pb-8 border-b border-[#E3CAAB]/50 gap-6">
          <div>
            <span className="text-[11px] tracking-[0.25em] font-semibold text-[#B08A62] uppercase">
              DIRECT MANUFACTURER CATALOG
            </span>
            <h2 className="text-3xl sm:text-4xl font-serif font-medium text-[#292522] tracking-tight mt-1">
              Handcrafted Furniture Showroom
            </h2>
            <p className="mt-2 text-xs sm:text-sm text-[#473C38]/70">
              Direct factory pricing • 100% Solid wood & heavy-gauge steel • {settings.deliveryPromise || 'Ahmedabad delivery & assembly'}
            </p>
          </div>

          {/* Controls: Search & Sort */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative">
              <input
                type="text"
                value={searchFilter}
                onChange={(e) => setSearchFilter(e.target.value)}
                placeholder="Search wood, style, name, SKU..."
                className="w-48 sm:w-56 px-3 py-2 bg-white text-xs border border-[#E3CAAB] focus:border-[#473C38] focus:outline-none placeholder:text-[#473C38]/40"
              />
            </div>

            <div className="relative flex items-center bg-white border border-[#E3CAAB] px-3 py-2">
              <SlidersHorizontal className="w-3.5 h-3.5 text-[#473C38] mr-2" />
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                aria-label="Sort products"
                className="text-xs bg-transparent focus:outline-none text-[#292522] cursor-pointer"
              >
                <option value="featured">Sort: Featured</option>
                <option value="price-asc">Price: Low to High</option>
                <option value="price-desc">Price: High to Low</option>
              </select>
            </div>
          </div>
        </div>

        {/* Category Filter Tabs - Built dynamically from Categories in Database */}
        <div className="mt-8 flex items-center gap-2 overflow-x-auto pb-3 scrollbar-none">
          <button
            onClick={() => onSelectCategory('all')}
            className={`px-4 py-2 text-xs tracking-wider font-medium whitespace-nowrap transition-colors duration-200 cursor-pointer ${
              selectedCategory === 'all'
                ? 'bg-[#473C38] text-white'
                : 'bg-white/80 text-[#473C38] hover:bg-[#E3CAAB]/40 border border-[#E3CAAB]/60'
            }`}
          >
            ALL COLLECTIONS
          </button>

          {activeCategories.map((cat) => {
            const isActive = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => onSelectCategory(cat.id)}
                className={`px-4 py-2 text-xs tracking-wider font-medium whitespace-nowrap uppercase transition-colors duration-200 cursor-pointer ${
                  isActive
                    ? 'bg-[#473C38] text-white'
                    : 'bg-white/80 text-[#473C38] hover:bg-[#E3CAAB]/40 border border-[#E3CAAB]/60'
                }`}
              >
                {cat.name}
              </button>
            );
          })}
        </div>

        {/* Product Grid */}
        {filteredProducts.length === 0 ? (
          <div className="py-20 text-center bg-white/50 border border-[#E3CAAB]/40 mt-8">
            <p className="font-serif text-xl text-[#473C38]">No matching furniture pieces found</p>
            <p className="text-xs text-[#473C38]/60 mt-2">Try clearing your search or switching categories.</p>
            <button
              onClick={() => {
                onSelectCategory('all');
                setSearchFilter('');
              }}
              className="mt-4 px-5 py-2 bg-[#473C38] text-white text-xs font-semibold tracking-wider cursor-pointer hover:bg-[#B08A62] transition-colors"
            >
              SHOW ALL FURNITURE
            </button>
          </div>
        ) : (
          <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredProducts.map((product) => {
              const inWishlist = isInWishlist(product.id);
              const isJustAdded = addedNotice === product.id;
              const catObj = categories.find((c) => c.id === product.categoryId);
              const categoryName = catObj ? catObj.name : product.categoryLabel || product.categoryId;

              return (
                <div
                  key={product.id}
                  className="group bg-white border border-[#E3CAAB]/50 flex flex-col justify-between transition-all duration-300 hover:shadow-lg hover:border-[#B08A62]/60"
                >
                  {/* Top Image Showcase */}
                  <div className="relative aspect-[4/3] bg-[#F7F3EE] overflow-hidden">
                    <img
                      src={(product.images && product.images[0]) || product.image}
                      alt={product.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover object-center transition-transform duration-500 group-hover:scale-105"
                    />

                    {/* Wishlist Button */}
                    <button
                      onClick={() => onToggleWishlist(product)}
                      aria-label={inWishlist ? 'Remove from wishlist' : 'Add to wishlist'}
                      className={`absolute top-3 right-3 p-2 bg-white/90 backdrop-blur-sm transition-colors cursor-pointer ${
                        inWishlist ? 'text-red-500' : 'text-[#473C38] hover:text-[#B08A62]'
                      }`}
                    >
                      <Heart className={`w-4 h-4 ${inWishlist ? 'fill-current' : ''}`} />
                    </button>

                    {/* Quick View Button overlay */}
                    <div className="absolute inset-x-0 bottom-0 p-3 bg-gradient-to-t from-black/50 to-transparent flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <button
                        onClick={() => onOpenQuickView(product)}
                        className="px-4 py-2 bg-white text-[#473C38] hover:bg-[#473C38] hover:text-white text-xs font-semibold tracking-wider flex items-center gap-1.5 transition-colors shadow-md cursor-pointer"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>QUICK VIEW</span>
                      </button>
                    </div>

                    {/* Badge if featured / new */}
                    {product.featured && (
                      <span className="absolute top-3 left-3 bg-[#473C38] text-white text-[10px] tracking-wider font-semibold px-2.5 py-1">
                        BESTSELLER
                      </span>
                    )}
                    {product.isNew && !product.featured && (
                      <span className="absolute top-3 left-3 bg-[#B08A62] text-white text-[10px] tracking-wider font-semibold px-2.5 py-1">
                        NEW DESIGN
                      </span>
                    )}
                  </div>

                  {/* Body Content */}
                  <div className="p-5 flex-1 flex flex-col justify-between">
                    <div>
                      {/* Quiet Category Metadata */}
                      <div className="flex items-center gap-2 text-[11px] text-[#B08A62] tracking-[0.14em] font-semibold uppercase">
                        <span>{categoryName}</span>
                        {product.dimensions && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="text-[#473C38]/60 font-normal">{product.dimensions.split('(')[0]}</span>
                          </>
                        )}
                      </div>

                      {/* Product Title */}
                      <h3
                        onClick={() => onOpenQuickView(product)}
                        className="mt-2 text-lg font-serif font-medium text-[#292522] hover:text-[#B08A62] transition-colors cursor-pointer"
                      >
                        {product.name}
                      </h3>

                      {/* Materials Brief */}
                      <p className="mt-1 text-xs text-[#473C38]/75 line-clamp-1">
                        {product.material || product.materials}
                      </p>
                    </div>

                    {/* Price and Action Bar */}
                    <div className="mt-5 pt-4 border-t border-[#E3CAAB]/40">
                      <div className="flex items-baseline justify-between">
                        <div>
                          <div className="flex items-baseline gap-2">
                            <span className="text-xl font-medium font-serif text-[#292522] tabular-nums">
                              ₹{product.price.toLocaleString('en-IN')}
                            </span>
                            {(product.discountPrice || product.originalPrice) && (
                              <span className="text-xs text-[#473C38]/50 line-through tabular-nums">
                                ₹{(product.discountPrice || product.originalPrice)!.toLocaleString('en-IN')}
                              </span>
                            )}
                          </div>
                          <span className="text-[10px] text-[#B08A62] tracking-wider uppercase font-semibold">
                            Direct Manufacturer Price
                          </span>
                        </div>

                        {/* WhatsApp Quick Order Link */}
                        <a
                          href={getWhatsAppProductUrl(product)}
                          target="_blank"
                          rel="noreferrer"
                          title="Chat & Order on WhatsApp"
                          className="p-2 border border-[#473C38]/30 text-[#473C38] hover:bg-[#473C38] hover:text-white transition-colors"
                        >
                          <MessageCircle className="w-4 h-4" />
                        </a>
                      </div>

                      {/* Add to Bag Button */}
                      <button
                        onClick={() => handleQuickAdd(product)}
                        className={`mt-3 w-full py-2.5 text-xs font-semibold tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer ${
                          isJustAdded
                            ? 'bg-emerald-800 text-white'
                            : 'bg-[#473C38] text-white hover:bg-[#B08A62]'
                        }`}
                      >
                        {isJustAdded ? (
                          <>
                            <Check className="w-4 h-4" />
                            <span>ADDED TO BAG</span>
                          </>
                        ) : (
                          <>
                            <ShoppingBag className="w-3.5 h-3.5" />
                            <span>ADD TO BAG</span>
                          </>
                        )}
                      </button>
                    </div>

                  </div>
                </div>
              );
            })}
          </div>
        )}

      </div>
    </section>
  );
}
