import { useState } from 'react';
import { X, Trash2, ShoppingBag, ArrowRight, MessageCircle, Truck, Check } from 'lucide-react';
import { CartItem } from '../types/furniture';
import { useData } from '../context/DataContext';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onRemoveItem: (productId: string) => void;
  onClearCart: () => void;
}

export default function CartDrawer({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
}: CartDrawerProps) {
  const { settings, addEnquiry } = useData();
  const [checkoutStep, setCheckoutStep] = useState<'cart' | 'details'>('cart');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [orderNotes, setOrderNotes] = useState('');

  if (!isOpen) return null;

  const subtotal = items.reduce((sum, item) => sum + item.product.price * item.quantity, 0);

  const handleSendWhatsAppOrder = (e: React.FormEvent) => {
    e.preventDefault();

    const itemsSummary = items
      .map(
        (item) =>
          `${item.product.name} (Qty: ${item.quantity}, Finish: ${item.selectedFinish || 'Standard'}, ₹${(
            item.product.price * item.quantity
          ).toLocaleString('en-IN')})`
      )
      .join('; ');

    // Save to unified database
    addEnquiry({
      customerName,
      phone: customerPhone,
      email: '',
      type: 'Get Quote',
      message: `[Cart Order - Total ₹${subtotal.toLocaleString('en-IN')}] Delivery Address: ${deliveryAddress}. Items: ${itemsSummary}. Notes: ${orderNotes || 'None'}`,
    });

    let itemsText = items
      .map(
        (item, index) =>
          `${index + 1}. *${item.product.name}*\n` +
          `   - Finish: ${item.selectedFinish || 'Standard'}\n` +
          `   - Qty: ${item.quantity}\n` +
          `   - Price: ₹${(item.product.price * item.quantity).toLocaleString('en-IN')}`
      )
      .join('\n\n');

    const message = encodeURIComponent(
      `*NEW FURNITURE ORDER - ${settings.businessName || 'AFURN'} AHMEDABAD*\n` +
      `------------------------------------------\n` +
      `*Customer Name:* ${customerName}\n` +
      `*Phone Number:* ${customerPhone}\n` +
      `*Delivery Address:* ${deliveryAddress}\n` +
      (orderNotes ? `*Special Notes:* ${orderNotes}\n` : '') +
      `------------------------------------------\n` +
      `*ORDER ITEMS:*\n\n` +
      `${itemsText}\n\n` +
      `------------------------------------------\n` +
      `*TOTAL ORDER VALUE:* ₹${subtotal.toLocaleString('en-IN')}\n` +
      `*Delivery City:* ${settings.city || 'Ahmedabad'}, Gujarat\n` +
      `------------------------------------------\n` +
      `Please confirm stock availability, delivery schedule, and payment details.`
    );

    window.open(`https://wa.me/91${settings.phone}?text=${message}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/60 backdrop-blur-sm animate-fade-in">
      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-[#F7F3EE] shadow-2xl flex flex-col justify-between border-l border-[#E3CAAB]">
          
          {/* Header */}
          <div className="p-6 border-b border-[#E3CAAB]/60 flex items-center justify-between bg-white">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-[#473C38]" />
              <h2 className="font-serif text-xl font-medium text-[#292522]">
                Your Shopping Bag
              </h2>
              <span className="text-xs text-[#B08A62] font-semibold tabular-nums">
                ({items.reduce((acc, i) => acc + i.quantity, 0)} items)
              </span>
            </div>
            <button
              onClick={onClose}
              aria-label="Close cart"
              className="p-2 text-[#473C38] hover:text-[#B08A62] transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Body Content */}
          <div className="p-6 flex-1 overflow-y-auto">
            {items.length === 0 ? (
              <div className="py-20 text-center">
                <ShoppingBag className="w-12 h-12 text-[#E3CAAB] mx-auto stroke-[1.2]" />
                <h3 className="font-serif text-lg text-[#473C38] mt-4">Your bag is currently empty</h3>
                <p className="text-xs text-[#473C38]/60 mt-1 max-w-xs mx-auto">
                  Explore our handcrafted sofas, solid teak dining suites, and swings.
                </p>
                <button
                  onClick={onClose}
                  className="mt-6 px-6 py-2.5 bg-[#473C38] text-white text-xs font-semibold tracking-wider hover:bg-[#B08A62] transition-colors cursor-pointer"
                >
                  START EXPLORING
                </button>
              </div>
            ) : checkoutStep === 'cart' ? (
              <div className="space-y-4">
                {items.map((item) => (
                  <div
                    key={`${item.product.id}-${item.selectedFinish}`}
                    className="p-3 bg-white border border-[#E3CAAB]/60 flex gap-4 items-center"
                  >
                    <img
                      src={(item.product.images && item.product.images[0]) || item.product.image}
                      alt={item.product.name}
                      referrerPolicy="no-referrer"
                      className="w-16 h-16 object-cover bg-[#F7F3EE] shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <h4 className="text-xs font-serif font-medium text-[#292522] truncate">
                        {item.product.name}
                      </h4>
                      {item.selectedFinish && (
                        <p className="text-[10px] text-[#B08A62] font-medium">
                          Finish: {item.selectedFinish}
                        </p>
                      )}
                      <p className="text-xs font-semibold text-[#473C38] mt-1 tabular-nums">
                        ₹{(item.product.price * item.quantity).toLocaleString('en-IN')}
                      </p>

                      <div className="mt-2 flex items-center justify-between">
                        <div className="flex items-center border border-[#E3CAAB] bg-[#F7F3EE]">
                          <button
                            onClick={() => onUpdateQuantity(item.product.id, item.quantity - 1)}
                            className="px-2 py-0.5 text-xs text-[#473C38] hover:bg-[#E3CAAB]/30 cursor-pointer"
                          >
                            -
                          </button>
                          <span className="px-2 text-xs font-semibold tabular-nums text-[#292522]">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => onUpdateQuantity(item.product.id, item.quantity + 1)}
                            className="px-2 py-0.5 text-xs text-[#473C38] hover:bg-[#E3CAAB]/30 cursor-pointer"
                          >
                            +
                          </button>
                        </div>

                        <button
                          onClick={() => onRemoveItem(item.product.id)}
                          className="text-[#473C38]/40 hover:text-red-600 transition-colors p-1"
                          title="Remove item"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}

                <div className="pt-2 flex justify-end">
                  <button
                    onClick={onClearCart}
                    className="text-[11px] text-[#473C38]/60 hover:text-red-600 underline cursor-pointer"
                  >
                    Clear shopping bag
                  </button>
                </div>
              </div>
            ) : (
              /* Checkout Form for WhatsApp Order */
              <form id="whatsapp-order-form" onSubmit={handleSendWhatsAppOrder} className="space-y-4">
                <div className="bg-[#E3CAAB]/30 p-3 text-xs text-[#473C38] border border-[#E3CAAB]">
                  Direct Manufacturer WhatsApp Checkout • No middleman payment gateway fees.
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                    Your Full Name: *
                  </label>
                  <input
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="e.g. Priyesh Patel"
                    className="w-full px-3 py-2 bg-white border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                    WhatsApp Phone Number: *
                  </label>
                  <input
                    type="tel"
                    required
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    placeholder="e.g. 9825000000"
                    className="w-full px-3 py-2 bg-white border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                    Delivery Address in Ahmedabad: *
                  </label>
                  <textarea
                    rows={2}
                    required
                    value={deliveryAddress}
                    onChange={(e) => setDeliveryAddress(e.target.value)}
                    placeholder="House/Flat No., Society/Apartment, Area, Pincode (e.g. Bodakdev, Ahmedabad - 380054)"
                    className="w-full px-3 py-2 bg-white border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                    Special Customization / Delivery Notes:
                  </label>
                  <input
                    type="text"
                    value={orderNotes}
                    onChange={(e) => setOrderNotes(e.target.value)}
                    placeholder="e.g. 3rd floor delivery, lift available, specific date"
                    className="w-full px-3 py-2 bg-white border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
                  />
                </div>

                <button
                  type="button"
                  onClick={() => setCheckoutStep('cart')}
                  className="text-xs text-[#473C38] underline hover:text-[#B08A62] cursor-pointer"
                >
                  ← Back to cart items
                </button>
              </form>
            )}
          </div>

          {/* Footer Subtotal & Action */}
          {items.length > 0 && (
            <div className="p-6 bg-white border-t border-[#E3CAAB]/60 space-y-3">
              <div className="flex items-center justify-between text-xs text-[#473C38]/80">
                <span className="flex items-center gap-1.5">
                  <Truck className="w-3.5 h-3.5 text-[#B08A62]" />
                  <span>Delivery in {settings.city || 'Ahmedabad'}:</span>
                </span>
                <span className="font-semibold text-emerald-700 uppercase">
                  Included / Free Setup
                </span>
              </div>

              <div className="flex items-baseline justify-between pt-2 border-t border-[#E3CAAB]/30">
                <span className="text-sm font-semibold uppercase tracking-wider text-[#473C38]">
                  Total Value:
                </span>
                <span className="text-2xl font-serif font-bold text-[#292522] tabular-nums">
                  ₹{subtotal.toLocaleString('en-IN')}
                </span>
              </div>

              {checkoutStep === 'cart' ? (
                <button
                  onClick={() => setCheckoutStep('details')}
                  className="w-full py-3.5 bg-[#473C38] text-white hover:bg-[#B08A62] text-xs font-semibold tracking-wider flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  <span>PROCEED TO WHATSAPP CHECKOUT</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              ) : (
                <button
                  type="submit"
                  form="whatsapp-order-form"
                  className="w-full py-3.5 bg-[#25D366] text-white hover:bg-emerald-600 text-xs font-semibold tracking-wider flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-md"
                >
                  <MessageCircle className="w-4 h-4 fill-current" />
                  <span>CONFIRM & PLACE ORDER ON WHATSAPP</span>
                </button>
              )}
            </div>
          )}

        </div>
      </div>
    </div>
  );
}
