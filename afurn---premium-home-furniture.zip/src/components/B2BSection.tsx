import { Building, Coffee, Compass, Hotel, Briefcase, CheckCircle, ArrowRight } from 'lucide-react';
import { useData } from '../context/DataContext';

export default function B2BSection() {
  const { settings } = useData();

  if (settings.sections && settings.sections.b2bSection === false) {
    return null;
  }

  const industries = [
    {
      icon: Compass,
      title: 'Architects & Interior Designers',
      desc: 'White-glove CAD drawing execution, timber & upholstery swatch kits delivered to your studio, and transparent trade pricing.'
    },
    {
      icon: Coffee,
      title: 'Restaurants & Cafes',
      desc: 'High-traffic commercial seating, spill-resistant PU coatings, solid teak dining tables, and heavy-duty powder coated bar stools.'
    },
    {
      icon: Hotel,
      title: 'Hotels & Luxury Resorts',
      desc: 'Turnkey bedroom suites, grand lobby modular sectionals, outdoor wooden swings, and luggage credenzas built to hospitality specs.'
    },
    {
      icon: Briefcase,
      title: 'Offices & Co-Working Spaces',
      desc: 'Acoustic lounge booths, solid wood board room tables, ergonomic work desks, and reception statement pieces.'
    }
  ];

  return (
    <section id="b2b" className="py-16 sm:py-24 bg-[#E3CAAB]/20 border-t border-[#E3CAAB]/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          
          {/* Left Column: Heading & Value Prop */}
          <div className="lg:col-span-5">
            <span className="text-[11px] tracking-[0.25em] font-semibold text-[#B08A62] uppercase">
              B2B & TRADE PARTNERSHIPS
            </span>
            <h2 className="text-3xl sm:text-4xl font-serif font-medium text-[#292522] tracking-tight mt-1">
              Bulk Manufacturing for Commercial Spaces
            </h2>
            <p className="mt-4 text-sm text-[#473C38]/85 leading-relaxed font-normal">
              With over 15 years as a premier furniture manufacturer in Danilimda, Ahmedabad, {settings.businessName || 'AFURN'} powers luxury residences, boutique hospitality projects, and thriving F&B establishments across Gujarat.
            </p>

            <div className="mt-6 space-y-3">
              <div className="flex items-start gap-2.5 text-xs text-[#473C38]">
                <CheckCircle className="w-4 h-4 text-[#B08A62] shrink-0 mt-0.5" />
                <span><strong>Direct Manufacturer Pricing:</strong> Save 30-40% compared to third-party retail distributors.</span>
              </div>
              <div className="flex items-start gap-2.5 text-xs text-[#473C38]">
                <CheckCircle className="w-4 h-4 text-[#B08A62] shrink-0 mt-0.5" />
                <span><strong>Heavy-Duty Commercial Grade:</strong> Reinforced joints, commercial spring systems, and kiln-dried wood.</span>
              </div>
              <div className="flex items-start gap-2.5 text-xs text-[#473C38]">
                <CheckCircle className="w-4 h-4 text-[#B08A62] shrink-0 mt-0.5" />
                <span><strong>On-Time Milestone Delivery:</strong> Coordinated dispatch and direct on-site installation in Ahmedabad.</span>
              </div>
            </div>

            <div className="mt-8 flex flex-col sm:flex-row gap-3">
              <a
                href={settings.whatsappUrl || `https://wa.me/91${settings.phone}`}
                target="_blank"
                rel="noreferrer"
                className="px-6 py-3 bg-[#473C38] text-white hover:bg-[#B08A62] text-xs font-semibold tracking-wider flex items-center justify-center gap-2 transition-colors"
              >
                <span>DISCUSS BULK PROJECT</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </a>
              <a
                href={`tel:${settings.phone}`}
                className="px-6 py-3 border border-[#473C38] text-[#473C38] hover:bg-white text-xs font-semibold tracking-wider flex items-center justify-center gap-2 transition-colors"
              >
                <span>CALL: {settings.displayPhone || settings.phone}</span>
              </a>
            </div>
          </div>

          {/* Right Column: 4 Segment Cards */}
          <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-5">
            {industries.map((ind) => {
              const Icon = ind.icon;
              return (
                <div
                  key={ind.title}
                  className="bg-white p-6 border border-[#E3CAAB] shadow-sm hover:border-[#B08A62] transition-colors"
                >
                  <div className="w-10 h-10 bg-[#F7F3EE] flex items-center justify-center text-[#B08A62] mb-4">
                    <Icon className="w-5 h-5 stroke-[1.8]" />
                  </div>
                  <h3 className="font-serif text-lg font-medium text-[#292522]">
                    {ind.title}
                  </h3>
                  <p className="mt-2 text-xs text-[#473C38]/75 leading-relaxed font-normal">
                    {ind.desc}
                  </p>
                </div>
              );
            })}
          </div>

        </div>

      </div>
    </section>
  );
}
