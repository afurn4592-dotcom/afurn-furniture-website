import { useState, useEffect } from 'react';
import { Search, Heart, ShoppingBag, Menu, X, MessageCircle, Phone } from 'lucide-react';
import { useData } from '../context/DataContext';

interface HeaderProps {
  cartCount: number;
  wishlistCount: number;
  onOpenCart: () => void;
  onOpenWishlist: () => void;
  onOpenSearch: () => void;
}

export default function Header({
  cartCount,
  wishlistCount,
  onOpenCart,
  onOpenWishlist,
  onOpenSearch
}: HeaderProps) {
  const { settings } = useData();
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 24);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks =
    settings.navigation && settings.navigation.length > 0
      ? settings.navigation.filter((item) => item.isVisible)
      : [
          { label: 'HOME', href: '#home' },
          { label: 'SHOP', href: '#shop' },
          { label: 'CATEGORIES', href: '#categories' },
          { label: 'ABOUT US', href: '#about' },
          { label: 'CUSTOM FURNITURE', href: '#custom' },
          { label: 'GALLERY', href: '#gallery' },
          { label: 'CONTACT', href: '#contact' },
        ];

  const handleNavClick = (href: string) => {
    setMobileMenuOpen(false);
    if (href.startsWith('#')) {
      const element = document.querySelector(href);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    } else {
      window.location.href = href;
    }
  };

  return (
    <>
      <header
        className={`sticky top-0 z-40 w-full transition-all duration-300 ${
          isScrolled
            ? 'bg-[#F7F3EE]/95 backdrop-blur-md py-3 shadow-[0_4px_20px_rgba(71,60,56,0.06)] border-b border-[#E3CAAB]/50'
            : 'bg-[#F7F3EE] py-5 border-b border-[#E3CAAB]/30'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            {/* Zone 1: Single text element Brand Wordmark or Image Logo */}
            {settings.customization?.logoType === 'image' && settings.customization?.logoImage ? (
              <a href="#home" className="inline-block py-1">
                <img
                  src={settings.customization.logoImage}
                  alt={settings.businessName || 'AFURN'}
                  className="h-8 sm:h-10 object-contain"
                />
              </a>
            ) : (
              <a
                href="#home"
                className="text-2xl sm:text-3xl font-serif tracking-[0.2em] font-semibold text-[#473C38] hover:text-[#B08A62] transition-colors"
                style={{
                  fontFamily: settings.customization?.headingFont
                    ? `"${settings.customization.headingFont}", Georgia, serif`
                    : undefined,
                  color: settings.customization?.primaryColor,
                }}
              >
                {settings.customization?.logoText || settings.businessName || 'AFURN'}
              </a>
            )}

            {/* Zone 2: Navigation Links (Desktop) */}
            <nav className="hidden lg:flex items-center space-x-7 text-[13px] tracking-[0.14em] font-medium text-[#292522]">
              {navLinks.map((link) => (
                <button
                  key={link.label}
                  onClick={() => handleNavClick(link.href)}
                  className="hover:text-[#B08A62] transition-colors relative py-1 group cursor-pointer"
                >
                  {link.label}
                  <span className="absolute bottom-0 left-0 w-0 h-[1.5px] bg-[#B08A62] transition-all duration-200 group-hover:w-full" />
                </button>
              ))}
            </nav>

            {/* Zone 3: Interactive Affordances */}
            <div className="flex items-center space-x-3 sm:space-x-5">
              {/* Search Button */}
              <button
                onClick={onOpenSearch}
                aria-label="Search furniture catalog"
                className="p-2 text-[#473C38] hover:text-[#B08A62] transition-colors cursor-pointer"
              >
                <Search className="w-5 h-5 stroke-[1.8]" />
              </button>

              {/* Wishlist Button */}
              <button
                onClick={onOpenWishlist}
                aria-label="View wishlist"
                className="relative p-2 text-[#473C38] hover:text-[#B08A62] transition-colors cursor-pointer"
              >
                <Heart className="w-5 h-5 stroke-[1.8]" />
                {wishlistCount > 0 && (
                  <span className="absolute top-1 right-1 w-4 h-4 bg-[#B08A62] text-white text-[10px] font-bold rounded-full flex items-center justify-center tabular-nums">
                    {wishlistCount}
                  </span>
                )}
              </button>

              {/* Cart / Bag Button */}
              <button
                onClick={onOpenCart}
                aria-label="Shopping bag"
                className="relative p-2 text-[#473C38] hover:text-[#B08A62] transition-colors cursor-pointer"
              >
                <ShoppingBag className="w-5 h-5 stroke-[1.8]" />
                {cartCount > 0 && (
                  <span className="absolute top-1 right-1 w-4 h-4 bg-[#473C38] text-white text-[10px] font-bold rounded-full flex items-center justify-center tabular-nums">
                    {cartCount}
                  </span>
                )}
              </button>

              {/* WhatsApp Button (Direct Contact) */}
              <a
                href={settings.whatsappUrl || `https://wa.me/91${settings.phone}`}
                target="_blank"
                rel="noreferrer"
                className="hidden sm:inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-[#473C38] text-[#F7F3EE] hover:bg-[#B08A62] text-xs font-semibold tracking-wider rounded-none transition-colors duration-200"
              >
                <MessageCircle className="w-3.5 h-3.5 fill-current" />
                <span>WHATSAPP</span>
              </a>

              {/* Mobile Hamburger Menu Toggle */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                aria-label="Open mobile menu"
                className="lg:hidden p-2 text-[#473C38] hover:text-[#B08A62] transition-colors cursor-pointer"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden bg-black/40 backdrop-blur-sm animate-fade-in">
          <div className="fixed inset-y-0 right-0 w-full max-w-xs bg-[#F7F3EE] p-6 shadow-2xl flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between pb-6 border-b border-[#E3CAAB]/60">
                <span className="text-2xl font-serif tracking-[0.2em] font-semibold text-[#473C38]">
                  {settings.businessName || 'AFURN'}
                </span>
                <button
                  onClick={() => setMobileMenuOpen(false)}
                  aria-label="Close menu"
                  className="p-2 text-[#473C38]"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <nav className="mt-8 flex flex-col space-y-5 text-sm tracking-[0.14em] font-medium text-[#292522]">
                {navLinks.map((link) => (
                  <button
                    key={link.label}
                    onClick={() => handleNavClick(link.href)}
                    className="text-left py-1 hover:text-[#B08A62] transition-colors border-b border-[#E3CAAB]/20"
                  >
                    {link.label}
                  </button>
                ))}
              </nav>
            </div>

            <div className="pt-6 border-t border-[#E3CAAB]/60 space-y-3">
              <a
                href={settings.whatsappUrl || `https://wa.me/91${settings.phone}`}
                target="_blank"
                rel="noreferrer"
                className="w-full flex items-center justify-center gap-2 py-3 bg-[#473C38] text-white text-xs font-semibold tracking-wider hover:bg-[#B08A62] transition-colors"
              >
                <MessageCircle className="w-4 h-4" />
                <span>CHAT ON WHATSAPP</span>
              </a>
              <a
                href={`tel:${settings.phone}`}
                className="w-full flex items-center justify-center gap-2 py-2.5 border border-[#473C38] text-[#473C38] text-xs font-semibold tracking-wider hover:bg-[#E3CAAB]/30 transition-colors"
              >
                <Phone className="w-4 h-4" />
                <span>CALL: {settings.displayPhone || settings.phone}</span>
              </a>
              <p className="text-[11px] text-[#473C38]/70 text-center pt-1">
                {settings.city || 'Ahmedabad'}, {settings.state || 'Gujarat'} • {settings.experience}
              </p>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
