import React, { useState, useEffect } from 'react';
import {
  X,
  Check,
  ShoppingBag,
  MessageCircle,
  Shield,
  Truck,
  Sparkles,
  Ruler,
  ChevronLeft,
  ChevronRight,
  ZoomIn,
  ExternalLink,
  Star,
  Maximize2
} from 'lucide-react';
import { Product } from '../types/furniture';
import { useData } from '../context/DataContext';
import { Link } from 'react-router-dom';

interface ProductQuickViewModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product, finish: string, quantity: number) => void;
}

export default function ProductQuickViewModal({
  product,
  onClose,
  onAddToCart,
}: ProductQuickViewModalProps) {
  const { settings, categories } = useData();

  // Active image in thumbnail gallery
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  // Fullscreen Lightbox state
  const [isLightboxOpen, setIsLightboxOpen] = useState(false);
  // Zoom mode in lightbox
  const [isZoomed, setIsZoomed] = useState(false);

  // Form states
  const colorOptions =
    product?.colors && product.colors.length > 0
      ? product.colors
      : product?.finishOptions || ['Natural Teak', 'Dark Walnut'];
  const [selectedFinish, setSelectedFinish] = useState(colorOptions[0] || 'Natural Teak');
  const [quantity, setQuantity] = useState(1);
  const [addedSuccess, setAddedSuccess] = useState(false);

  // Reset active image index whenever a new product is selected
  useEffect(() => {
    setActiveImageIndex(0);
    setIsLightboxOpen(false);
    setIsZoomed(false);
    if (product) {
      const colors =
        product.colors && product.colors.length > 0
          ? product.colors
          : product.finishOptions || ['Natural Teak'];
      setSelectedFinish(colors[0] || 'Natural Teak');
      setQuantity(1);
    }
  }, [product]);

  // Keyboard navigation for lightbox
  useEffect(() => {
    if (!isLightboxOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setIsLightboxOpen(false);
      } else if (e.key === 'ArrowRight') {
        handleNextImage();
      } else if (e.key === 'ArrowLeft') {
        handlePrevImage();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isLightboxOpen, activeImageIndex, product]);

  if (!product) return null;

  // Resolve all images: gallery array takes precedence, then product.image
  const allImages: string[] = [];
  if (product.images && product.images.length > 0) {
    allImages.push(...product.images);
  } else if (product.image) {
    allImages.push(product.image);
  }

  // Fallback if empty
  if (allImages.length === 0) {
    allImages.push('https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=1200&q=80');
  }

  const currentMainImage = allImages[activeImageIndex] || allImages[0];

  const handlePrevImage = () => {
    setActiveImageIndex((prev) => (prev - 1 + allImages.length) % allImages.length);
  };

  const handleNextImage = () => {
    setActiveImageIndex((prev) => (prev + 1) % allImages.length);
  };

  const catObj = categories.find((c) => c.id === product.categoryId);
  const categoryName = catObj ? catObj.name : product.categoryLabel || product.categoryId;

  const handleAdd = () => {
    onAddToCart(product, selectedFinish, quantity);
    setAddedSuccess(true);
    setTimeout(() => {
      setAddedSuccess(false);
      onClose();
    }, 1200);
  };

  const getWhatsAppMessageUrl = () => {
    const message = encodeURIComponent(
      `Hello ${settings.businessName || 'AFURN'}, I want to order/inquire about the "${product.name}" with "${selectedFinish}" finish (Quantity: ${quantity}, Price: ₹${(
        product.price * quantity
      ).toLocaleString('en-IN')}). Direct from Ahmedabad factory.`
    );
    return `https://wa.me/91${settings.phone}?text=${message}`;
  };

  return (
    <>
      <div className="fixed inset-0 z-50 overflow-y-auto bg-black/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 animate-fade-in">
        <div className="relative w-full max-w-5xl bg-[#F7F3EE] shadow-2xl border border-[#E3CAAB] overflow-hidden my-6">
          
          {/* Close Button */}
          <button
            onClick={onClose}
            aria-label="Close modal"
            className="absolute top-4 right-4 z-20 p-2.5 bg-white/90 hover:bg-white text-[#473C38] transition-colors cursor-pointer border border-[#E3CAAB] shadow-sm hover:text-black"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-0">
            
            {/* ==================================================== */}
            {/* Left: Product Images Gallery (Large Image + Thumbs) */}
            {/* ==================================================== */}
            <div className="lg:col-span-7 bg-white p-4 sm:p-6 flex flex-col justify-between border-b lg:border-b-0 lg:border-r border-[#E3CAAB]">
              <div>
                {/* Large Main Product Image Container */}
                <div className="relative aspect-[4/3] sm:aspect-[16/11] bg-[#F7F3EE] overflow-hidden group border border-[#E3CAAB]/60">
                  <img
                    src={currentMainImage}
                    alt={`${product.name} - Image ${activeImageIndex + 1}`}
                    referrerPolicy="no-referrer"
                    onClick={() => setIsLightboxOpen(true)}
                    className="w-full h-full object-cover object-center cursor-zoom-in transition-transform duration-300 group-hover:scale-[1.02]"
                  />

                  {/* Main Image Badge on index 0 */}
                  {activeImageIndex === 0 && (
                    <div className="absolute top-3 left-3 bg-[#B08A62] text-white text-[10px] font-bold uppercase tracking-wider px-2 py-1 flex items-center gap-1 shadow-sm">
                      <Star className="w-3 h-3 fill-white" />
                      <span>MAIN IMAGE</span>
                    </div>
                  )}

                  {/* Image Counter Badge if multiple images */}
                  {allImages.length > 1 && (
                    <div className="absolute top-3 right-3 bg-black/70 backdrop-blur-xs text-white text-[11px] font-mono px-2 py-0.5 shadow-sm">
                      {activeImageIndex + 1} / {allImages.length}
                    </div>
                  )}

                  {/* Previous / Next Arrow Buttons */}
                  {allImages.length > 1 && (
                    <>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handlePrevImage();
                        }}
                        aria-label="Previous product image"
                        className="absolute left-2.5 top-1/2 -translate-y-1/2 p-2 bg-white/90 hover:bg-white text-[#473C38] border border-[#E3CAAB] shadow-md transition-transform active:scale-95 cursor-pointer opacity-90 group-hover:opacity-100"
                      >
                        <ChevronLeft className="w-4 h-4 stroke-[2.2]" />
                      </button>

                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleNextImage();
                        }}
                        aria-label="Next product image"
                        className="absolute right-2.5 top-1/2 -translate-y-1/2 p-2 bg-white/90 hover:bg-white text-[#473C38] border border-[#E3CAAB] shadow-md transition-transform active:scale-95 cursor-pointer opacity-90 group-hover:opacity-100"
                      >
                        <ChevronRight className="w-4 h-4 stroke-[2.2]" />
                      </button>
                    </>
                  )}

                  {/* Zoom / Lightbox Trigger Button */}
                  <button
                    type="button"
                    onClick={() => setIsLightboxOpen(true)}
                    className="absolute bottom-3 right-3 px-2.5 py-1.5 bg-black/75 hover:bg-black text-white text-[11px] font-medium flex items-center gap-1.5 shadow-md transition-colors cursor-pointer"
                    title="Click to expand fullscreen"
                  >
                    <ZoomIn className="w-3.5 h-3.5" />
                    <span>Zoom / Lightbox</span>
                  </button>

                  {/* Factory direct tag */}
                  <div className="absolute bottom-3 left-3 bg-white/95 px-2.5 py-1 border border-[#E3CAAB] text-[9px] tracking-widest uppercase font-semibold text-[#B08A62]">
                    AHMEDABAD FACTORY DIRECT
                  </div>
                </div>

                {/* ==================================================== */}
                {/* Thumbnail Gallery Row Below Main Image */}
                {/* ==================================================== */}
                {allImages.length > 1 && (
                  <div className="mt-3">
                    <div className="flex items-center justify-between text-[11px] text-[#473C38]/70 mb-1.5 font-medium">
                      <span>PRODUCT GALLERY ({allImages.length} IMAGES)</span>
                      <span className="text-[10px]">Click thumbnail to view</span>
                    </div>

                    <div className="flex items-center gap-2 overflow-x-auto pb-1.5 scrollbar-thin">
                      {allImages.map((imgUrl, idx) => {
                        const isSelected = idx === activeImageIndex;
                        return (
                          <button
                            key={`${imgUrl}-${idx}`}
                            type="button"
                            onClick={() => setActiveImageIndex(idx)}
                            aria-label={`View image ${idx + 1}`}
                            className={`relative shrink-0 w-16 h-16 sm:w-20 sm:h-20 bg-[#F7F3EE] overflow-hidden border-2 transition-all cursor-pointer ${
                              isSelected
                                ? 'border-[#B08A62] ring-2 ring-[#B08A62]/30 scale-[1.02]'
                                : 'border-[#E3CAAB] hover:border-[#473C38] opacity-75 hover:opacity-100'
                            }`}
                          >
                            <img
                              src={imgUrl}
                              alt={`Thumbnail ${idx + 1}`}
                              className="w-full h-full object-cover"
                            />
                            {idx === 0 && (
                              <span className="absolute bottom-0 inset-x-0 bg-[#B08A62] text-white text-[8px] font-bold text-center py-0.2 uppercase">
                                MAIN
                              </span>
                            )}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>

              {/* View Full Product Page Link */}
              <div className="mt-4 pt-3 border-t border-[#E3CAAB]/50 flex items-center justify-between text-xs text-[#473C38]">
                <Link
                  to={`/product/${product.id}`}
                  onClick={onClose}
                  className="inline-flex items-center gap-1.5 text-[#B08A62] hover:text-[#473C38] font-semibold underline underline-offset-4 cursor-pointer"
                >
                  <span>Open Full Dedicated Product Page</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </Link>
                <span className="text-[11px] text-[#473C38]/60">SKU: {product.sku}</span>
              </div>
            </div>

            {/* ==================================================== */}
            {/* Right: Product Details, Specs & CTAs */}
            {/* ==================================================== */}
            <div className="lg:col-span-5 p-6 sm:p-7 flex flex-col justify-between max-h-[85vh] overflow-y-auto">
              <div>
                {/* Category & Status */}
                <div className="flex items-center justify-between text-xs font-semibold uppercase tracking-[0.16em] text-[#B08A62]">
                  <span>{categoryName}</span>
                  <span
                    className={`px-2 py-0.5 text-[10px] tracking-wider ${
                      product.availability === 'Out of Stock'
                        ? 'bg-rose-100 text-rose-800'
                        : product.availability === 'Made to Order'
                        ? 'bg-amber-100 text-amber-900'
                        : 'bg-emerald-100 text-emerald-800'
                    }`}
                  >
                    {product.availability || 'In Stock'}
                  </span>
                </div>

                {/* Title */}
                <h2 className="text-xl sm:text-2xl font-serif font-medium text-[#292522] mt-1.5 leading-snug">
                  {product.name}
                </h2>

                {/* Price Block */}
                <div className="mt-3 flex items-baseline gap-3">
                  <span className="text-2xl font-serif font-semibold text-[#473C38] tabular-nums">
                    ₹{product.price.toLocaleString('en-IN')}
                  </span>
                  {(product.discountPrice || product.originalPrice) && (
                    <span className="text-sm text-[#473C38]/50 line-through tabular-nums">
                      ₹{(product.discountPrice || product.originalPrice)!.toLocaleString('en-IN')}
                    </span>
                  )}
                  <span className="text-[11px] bg-[#E3CAAB]/40 text-[#473C38] px-2 py-0.5 font-medium">
                    Direct Factory Pricing
                  </span>
                </div>

                {/* Description */}
                <p className="mt-3.5 text-xs text-[#473C38]/85 leading-relaxed">
                  {product.description}
                </p>

                {/* Dimensions & Specifications */}
                <div className="mt-4 p-3 bg-white border border-[#E3CAAB]/60 space-y-1.5 text-xs text-[#473C38]">
                  {product.dimensions && (
                    <div className="flex items-center gap-2">
                      <Ruler className="w-3.5 h-3.5 text-[#B08A62] shrink-0" />
                      <span>
                        <strong>Dimensions:</strong> {product.dimensions}
                      </span>
                    </div>
                  )}
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-3.5 h-3.5 text-[#B08A62] shrink-0" />
                    <span>
                      <strong>Materials:</strong> {product.material || product.materials}
                    </span>
                  </div>
                </div>

                {/* Finish / Shade Options */}
                {colorOptions.length > 0 && (
                  <div className="mt-4">
                    <label className="block text-[11px] font-semibold tracking-wider uppercase text-[#473C38] mb-1.5">
                      Select Finish / Shade: <span className="font-normal text-[#B08A62]">{selectedFinish}</span>
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {colorOptions.map((finish) => (
                        <button
                          key={finish}
                          type="button"
                          onClick={() => setSelectedFinish(finish)}
                          className={`px-3 py-1.5 text-xs font-medium border transition-colors cursor-pointer ${
                            selectedFinish === finish
                              ? 'border-[#473C38] bg-[#473C38] text-white'
                              : 'border-[#E3CAAB] bg-white text-[#473C38] hover:border-[#473C38]'
                          }`}
                        >
                          {finish}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Quantity Selector */}
                <div className="mt-4 flex items-center gap-4">
                  <span className="text-xs font-semibold uppercase tracking-wider text-[#473C38]">
                    Quantity:
                  </span>
                  <div className="flex items-center border border-[#E3CAAB] bg-white">
                    <button
                      type="button"
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="px-3 py-1 text-sm text-[#473C38] hover:bg-[#E3CAAB]/30 cursor-pointer"
                    >
                      -
                    </button>
                    <span className="px-3 text-xs font-semibold tabular-nums text-[#292522]">
                      {quantity}
                    </span>
                    <button
                      type="button"
                      onClick={() => setQuantity(quantity + 1)}
                      className="px-3 py-1 text-sm text-[#473C38] hover:bg-[#E3CAAB]/30 cursor-pointer"
                    >
                      +
                    </button>
                  </div>
                </div>
              </div>

              {/* Action CTAs */}
              <div className="mt-6 pt-5 border-t border-[#E3CAAB]/60 space-y-2.5">
                <button
                  type="button"
                  onClick={handleAdd}
                  className={`w-full py-3 text-xs font-semibold tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer ${
                    addedSuccess
                      ? 'bg-emerald-800 text-white'
                      : 'bg-[#473C38] text-white hover:bg-[#B08A62]'
                  }`}
                >
                  {addedSuccess ? (
                    <>
                      <Check className="w-4 h-4" />
                      <span>ITEM ADDED TO BAG</span>
                    </>
                  ) : (
                    <>
                      <ShoppingBag className="w-4 h-4" />
                      <span>ADD TO BAG • ₹{(product.price * quantity).toLocaleString('en-IN')}</span>
                    </>
                  )}
                </button>

                <a
                  href={getWhatsAppMessageUrl()}
                  target="_blank"
                  rel="noreferrer"
                  className="w-full py-3 border border-[#473C38] text-[#473C38] hover:bg-[#473C38] hover:text-white text-xs font-semibold tracking-wider flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>DIRECT ORDER ON WHATSAPP</span>
                </a>

                {/* Trust Callouts */}
                <div className="pt-2 grid grid-cols-2 gap-2 text-[11px] text-[#473C38]/75">
                  <div className="flex items-center gap-1.5">
                    <Shield className="w-3.5 h-3.5 text-[#B08A62] shrink-0" />
                    <span>5-Year Structural Warranty</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Truck className="w-3.5 h-3.5 text-[#B08A62] shrink-0" />
                    <span>{settings.city || 'Ahmedabad'} Free Delivery</span>
                  </div>
                </div>
              </div>

            </div>

          </div>

        </div>
      </div>

      {/* ==================================================== */}
      {/* FULLSCREEN LIGHTBOX & IMAGE ZOOM MODAL */}
      {/* ==================================================== */}
      {isLightboxOpen && (
        <div className="fixed inset-0 z-60 bg-black/95 backdrop-blur-md flex flex-col justify-between animate-fade-in p-4 sm:p-6 select-none">
          {/* Lightbox Top Header */}
          <div className="flex items-center justify-between text-white pb-3 border-b border-white/10">
            <div className="flex items-center gap-3">
              <span className="text-sm font-serif text-[#E3CAAB]">
                {product.name}
              </span>
              <span className="text-xs text-white/60">
                • Image {activeImageIndex + 1} of {allImages.length}
              </span>
            </div>

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setIsZoomed(!isZoomed)}
                className="px-3 py-1 bg-white/10 hover:bg-white/20 text-xs text-white flex items-center gap-1.5 cursor-pointer"
              >
                <Maximize2 className="w-3.5 h-3.5" />
                <span>{isZoomed ? 'Zoom 1x' : 'Zoom 2x'}</span>
              </button>

              <button
                type="button"
                onClick={() => setIsLightboxOpen(false)}
                aria-label="Close lightbox"
                className="p-1.5 bg-white/10 hover:bg-white/20 text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Lightbox Center Image Viewport */}
          <div className="relative flex-1 flex items-center justify-center overflow-hidden my-3">
            {/* Prev Image Button */}
            {allImages.length > 1 && (
              <button
                type="button"
                onClick={handlePrevImage}
                aria-label="Previous image"
                className="absolute left-2 sm:left-4 z-10 p-3 bg-black/60 hover:bg-black/90 text-white rounded-full border border-white/20 transition-transform active:scale-90 cursor-pointer"
              >
                <ChevronLeft className="w-6 h-6" />
              </button>
            )}

            {/* Large Image display */}
            <div
              className={`max-w-5xl max-h-[75vh] transition-transform duration-300 flex items-center justify-center ${
                isZoomed ? 'scale-150 cursor-zoom-out' : 'cursor-zoom-in'
              }`}
              onClick={() => setIsZoomed(!isZoomed)}
            >
              <img
                src={currentMainImage}
                alt={`${product.name} zoomed view`}
                className="max-h-[75vh] max-w-full object-contain shadow-2xl"
              />
            </div>

            {/* Next Image Button */}
            {allImages.length > 1 && (
              <button
                type="button"
                onClick={handleNextImage}
                aria-label="Next image"
                className="absolute right-2 sm:right-4 z-10 p-3 bg-black/60 hover:bg-black/90 text-white rounded-full border border-white/20 transition-transform active:scale-90 cursor-pointer"
              >
                <ChevronRight className="w-6 h-6" />
              </button>
            )}
          </div>

          {/* Lightbox Bottom Thumbnail Strip */}
          {allImages.length > 1 && (
            <div className="pt-3 border-t border-white/10 flex items-center justify-center gap-2 overflow-x-auto">
              {allImages.map((imgUrl, idx) => (
                <button
                  key={`lightbox-thumb-${idx}`}
                  type="button"
                  onClick={() => setActiveImageIndex(idx)}
                  className={`w-14 h-14 bg-black/50 border-2 transition-all cursor-pointer overflow-hidden ${
                    idx === activeImageIndex
                      ? 'border-[#B08A62] scale-105 ring-2 ring-[#B08A62]'
                      : 'border-white/30 opacity-60 hover:opacity-100'
                  }`}
                >
                  <img
                    src={imgUrl}
                    alt={`Thumb ${idx + 1}`}
                    className="w-full h-full object-cover"
                  />
                </button>
              ))}
            </div>
          )}
        </div>
      )}
    </>
  );
}
