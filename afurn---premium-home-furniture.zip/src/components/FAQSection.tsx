import { useState } from 'react';
import { ChevronDown } from 'lucide-react';
import { FAQ_ITEMS } from '../data/furnitureData';
import { useData } from '../context/DataContext';

export default function FAQSection() {
  const { settings } = useData();
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  if (settings.sections && settings.sections.faqSection === false) {
    return null;
  }

  const toggle = (idx: number) => {
    setOpenIndex(openIndex === idx ? null : idx);
  };

  return (
    <section id="faq" className="py-16 sm:py-24 bg-[#F7F3EE] border-t border-[#E3CAAB]/40">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="text-center max-w-2xl mx-auto mb-12 sm:mb-16">
          <p className="text-[11px] tracking-[0.25em] font-semibold text-[#B08A62] uppercase mb-2">
            FREQUENTLY ASKED QUESTIONS
          </p>
          <h2 className="text-3xl sm:text-4xl font-serif font-medium text-[#292522] tracking-tight">
            Direct Manufacturer Clarity
          </h2>
          <p className="mt-3 text-sm text-[#473C38]/80 leading-relaxed font-normal">
            Everything you need to know about purchasing, timber quality, and deliveries from {settings.businessName || 'AFURN'} {settings.city || 'Ahmedabad'}.
          </p>
        </div>

        {/* FAQ Accordion */}
        <div className="space-y-3">
          {FAQ_ITEMS.map((item, idx) => {
            const isOpen = openIndex === idx;
            return (
              <div
                key={idx}
                className="bg-white border border-[#E3CAAB]/70 transition-all duration-200"
              >
                <button
                  onClick={() => toggle(idx)}
                  className="w-full p-5 sm:p-6 text-left flex items-center justify-between gap-4 cursor-pointer"
                >
                  <span className="font-serif text-base sm:text-lg font-medium text-[#292522]">
                    {item.question}
                  </span>
                  <ChevronDown
                    className={`w-4 h-4 text-[#B08A62] shrink-0 transition-transform duration-200 ${
                      isOpen ? 'rotate-180' : ''
                    }`}
                  />
                </button>
                {isOpen && (
                  <div className="px-5 pb-5 sm:px-6 sm:pb-6 text-xs sm:text-sm text-[#473C38]/80 leading-relaxed border-t border-[#E3CAAB]/30 pt-3">
                    {item.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
