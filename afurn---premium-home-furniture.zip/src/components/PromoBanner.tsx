import React from 'react';
import { ArrowRight, Megaphone } from 'lucide-react';
import { useData } from '../context/DataContext';

export default function PromoBanner() {
  const { settings } = useData();

  const activeBanners = (settings.banners || []).filter((b) => b.isActive);

  if (activeBanners.length === 0) {
    return null;
  }

  // Display the first active promotional banner
  const banner = activeBanners[0];

  return (
    <aside aria-label="Special promotion" className="bg-[#473C38] text-white border-y border-[#B08A62]/30 py-3.5 px-4 relative overflow-hidden">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-[#B08A62] text-white flex items-center justify-center shrink-0">
            <Megaphone className="w-4 h-4" />
          </div>
          <div>
            <span className="font-serif font-bold text-sm tracking-wide text-[#E3CAAB]">
              {banner.title}
            </span>
            <span className="hidden md:inline mx-2 text-[#E3CAAB]/50">·</span>
            <span className="text-xs text-white/85 font-light block md:inline">
              {banner.subtitle}
            </span>
          </div>
        </div>

        {banner.buttonText && banner.buttonLink && (
          <a
            href={banner.buttonLink}
            className="px-4 py-1.5 bg-[#B08A62] text-white hover:bg-white hover:text-[#473C38] text-xs font-semibold tracking-wider uppercase transition-colors shrink-0 flex items-center gap-1.5 shadow-xs"
          >
            <span>{banner.buttonText}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </a>
        )}
      </div>
    </aside>
  );
}
