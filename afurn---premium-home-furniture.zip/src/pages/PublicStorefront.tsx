import React, { useState, useEffect, useMemo } from 'react';
import Header from '../components/Header';
import Hero from '../components/Hero';
import Categories from '../components/Categories';
import ShopCatalog from '../components/ShopCatalog';
import ProductQuickViewModal from '../components/ProductQuickViewModal';
import CustomFurnitureStudio from '../components/CustomFurnitureStudio';
import B2BSection from '../components/B2BSection';
import AboutSection from '../components/AboutSection';
import WhyChooseUs from '../components/WhyChooseUs';
import GallerySection from '../components/GallerySection';
import TestimonialsSection from '../components/TestimonialsSection';
import FAQSection from '../components/FAQSection';
import ContactSection from '../components/ContactSection';
import CartDrawer from '../components/CartDrawer';
import WishlistDrawer from '../components/WishlistDrawer';
import SearchModal from '../components/SearchModal';
import PromoBanner from '../components/PromoBanner';
import Footer from '../components/Footer';

import { useData } from '../context/DataContext';
import { Product, CartItem } from '../types/furniture';
import { MessageCircle, Phone, Lock } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function PublicStorefront() {
  const { products, settings } = useData();

  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  // Cart State (stored in localStorage)
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('afurn_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Wishlist State (stored in localStorage)
  const [wishlist, setWishlist] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem('afurn_wishlist');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Modals / Drawers
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isWishlistOpen, setIsWishlistOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('afurn_cart', JSON.stringify(cart));
    } catch (e) {
      console.error(e);
    }
  }, [cart]);

  useEffect(() => {
    try {
      localStorage.setItem('afurn_wishlist', JSON.stringify(wishlist));
    } catch (e) {
      console.error(e);
    }
  }, [wishlist]);

  // SEO & Head sync
  useEffect(() => {
    if (settings.seo?.siteTitle) {
      document.title = settings.seo.siteTitle;
    }
    if (settings.seo?.metaDescription) {
      const meta = document.querySelector('meta[name="description"]');
      if (meta) {
        meta.setAttribute('content', settings.seo.metaDescription);
      }
    }
    if (settings.customization?.favicon) {
      let link: HTMLLinkElement | null = document.querySelector("link[rel*='icon']");
      if (!link) {
        link = document.createElement('link');
        link.rel = 'shortcut icon';
        document.getElementsByTagName('head')[0].appendChild(link);
      }
      link.href = settings.customization.favicon;
    }
  }, [settings.seo, settings.customization?.favicon]);

  // Cart Handlers
  const handleAddToCart = (product: Product, finish?: string, quantity = 1) => {
    setCart((prev) => {
      const existingIndex = prev.findIndex(
        (item) => item.product.id === product.id && item.selectedFinish === finish
      );
      if (existingIndex > -1) {
        const next = [...prev];
        next[existingIndex].quantity += quantity;
        return next;
      }
      const finishOption =
        finish ||
        (product.colors && product.colors[0]) ||
        (product.finishOptions && product.finishOptions[0]) ||
        'Standard';
      return [
        ...prev,
        {
          product,
          quantity,
          selectedFinish: finishOption,
        },
      ];
    });
  };

  const handleUpdateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      handleRemoveCartItem(productId);
      return;
    }
    setCart((prev) =>
      prev.map((item) => (item.product.id === productId ? { ...item, quantity } : item))
    );
  };

  const handleRemoveCartItem = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const handleClearCart = () => {
    setCart([]);
  };

  // Wishlist Handlers
  const handleToggleWishlist = (product: Product) => {
    setWishlist((prev) => {
      const exists = prev.some((p) => p.id === product.id);
      if (exists) {
        return prev.filter((p) => p.id !== product.id);
      }
      return [...prev, product];
    });
  };

  const isInWishlist = (productId: string) => {
    return wishlist.some((p) => p.id === productId);
  };

  const handleSelectCategoryFromHeroOrCategories = (catId: string) => {
    setSelectedCategory(catId);
    const shopElement = document.getElementById('shop');
    if (shopElement) {
      shopElement.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToShop = () => {
    setSelectedCategory('all');
    document.getElementById('shop')?.scrollIntoView({ behavior: 'smooth' });
  };

  const scrollToCategories = () => {
    document.getElementById('categories')?.scrollIntoView({ behavior: 'smooth' });
  };

  // Dynamic Section Map
  const sectionComponents: Record<string, React.ReactNode> = {
    hero: (
      <Hero
        key="hero"
        onShopClick={scrollToShop}
        onExploreClick={scrollToCategories}
      />
    ),
    categories: (
      <Categories
        key="categories"
        onSelectCategory={handleSelectCategoryFromHeroOrCategories}
      />
    ),
    featuredProducts: (
      <ShopCatalog
        key="featuredProducts"
        products={products}
        selectedCategory={selectedCategory}
        onSelectCategory={setSelectedCategory}
        onOpenQuickView={(product) => setQuickViewProduct(product)}
        onAddToCart={(product) => handleAddToCart(product)}
        onToggleWishlist={handleToggleWishlist}
        isInWishlist={isInWishlist}
      />
    ),
    whyChooseUs: <WhyChooseUs key="whyChooseUs" />,
    customFurniture: <CustomFurnitureStudio key="customFurniture" />,
    b2bSection: <B2BSection key="b2bSection" />,
    aboutSection: <AboutSection key="aboutSection" />,
    gallery: <GallerySection key="gallery" />,
    testimonials: <TestimonialsSection key="testimonials" />,
    faqSection: <FAQSection key="faqSection" />,
    contactSection: <ContactSection key="contactSection" />,
  };

  const activeSectionOrder = settings.sectionOrder && settings.sectionOrder.length > 0
    ? settings.sectionOrder
    : [
        'hero',
        'categories',
        'featuredProducts',
        'whyChooseUs',
        'customFurniture',
        'b2bSection',
        'aboutSection',
        'gallery',
        'testimonials',
        'faqSection',
        'contactSection',
      ];

  // Dynamic customization styles
  const customization = settings.customization || {};
  const customStyles: React.CSSProperties = {
    backgroundColor: customization.backgroundColor || '#F7F3EE',
    color: customization.textColor || '#292522',
    fontFamily: customization.bodyFont ? `"${customization.bodyFont}", -apple-system, sans-serif` : undefined,
  };

  return (
    <div
      className="min-h-screen flex flex-col antialiased transition-colors duration-200"
      style={customStyles}
    >
      {/* Slim Top Announcement Bar */}
      <div className="bg-[#473C38] text-[#F7F3EE] text-[11px] sm:text-xs py-2 px-4 border-b border-[#B08A62]/30">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-[#E3CAAB]">
              {(settings.businessName || 'AFURN').toUpperCase()} {settings.city ? settings.city.toUpperCase() : 'AHMEDABAD'}:
            </span>
            <span className="hidden sm:inline">
              {settings.experience} Direct Manufacturer • Factory Pricing on Solid Teak & Steel
            </span>
            <span className="sm:hidden">
              Direct Factory Furniture • {settings.city || 'Danilimda, Ahmedabad'}
            </span>
          </div>

          <div className="flex items-center gap-3 sm:gap-4 text-[11px]">
            <span className="hidden md:inline">
              {settings.deliveryPromise || 'Free Delivery & Assembly in Ahmedabad'}
            </span>
            <a
              href={`tel:${settings.phone}`}
              className="text-[#E3CAAB] hover:text-white transition-colors font-medium flex items-center gap-1"
            >
              <Phone className="w-3 h-3" />
              <span>{settings.displayPhone || settings.phone}</span>
            </a>
            {/* Clearly Visible ADMIN LOGIN button */}
            <Link
              to="/admin/login"
              className="px-2.5 py-0.5 bg-[#B08A62] text-white hover:bg-white hover:text-[#473C38] text-[10px] font-bold tracking-wider uppercase transition-colors flex items-center gap-1 shadow-xs shrink-0"
              title="Open Admin Login"
            >
              <Lock className="w-3 h-3" />
              <span>ADMIN LOGIN</span>
            </Link>
          </div>
        </div>
      </div>

      {/* Promotional Top Banner (if active) */}
      <PromoBanner />

      {/* Sticky Navigation Header */}
      <Header
        cartCount={cart.reduce((total, item) => total + item.quantity, 0)}
        wishlistCount={wishlist.length}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenWishlist={() => setIsWishlistOpen(true)}
        onOpenSearch={() => setIsSearchOpen(true)}
      />

      {/* Main Content Sections (Dynamically Ordered & Toggled from CMS) */}
      <main className="flex-1">
        {activeSectionOrder.map((sectionKey) => {
          // If disabled in settings, don't render
          if (settings.sections && settings.sections[sectionKey] === false) {
            return null;
          }
          return sectionComponents[sectionKey] || null;
        })}
      </main>

      {/* Footer */}
      <Footer
        onSelectCategory={(catId) => {
          setSelectedCategory(catId);
        }}
      />

      {/* Floating WhatsApp Action Button */}
      {settings.whatsapp?.enableFloatingButton !== false && (
        <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end gap-2">
          <a
            href={
              settings.whatsappUrl ||
              `https://wa.me/91${settings.whatsappNumber || settings.phone}?text=${encodeURIComponent(
                settings.whatsapp?.defaultMessage || 'Hello AFURN, I want details regarding furniture.'
              )}`
            }
            target="_blank"
            rel="noreferrer"
            aria-label="Direct WhatsApp chat with AFURN"
            className="group flex items-center gap-2 bg-[#25D366] text-white px-4 py-3 rounded-full shadow-2xl hover:bg-emerald-600 transition-all duration-300 hover:scale-105"
          >
            <MessageCircle className="w-5 h-5 fill-current" />
            <span className="text-xs font-semibold tracking-wider pr-1 hidden sm:inline">
              Direct WhatsApp Chat
            </span>
          </a>
        </div>
      )}

      {/* Product Quick View Modal */}
      <ProductQuickViewModal
        product={quickViewProduct}
        onClose={() => setQuickViewProduct(null)}
        onAddToCart={(product, finish, quantity) => {
          handleAddToCart(product, finish, quantity);
        }}
      />

      {/* Slide-over Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cart}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveCartItem}
        onClearCart={handleClearCart}
      />

      {/* Slide-over Wishlist Drawer */}
      <WishlistDrawer
        isOpen={isWishlistOpen}
        onClose={() => setIsWishlistOpen(false)}
        wishlist={wishlist}
        onRemoveFromWishlist={(id) => setWishlist((prev) => prev.filter((p) => p.id !== id))}
        onAddToCart={(product) => handleAddToCart(product)}
      />

      {/* Search Modal */}
      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        products={products.filter((p) => p.status === 'active')}
        onSelectProduct={(product) => setQuickViewProduct(product)}
      />
    </div>
  );
}
