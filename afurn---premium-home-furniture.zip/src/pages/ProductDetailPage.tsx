import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import {
  ChevronLeft,
  ChevronRight,
  ZoomIn,
  Star,
  ShoppingBag,
  MessageCircle,
  Shield,
  Truck,
  Sparkles,
  Ruler,
  Check,
  ArrowLeft,
  Heart,
  Share2,
  Maximize2,
  X
} from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import CartDrawer from '../components/CartDrawer';
import WishlistDrawer from '../components/WishlistDrawer';
import SearchModal from '../components/SearchModal';
import { useData } from '../context/DataContext';
import { Product } from '../types/furniture';

export default function ProductDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { products, categories, settings } = useData();

  // Find product by id or slug
  const product = products.find((p) => p.id === id || p.slug === id);

  // Gallery state
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [isLightboxOpen, setIsLightboxOpen] = useState(false);
  const [isZoomed, setIsZoomed] = useState(false);

  // Selection states
  const [selectedFinish, setSelectedFinish] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [addedSuccess, setAddedSuccess] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  // App drawers state
  const [cart, setCart] = useState<
    Array<{ product: Product; quantity: number; selectedFinish?: string }>
  >(() => {
    try {
      const stored = localStorage.getItem('afurn_cart');
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  const [wishlist, setWishlist] = useState<Product[]>(() => {
    try {
      const stored = localStorage.getItem('afurn_wishlist');
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isWishlistOpen, setIsWishlistOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  // Save cart and wishlist
  useEffect(() => {
    try {
      localStorage.setItem('afurn_cart', JSON.stringify(cart));
    } catch {}
  }, [cart]);

  useEffect(() => {
    try {
      localStorage.setItem('afurn_wishlist', JSON.stringify(wishlist));
    } catch {}
  }, [wishlist]);

  // Sync initial product states
  useEffect(() => {
    window.scrollTo(0, 0);
    setActiveImageIndex(0);
    setIsLightboxOpen(false);
    setIsZoomed(false);
    if (product) {
      const colors =
        product.colors && product.colors.length > 0
          ? product.colors
          : product.finishOptions || ['Natural Teak'];
      setSelectedFinish(colors[0] || 'Natural Teak');
      setQuantity(1);
    }
  }, [product, id]);

  // Keyboard navigation for lightbox
  useEffect(() => {
    if (!isLightboxOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setIsLightboxOpen(false);
      } else if (e.key === 'ArrowRight') {
        handleNextImage();
      } else if (e.key === 'ArrowLeft') {
        handlePrevImage();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isLightboxOpen, activeImageIndex, product]);

  if (!product) {
    return (
      <div className="min-h-screen bg-[#F7F3EE] flex flex-col justify-between">
        <Header
          onOpenCart={() => setIsCartOpen(true)}
          onOpenWishlist={() => setIsWishlistOpen(true)}
          onOpenSearch={() => setIsSearchOpen(true)}
          cartCount={cart.reduce((sum, item) => sum + item.quantity, 0)}
          wishlistCount={wishlist.length}
        />
        <main className="max-w-4xl mx-auto px-4 py-24 text-center">
          <h1 className="text-3xl font-serif text-[#292522]">Product Not Found</h1>
          <p className="mt-3 text-sm text-[#473C38]/70">
            The furniture design you are looking for is either unavailable or has been relocated.
          </p>
          <div className="mt-6">
            <Link
              to="/"
              className="inline-flex items-center gap-2 px-6 py-3 bg-[#473C38] text-white text-xs font-semibold tracking-wider hover:bg-[#B08A62] transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>RETURN TO SHOWROOM</span>
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  // Resolve all images
  const allImages: string[] = [];
  if (product.images && product.images.length > 0) {
    allImages.push(...product.images);
  } else if (product.image) {
    allImages.push(product.image);
  }
  if (allImages.length === 0) {
    allImages.push('https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=1200&q=80');
  }

  const currentMainImage = allImages[activeImageIndex] || allImages[0];

  const handlePrevImage = () => {
    setActiveImageIndex((prev) => (prev - 1 + allImages.length) % allImages.length);
  };

  const handleNextImage = () => {
    setActiveImageIndex((prev) => (prev + 1) % allImages.length);
  };

  const catObj = categories.find((c) => c.id === product.categoryId);
  const categoryName = catObj ? catObj.name : product.categoryLabel || product.categoryId;

  const colorOptions =
    product.colors && product.colors.length > 0
      ? product.colors
      : product.finishOptions || ['Natural Teak', 'Dark Walnut'];

  const handleAddToCart = () => {
    setCart((prev) => {
      const finishOption = selectedFinish || colorOptions[0] || 'Standard';
      const existingIndex = prev.findIndex(
        (item) => item.product.id === product.id && item.selectedFinish === finishOption
      );
      if (existingIndex > -1) {
        const next = [...prev];
        next[existingIndex].quantity += quantity;
        return next;
      }
      return [
        ...prev,
        {
          product,
          quantity,
          selectedFinish: finishOption,
        },
      ];
    });
    setAddedSuccess(true);
    setTimeout(() => {
      setAddedSuccess(false);
      setIsCartOpen(true);
    }, 800);
  };

  const handleToggleWishlist = () => {
    setWishlist((prev) => {
      const exists = prev.some((p) => p.id === product.id);
      if (exists) {
        return prev.filter((p) => p.id !== product.id);
      }
      return [...prev, product];
    });
  };

  const isInWishlist = wishlist.some((p) => p.id === product.id);

  const getWhatsAppMessageUrl = () => {
    const message = encodeURIComponent(
      `Hello ${settings.businessName || 'AFURN'}, I would like to order or enquire about the "${product.name}" with "${selectedFinish}" finish (Quantity: ${quantity}, Price: ₹${(
        product.price * quantity
      ).toLocaleString('en-IN')}). Direct from Ahmedabad factory.`
    );
    return `https://wa.me/91${settings.phone}?text=${message}`;
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  // Related products in same category
  const relatedProducts = products
    .filter((p) => p.id !== product.id && p.categoryId === product.categoryId && p.status === 'active')
    .slice(0, 4);

  return (
    <div className="min-h-screen bg-[#F7F3EE] flex flex-col justify-between">
      {/* Website Header */}
      <Header
        onOpenCart={() => setIsCartOpen(true)}
        onOpenWishlist={() => setIsWishlistOpen(true)}
        onOpenSearch={() => setIsSearchOpen(true)}
        cartCount={cart.reduce((sum, item) => sum + item.quantity, 0)}
        wishlistCount={wishlist.length}
      />

      <main className="flex-1">
        {/* Breadcrumb Navigation */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 pb-4">
          <nav className="flex items-center gap-2 text-xs text-[#473C38]/70">
            <Link to="/" className="hover:text-[#B08A62] transition-colors">
              Home
            </Link>
            <span>/</span>
            <Link to="/#shop" className="hover:text-[#B08A62] transition-colors">
              Catalog
            </Link>
            <span>/</span>
            <span className="text-[#B08A62] font-medium">{categoryName}</span>
            <span>/</span>
            <span className="text-[#292522] font-semibold truncate max-w-xs">{product.name}</span>
          </nav>
        </div>

        {/* Product Detail Main Section */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-16">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 bg-white p-6 sm:p-10 border border-[#E3CAAB] shadow-sm">
            
            {/* ========================================================= */}
            {/* Left Column (7 cols): PRODUCT GALLERY & THUMBNAILS */}
            {/* ========================================================= */}
            <div className="lg:col-span-7 space-y-4">
              
              {/* LARGE MAIN PRODUCT IMAGE */}
              <div className="relative aspect-[4/3] sm:aspect-[16/11] bg-[#F7F3EE] overflow-hidden group border border-[#E3CAAB]">
                <img
                  src={currentMainImage}
                  alt={`${product.name} - View ${activeImageIndex + 1}`}
                  referrerPolicy="no-referrer"
                  onClick={() => setIsLightboxOpen(true)}
                  className="w-full h-full object-cover object-center cursor-zoom-in transition-transform duration-300 group-hover:scale-[1.02]"
                />

                {/* Main Image Badge on index 0 */}
                {activeImageIndex === 0 ? (
                  <div className="absolute top-4 left-4 bg-[#B08A62] text-white text-[10px] font-bold uppercase tracking-wider px-3 py-1 flex items-center gap-1.5 shadow-sm">
                    <Star className="w-3.5 h-3.5 fill-white" />
                    <span>MAIN PRODUCT IMAGE</span>
                  </div>
                ) : (
                  <div className="absolute top-4 left-4 bg-[#473C38]/80 text-white text-[10px] font-bold uppercase tracking-wider px-3 py-1 shadow-sm">
                    <span>GALLERY PHOTO #{activeImageIndex + 1}</span>
                  </div>
                )}

                {/* Counter Badge */}
                {allImages.length > 1 && (
                  <div className="absolute top-4 right-4 bg-black/70 backdrop-blur-xs text-white text-xs font-mono px-2.5 py-1 shadow-sm">
                    {activeImageIndex + 1} / {allImages.length}
                  </div>
                )}

                {/* Previous & Next Navigation Buttons */}
                {allImages.length > 1 && (
                  <>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handlePrevImage();
                      }}
                      aria-label="Previous product image"
                      className="absolute left-3 top-1/2 -translate-y-1/2 p-2.5 bg-white/90 hover:bg-white text-[#473C38] border border-[#E3CAAB] shadow-md transition-all active:scale-95 cursor-pointer opacity-90 group-hover:opacity-100"
                    >
                      <ChevronLeft className="w-5 h-5 stroke-[2.2]" />
                    </button>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleNextImage();
                      }}
                      aria-label="Next product image"
                      className="absolute right-3 top-1/2 -translate-y-1/2 p-2.5 bg-white/90 hover:bg-white text-[#473C38] border border-[#E3CAAB] shadow-md transition-all active:scale-95 cursor-pointer opacity-90 group-hover:opacity-100"
                    >
                      <ChevronRight className="w-5 h-5 stroke-[2.2]" />
                    </button>
                  </>
                )}

                {/* Zoom / Lightbox Trigger */}
                <button
                  type="button"
                  onClick={() => setIsLightboxOpen(true)}
                  className="absolute bottom-4 right-4 px-3 py-2 bg-black/75 hover:bg-black text-white text-xs font-medium flex items-center gap-1.5 shadow-md transition-colors cursor-pointer"
                  title="Click to open fullscreen zoom"
                >
                  <ZoomIn className="w-4 h-4" />
                  <span>Click to Zoom</span>
                </button>

                {/* Direct Factory Guarantee Stamp */}
                <div className="absolute bottom-4 left-4 bg-white/95 px-3 py-1.5 border border-[#E3CAAB] text-[10px] tracking-widest uppercase font-semibold text-[#B08A62]">
                  DIRECT FROM AHMEDABAD WORKSHOP
                </div>
              </div>

              {/* ========================================================= */}
              {/* THUMBNAIL GALLERY */}
              {/* [MAIN IMAGE] [thumb 1] [thumb 2] [thumb 3] [thumb 4] [thumb 5] */}
              {/* ========================================================= */}
              {allImages.length > 1 && (
                <div className="space-y-2 pt-1">
                  <div className="flex items-center justify-between text-xs text-[#473C38]/80 font-medium">
                    <span className="uppercase tracking-wider font-semibold">
                      Product Gallery ({allImages.length} images)
                    </span>
                    <span className="text-[11px] text-[#473C38]/60">
                      Click any thumbnail to change large main display
                    </span>
                  </div>

                  <div className="flex items-center gap-3 overflow-x-auto pb-2 scrollbar-thin">
                    {allImages.map((imgUrl, idx) => {
                      const isSelected = idx === activeImageIndex;
                      return (
                        <button
                          key={`${imgUrl}-${idx}`}
                          type="button"
                          onClick={() => setActiveImageIndex(idx)}
                          aria-label={`Switch to image ${idx + 1}`}
                          className={`relative shrink-0 w-20 h-20 sm:w-24 sm:h-24 bg-[#F7F3EE] overflow-hidden border-2 transition-all cursor-pointer ${
                            isSelected
                              ? 'border-[#B08A62] ring-2 ring-[#B08A62]/30 scale-[1.03]'
                              : 'border-[#E3CAAB] hover:border-[#473C38] opacity-75 hover:opacity-100'
                          }`}
                        >
                          <img
                            src={imgUrl}
                            alt={`Thumbnail ${idx + 1}`}
                            className="w-full h-full object-cover"
                          />
                          {idx === 0 && (
                            <span className="absolute bottom-0 inset-x-0 bg-[#B08A62] text-white text-[9px] font-bold text-center py-0.5 uppercase tracking-wide">
                              MAIN IMAGE
                            </span>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Guarantee callouts */}
              <div className="pt-4 grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs text-[#473C38]/85 border-t border-[#E3CAAB]/50">
                <div className="flex items-center gap-2 p-2.5 bg-[#F7F3EE]/60 border border-[#E3CAAB]/40">
                  <Shield className="w-4 h-4 text-[#B08A62] shrink-0" />
                  <span>5-Year Structural Frame Warranty</span>
                </div>
                <div className="flex items-center gap-2 p-2.5 bg-[#F7F3EE]/60 border border-[#E3CAAB]/40">
                  <Truck className="w-4 h-4 text-[#B08A62] shrink-0" />
                  <span>Free Ahmedabad Delivery & Assembly</span>
                </div>
                <div className="flex items-center gap-2 p-2.5 bg-[#F7F3EE]/60 border border-[#E3CAAB]/40">
                  <Sparkles className="w-4 h-4 text-[#B08A62] shrink-0" />
                  <span>100% Solid Seasoned Timber</span>
                </div>
              </div>

            </div>

            {/* ========================================================= */}
            {/* Right Column (5 cols): PRODUCT DETAILS, BUY & ENQUIRE */}
            {/* ========================================================= */}
            <div className="lg:col-span-5 flex flex-col justify-between space-y-6">
              
              <div className="space-y-5">
                {/* Category & Status */}
                <div className="flex items-center justify-between text-xs font-semibold uppercase tracking-[0.16em] text-[#B08A62]">
                  <span>{categoryName}</span>
                  <span
                    className={`px-2.5 py-0.5 text-[11px] tracking-wider font-semibold ${
                      product.availability === 'Out of Stock'
                        ? 'bg-rose-100 text-rose-800'
                        : product.availability === 'Made to Order'
                        ? 'bg-amber-100 text-amber-900'
                        : 'bg-emerald-100 text-emerald-800'
                    }`}
                  >
                    {product.availability || 'In Stock'}
                  </span>
                </div>

                {/* Title & SKU */}
                <div>
                  <h1 className="text-2xl sm:text-3xl font-serif font-medium text-[#292522] leading-tight">
                    {product.name}
                  </h1>
                  <div className="flex items-center gap-3 text-xs text-[#473C38]/60 mt-1.5 font-mono">
                    <span>SKU: {product.sku}</span>
                    <span>•</span>
                    <span>Ready for dispatch in {product.leadTimeDays || 5} days</span>
                  </div>
                </div>

                {/* Price Display */}
                <div className="p-4 bg-[#F7F3EE]/60 border border-[#E3CAAB] flex items-baseline justify-between gap-4">
                  <div className="flex items-baseline gap-3">
                    <span className="text-3xl font-serif font-bold text-[#473C38] tabular-nums">
                      ₹{product.price.toLocaleString('en-IN')}
                    </span>
                    {(product.discountPrice || product.originalPrice) && (
                      <span className="text-base text-[#473C38]/50 line-through tabular-nums">
                        ₹{(product.discountPrice || product.originalPrice)!.toLocaleString('en-IN')}
                      </span>
                    )}
                  </div>
                  <span className="text-xs bg-[#B08A62] text-white px-2.5 py-1 font-semibold uppercase tracking-wider">
                    Factory Price
                  </span>
                </div>

                {/* Product Summary */}
                <p className="text-xs sm:text-sm text-[#473C38]/85 leading-relaxed">
                  {product.description}
                </p>

                {/* Dimensions & Specifications */}
                <div className="p-4 bg-white border border-[#E3CAAB] space-y-2 text-xs text-[#473C38]">
                  <div className="font-semibold uppercase tracking-wider text-[11px] text-[#B08A62] pb-1 border-b border-[#E3CAAB]/50">
                    Workshop Specifications
                  </div>
                  {product.dimensions && (
                    <div className="flex items-center gap-2">
                      <Ruler className="w-4 h-4 text-[#B08A62] shrink-0" />
                      <span>
                        <strong>Dimensions:</strong> {product.dimensions}
                      </span>
                    </div>
                  )}
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-[#B08A62] shrink-0" />
                    <span>
                      <strong>Materials:</strong> {product.material || product.materials}
                    </span>
                  </div>
                </div>

                {/* Finish / Shade Options */}
                {colorOptions.length > 0 && (
                  <div>
                    <label className="block text-xs font-semibold tracking-wider uppercase text-[#473C38] mb-2">
                      Wood Finish / Fabric Shade: <span className="font-normal text-[#B08A62]">{selectedFinish}</span>
                    </label>
                    <div className="flex flex-wrap gap-2.5">
                      {colorOptions.map((finish) => (
                        <button
                          key={finish}
                          type="button"
                          onClick={() => setSelectedFinish(finish)}
                          className={`px-3.5 py-2 text-xs font-medium border transition-colors cursor-pointer ${
                            selectedFinish === finish
                              ? 'border-[#473C38] bg-[#473C38] text-white shadow-xs'
                              : 'border-[#E3CAAB] bg-white text-[#473C38] hover:border-[#473C38]'
                          }`}
                        >
                          {finish}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Quantity */}
                <div className="flex items-center gap-4">
                  <span className="text-xs font-semibold uppercase tracking-wider text-[#473C38]">
                    Quantity:
                  </span>
                  <div className="flex items-center border border-[#E3CAAB] bg-white">
                    <button
                      type="button"
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="px-3.5 py-1.5 text-sm text-[#473C38] hover:bg-[#E3CAAB]/30 cursor-pointer"
                    >
                      -
                    </button>
                    <span className="px-4 text-xs font-semibold tabular-nums text-[#292522]">
                      {quantity}
                    </span>
                    <button
                      type="button"
                      onClick={() => setQuantity(quantity + 1)}
                      className="px-3.5 py-1.5 text-sm text-[#473C38] hover:bg-[#E3CAAB]/30 cursor-pointer"
                    >
                      +
                    </button>
                  </div>
                </div>

              </div>

              {/* Action Buttons */}
              <div className="space-y-3 pt-4 border-t border-[#E3CAAB]/60">
                <button
                  type="button"
                  onClick={handleAddToCart}
                  className={`w-full py-3.5 text-xs font-semibold tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer shadow-sm ${
                    addedSuccess
                      ? 'bg-emerald-800 text-white'
                      : 'bg-[#473C38] text-white hover:bg-[#B08A62]'
                  }`}
                >
                  {addedSuccess ? (
                    <>
                      <Check className="w-4 h-4" />
                      <span>ITEM ADDED TO BAG</span>
                    </>
                  ) : (
                    <>
                      <ShoppingBag className="w-4 h-4" />
                      <span>ADD TO BAG • ₹{(product.price * quantity).toLocaleString('en-IN')}</span>
                    </>
                  )}
                </button>

                <a
                  href={getWhatsAppMessageUrl()}
                  target="_blank"
                  rel="noreferrer"
                  className="w-full py-3.5 border border-[#473C38] text-[#473C38] hover:bg-[#473C38] hover:text-white text-xs font-semibold tracking-wider flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>DIRECT ORDER ON WHATSAPP</span>
                </a>

                {/* Secondary buttons: Wishlist & Share */}
                <div className="grid grid-cols-2 gap-3 pt-1">
                  <button
                    type="button"
                    onClick={handleToggleWishlist}
                    className={`py-2 text-xs font-medium border flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                      isInWishlist
                        ? 'border-red-300 bg-red-50 text-red-700'
                        : 'border-[#E3CAAB] text-[#473C38] hover:border-[#473C38]'
                    }`}
                  >
                    <Heart className={`w-3.5 h-3.5 ${isInWishlist ? 'fill-current' : ''}`} />
                    <span>{isInWishlist ? 'In Wishlist' : 'Add to Wishlist'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleCopyLink}
                    className="py-2 text-xs font-medium border border-[#E3CAAB] text-[#473C38] hover:border-[#473C38] flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                    <span>{copiedLink ? 'Link Copied!' : 'Share Design'}</span>
                  </button>
                </div>
              </div>

            </div>

          </div>

          {/* Related Products Section */}
          {relatedProducts.length > 0 && (
            <div className="mt-16 pt-10 border-t border-[#E3CAAB]/60">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <span className="text-[10px] tracking-[0.2em] font-bold text-[#B08A62] uppercase">
                    MORE IN THIS COLLECTION
                  </span>
                  <h2 className="text-2xl font-serif font-medium text-[#292522]">
                    Related Handcrafted Designs
                  </h2>
                </div>
                <Link
                  to="/#shop"
                  className="text-xs font-semibold text-[#B08A62] hover:text-[#473C38] underline underline-offset-4"
                >
                  View All Products →
                </Link>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {relatedProducts.map((relProd) => (
                  <Link
                    key={relProd.id}
                    to={`/product/${relProd.id}`}
                    className="group bg-white border border-[#E3CAAB] hover:border-[#473C38] transition-all overflow-hidden flex flex-col justify-between"
                  >
                    <div className="relative aspect-[4/3] bg-[#F7F3EE] overflow-hidden">
                      <img
                        src={relProd.image}
                        alt={relProd.name}
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                      />
                      {relProd.images && relProd.images.length > 1 && (
                        <span className="absolute bottom-2 right-2 bg-black/60 text-white text-[10px] px-1.5 py-0.5">
                          {relProd.images.length} photos
                        </span>
                      )}
                    </div>
                    <div className="p-4">
                      <h3 className="font-serif text-sm font-medium text-[#292522] group-hover:text-[#B08A62] transition-colors truncate">
                        {relProd.name}
                      </h3>
                      <div className="mt-2 flex items-center justify-between text-xs">
                        <span className="font-serif font-bold text-[#473C38] tabular-nums">
                          ₹{relProd.price.toLocaleString('en-IN')}
                        </span>
                        <span className="text-[#B08A62] font-semibold">View →</span>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          )}

        </div>
      </main>

      {/* Website Footer */}
      <Footer />

      {/* ========================================================= */}
      {/* FULLSCREEN LIGHTBOX & HIGH-RES IMAGE ZOOM MODAL */}
      {/* ========================================================= */}
      {isLightboxOpen && (
        <div className="fixed inset-0 z-60 bg-black/95 backdrop-blur-md flex flex-col justify-between animate-fade-in p-4 sm:p-6 select-none">
          {/* Header */}
          <div className="flex items-center justify-between text-white pb-3 border-b border-white/10">
            <div className="flex items-center gap-3">
              <span className="text-sm font-serif text-[#E3CAAB]">
                {product.name}
              </span>
              <span className="text-xs text-white/60">
                • Image {activeImageIndex + 1} of {allImages.length}
              </span>
            </div>

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setIsZoomed(!isZoomed)}
                className="px-3 py-1 bg-white/10 hover:bg-white/20 text-xs text-white flex items-center gap-1.5 cursor-pointer"
              >
                <Maximize2 className="w-3.5 h-3.5" />
                <span>{isZoomed ? 'Zoom 1x' : 'Zoom 2x'}</span>
              </button>

              <button
                type="button"
                onClick={() => setIsLightboxOpen(false)}
                aria-label="Close lightbox"
                className="p-1.5 bg-white/10 hover:bg-white/20 text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Large Image Viewport */}
          <div className="relative flex-1 flex items-center justify-center overflow-hidden my-3">
            {allImages.length > 1 && (
              <button
                type="button"
                onClick={handlePrevImage}
                aria-label="Previous image"
                className="absolute left-2 sm:left-4 z-10 p-3 bg-black/60 hover:bg-black/90 text-white rounded-full border border-white/20 transition-transform active:scale-90 cursor-pointer"
              >
                <ChevronLeft className="w-6 h-6" />
              </button>
            )}

            <div
              className={`max-w-5xl max-h-[75vh] transition-transform duration-300 flex items-center justify-center ${
                isZoomed ? 'scale-150 cursor-zoom-out' : 'cursor-zoom-in'
              }`}
              onClick={() => setIsZoomed(!isZoomed)}
            >
              <img
                src={currentMainImage}
                alt={`${product.name} zoomed high resolution`}
                className="max-h-[75vh] max-w-full object-contain shadow-2xl"
              />
            </div>

            {allImages.length > 1 && (
              <button
                type="button"
                onClick={handleNextImage}
                aria-label="Next image"
                className="absolute right-2 sm:right-4 z-10 p-3 bg-black/60 hover:bg-black/90 text-white rounded-full border border-white/20 transition-transform active:scale-90 cursor-pointer"
              >
                <ChevronRight className="w-6 h-6" />
              </button>
            )}
          </div>

          {/* Bottom Thumbnails */}
          {allImages.length > 1 && (
            <div className="pt-3 border-t border-white/10 flex items-center justify-center gap-2 overflow-x-auto">
              {allImages.map((imgUrl, idx) => (
                <button
                  key={`lightbox-page-thumb-${idx}`}
                  type="button"
                  onClick={() => setActiveImageIndex(idx)}
                  className={`w-14 h-14 bg-black/50 border-2 transition-all cursor-pointer overflow-hidden ${
                    idx === activeImageIndex
                      ? 'border-[#B08A62] scale-105 ring-2 ring-[#B08A62]'
                      : 'border-white/30 opacity-60 hover:opacity-100'
                  }`}
                >
                  <img
                    src={imgUrl}
                    alt={`Thumb ${idx + 1}`}
                    className="w-full h-full object-cover"
                  />
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Drawers */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cart}
        onUpdateQuantity={(productId, qty) => {
          if (qty <= 0) {
            setCart((prev) => prev.filter((item) => item.product.id !== productId));
          } else {
            setCart((prev) =>
              prev.map((item) => (item.product.id === productId ? { ...item, quantity: qty } : item))
            );
          }
        }}
        onRemoveItem={(productId) => setCart((prev) => prev.filter((item) => item.product.id !== productId))}
        onClearCart={() => setCart([])}
      />

      <WishlistDrawer
        isOpen={isWishlistOpen}
        onClose={() => setIsWishlistOpen(false)}
        wishlist={wishlist}
        onRemoveFromWishlist={(prodId) => setWishlist((prev) => prev.filter((p) => p.id !== prodId))}
        onAddToCart={(p) => {
          setCart((prev) => [...prev, { product: p, quantity: 1, selectedFinish: p.colors?.[0] || 'Standard' }]);
          setIsWishlistOpen(false);
          setIsCartOpen(true);
        }}
      />

      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        products={products.filter((p) => p.status === 'active')}
        onSelectProduct={(p) => navigate(`/product/${p.id}`)}
      />
    </div>
  );
}
