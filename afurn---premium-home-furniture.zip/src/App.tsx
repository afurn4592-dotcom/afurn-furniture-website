import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { DataProvider } from './context/DataContext';

// Public Storefront & Product Detail
import PublicStorefront from './pages/PublicStorefront';
import ProductDetailPage from './pages/ProductDetailPage';

// Admin Pages
import AdminLogin from './admin/pages/AdminLogin';
import AdminLayout from './admin/AdminLayout';
import { AdminProtectedRoute } from './admin/AdminProtectedRoute';
import AdminDashboard from './admin/pages/AdminDashboard';
import AdminCustomization from './admin/pages/AdminCustomization';
import AdminProducts from './admin/pages/AdminProducts';
import AdminProductForm from './admin/pages/AdminProductForm';
import AdminCategories from './admin/pages/AdminCategories';
import AdminHomepage from './admin/pages/AdminHomepage';
import AdminNavigation from './admin/pages/AdminNavigation';
import AdminBanners from './admin/pages/AdminBanners';
import AdminGallery from './admin/pages/AdminGallery';
import AdminTestimonials from './admin/pages/AdminTestimonials';
import AdminEnquiries from './admin/pages/AdminEnquiries';
import AdminCustomOrders from './admin/pages/AdminCustomOrders';
import AdminSEO from './admin/pages/AdminSEO';
import AdminMedia from './admin/pages/AdminMedia';
import AdminSettings from './admin/pages/AdminSettings';

export default function App() {
  return (
    <DataProvider>
      <BrowserRouter>
        <Routes>
          {/* Customer Facing Public Website */}
          <Route path="/" element={<PublicStorefront />} />
          <Route path="/product/:id" element={<ProductDetailPage />} />

          {/* Admin Login */}
          <Route path="/admin/login" element={<AdminLogin />} />

          {/* Protected Admin Routes */}
          <Route
            path="/admin"
            element={
              <AdminProtectedRoute>
                <AdminLayout />
              </AdminProtectedRoute>
            }
          >
            <Route index element={<Navigate to="/admin/dashboard" replace />} />
            <Route path="dashboard" element={<AdminDashboard />} />
            <Route path="customization" element={<AdminCustomization />} />
            <Route path="products" element={<AdminProducts />} />
            <Route path="products/new" element={<AdminProductForm />} />
            <Route path="products/edit/:id" element={<AdminProductForm />} />
            <Route path="categories" element={<AdminCategories />} />
            <Route path="homepage" element={<AdminHomepage />} />
            <Route path="navigation" element={<AdminNavigation />} />
            <Route path="banners" element={<AdminBanners />} />
            <Route path="gallery" element={<AdminGallery />} />
            <Route path="testimonials" element={<AdminTestimonials />} />
            <Route path="enquiries" element={<AdminEnquiries />} />
            <Route path="custom-orders" element={<AdminCustomOrders />} />
            <Route path="media" element={<AdminMedia />} />
            <Route path="seo" element={<AdminSEO />} />
            <Route path="settings" element={<AdminSettings />} />
          </Route>

          {/* Fallback to Public Storefront */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </DataProvider>
  );
}
