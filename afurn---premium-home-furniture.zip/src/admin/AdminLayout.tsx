import React, { useState } from 'react';
import { Link, NavLink, Outlet, useNavigate, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  Palette,
  Package,
  PlusCircle,
  FolderTree,
  MessageSquare,
  Sparkles,
  Sliders,
  Menu as MenuIcon,
  Megaphone,
  Image as ImageIcon,
  Star,
  Globe,
  Settings,
  LogOut,
  ExternalLink,
  Menu,
  X,
  ChevronDown,
  Bell,
  Home,
  HardDrive
} from 'lucide-react';
import { useData } from '../context/DataContext';

export default function AdminLayout() {
  const { adminUser, logoutAdmin, enquiries, customOrders } = useData();
  const navigate = useNavigate();
  const location = useLocation();
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  const pendingEnquiriesCount = enquiries.filter((e) => e.status === 'NEW').length;
  const pendingOrdersCount = customOrders.filter((o) => o.status === 'NEW').length;
  const totalPending = pendingEnquiriesCount + pendingOrdersCount;

  const handleLogout = () => {
    if (window.confirm('Are you sure you want to log out of AFURN Admin?')) {
      logoutAdmin();
      navigate('/admin/login');
    }
  };

  const navLinkClass = ({ isActive }: { isActive: boolean }) =>
    `flex items-center gap-3 px-3.5 py-2.5 text-xs font-medium tracking-wide rounded-none transition-colors duration-150 ${
      isActive
        ? 'bg-[#B08A62] text-white shadow-sm font-semibold'
        : 'text-[#E3CAAB]/90 hover:bg-[#F7F3EE]/10 hover:text-white'
    }`;

  const subNavLinkClass = ({ isActive }: { isActive: boolean }) =>
    `flex items-center gap-2.5 pl-9 pr-3.5 py-2 text-xs font-medium tracking-wide rounded-none transition-colors duration-150 ${
      isActive
        ? 'text-white font-semibold bg-[#B08A62]/30 border-l-2 border-[#E3CAAB]'
        : 'text-[#E3CAAB]/70 hover:text-white hover:bg-[#F7F3EE]/5'
    }`;

  return (
    <div className="min-h-screen bg-[#F7F3EE] flex flex-col md:flex-row antialiased text-[#292522]">
      
      {/* Mobile Top Header */}
      <div className="md:hidden bg-[#473C38] text-white px-4 py-3 flex items-center justify-between border-b border-[#B08A62]/30 sticky top-0 z-50 shadow-md">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setMobileSidebarOpen(!mobileSidebarOpen)}
            aria-label="Toggle navigation menu"
            className="p-1.5 text-[#E3CAAB] hover:text-white"
          >
            {mobileSidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
          <div>
            <span className="font-serif text-lg tracking-[0.2em] font-semibold text-white">AFURN</span>
            <span className="ml-2 text-[10px] tracking-widest uppercase text-[#B08A62] font-semibold">ADMIN</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Link
            to="/"
            target="_blank"
            className="p-1.5 text-xs text-[#E3CAAB] hover:text-white flex items-center gap-1"
            title="View Public Store"
          >
            <ExternalLink className="w-4 h-4" />
          </Link>
          <button
            onClick={handleLogout}
            className="p-1.5 text-xs text-red-300 hover:text-white"
            title="Log Out"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Sidebar Navigation */}
      <aside
        className={`fixed inset-y-0 left-0 z-40 w-64 bg-[#473C38] text-[#F7F3EE] flex flex-col justify-between transform transition-transform duration-200 ease-in-out md:translate-x-0 md:static md:h-screen md:sticky md:top-0 shadow-2xl border-r border-[#B08A62]/20 ${
          mobileSidebarOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex flex-col h-full overflow-y-auto">
          {/* Brand Wordmark */}
          <div className="p-6 border-b border-[#B08A62]/20 flex items-center justify-between">
            <div>
              <div className="flex items-center gap-2">
                <span className="font-serif text-2xl tracking-[0.2em] font-bold text-white">
                  AFURN
                </span>
                <span className="text-[10px] tracking-[0.16em] uppercase bg-[#B08A62] text-white px-2 py-0.5 font-bold">
                  CMS
                </span>
              </div>
              <p className="text-[11px] text-[#E3CAAB]/70 tracking-wider mt-1">
                Ahmedabad Furniture Admin
              </p>
            </div>
            <button
              onClick={() => setMobileSidebarOpen(false)}
              className="md:hidden text-[#E3CAAB] hover:text-white p-1"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Navigation Links */}
          <nav className="p-3.5 space-y-4 flex-1 text-xs">
            {/* Dashboard */}
            <div>
              <NavLink
                to="/admin/dashboard"
                onClick={() => setMobileSidebarOpen(false)}
                className={navLinkClass}
              >
                <LayoutDashboard className="w-4 h-4 shrink-0" />
                <span>Dashboard</span>
              </NavLink>
            </div>

            {/* Customization & Appearance */}
            <div>
              <NavLink
                to="/admin/customization"
                onClick={() => setMobileSidebarOpen(false)}
                className={navLinkClass}
              >
                <Palette className="w-4 h-4 shrink-0" />
                <span>Website Customization</span>
              </NavLink>
            </div>

            {/* Catalog Group */}
            <div className="space-y-1">
              <p className="px-3.5 text-[10px] uppercase tracking-[0.2em] text-[#E3CAAB]/60 font-semibold mb-1">
                CATALOG
              </p>
              <NavLink
                to="/admin/products"
                onClick={() => setMobileSidebarOpen(false)}
                className={subNavLinkClass}
              >
                <Package className="w-3.5 h-3.5 shrink-0" />
                <span>Products</span>
              </NavLink>
              <NavLink
                to="/admin/categories"
                onClick={() => setMobileSidebarOpen(false)}
                className={subNavLinkClass}
              >
                <FolderTree className="w-3.5 h-3.5 shrink-0" />
                <span>Categories</span>
              </NavLink>
            </div>

            {/* Content & Layout Group */}
            <div className="space-y-1">
              <p className="px-3.5 text-[10px] uppercase tracking-[0.2em] text-[#E3CAAB]/60 font-semibold mb-1">
                CONTENT & DISPLAY
              </p>
              <NavLink
                to="/admin/homepage"
                onClick={() => setMobileSidebarOpen(false)}
                className={subNavLinkClass}
              >
                <Sliders className="w-3.5 h-3.5 shrink-0" />
                <span>Homepage</span>
              </NavLink>
              <NavLink
                to="/admin/navigation"
                onClick={() => setMobileSidebarOpen(false)}
                className={subNavLinkClass}
              >
                <MenuIcon className="w-3.5 h-3.5 shrink-0" />
                <span>Navigation</span>
              </NavLink>
              <NavLink
                to="/admin/banners"
                onClick={() => setMobileSidebarOpen(false)}
                className={subNavLinkClass}
              >
                <Megaphone className="w-3.5 h-3.5 shrink-0" />
                <span>Banners</span>
              </NavLink>
              <NavLink
                to="/admin/gallery"
                onClick={() => setMobileSidebarOpen(false)}
                className={subNavLinkClass}
              >
                <ImageIcon className="w-3.5 h-3.5 shrink-0" />
                <span>Gallery</span>
              </NavLink>
              <NavLink
                to="/admin/testimonials"
                onClick={() => setMobileSidebarOpen(false)}
                className={subNavLinkClass}
              >
                <Star className="w-3.5 h-3.5 shrink-0" />
                <span>Testimonials</span>
              </NavLink>
            </div>

            {/* Orders & Inquiries Group */}
            <div className="space-y-1">
              <p className="px-3.5 text-[10px] uppercase tracking-[0.2em] text-[#E3CAAB]/60 font-semibold mb-1">
                INQUIRIES & ORDERS
              </p>
              <NavLink
                to="/admin/enquiries"
                onClick={() => setMobileSidebarOpen(false)}
                className={subNavLinkClass}
              >
                <MessageSquare className="w-3.5 h-3.5 shrink-0" />
                <span className="flex-1">Enquiries</span>
                {pendingEnquiriesCount > 0 && (
                  <span className="bg-[#B08A62] text-white text-[10px] font-bold px-1.5 py-0.2 rounded-full tabular-nums">
                    {pendingEnquiriesCount}
                  </span>
                )}
              </NavLink>
              <NavLink
                to="/admin/custom-orders"
                onClick={() => setMobileSidebarOpen(false)}
                className={subNavLinkClass}
              >
                <Sparkles className="w-3.5 h-3.5 shrink-0" />
                <span className="flex-1">Custom Furniture</span>
                {pendingOrdersCount > 0 && (
                  <span className="bg-amber-600 text-white text-[10px] font-bold px-1.5 py-0.2 rounded-full tabular-nums">
                    {pendingOrdersCount}
                  </span>
                )}
              </NavLink>
            </div>

            {/* System & Settings Group */}
            <div className="space-y-1">
              <p className="px-3.5 text-[10px] uppercase tracking-[0.2em] text-[#E3CAAB]/60 font-semibold mb-1">
                SYSTEM & MEDIA
              </p>
              <NavLink
                to="/admin/media"
                onClick={() => setMobileSidebarOpen(false)}
                className={subNavLinkClass}
              >
                <HardDrive className="w-3.5 h-3.5 shrink-0" />
                <span>Media Library</span>
              </NavLink>
              <NavLink
                to="/admin/seo"
                onClick={() => setMobileSidebarOpen(false)}
                className={subNavLinkClass}
              >
                <Globe className="w-3.5 h-3.5 shrink-0" />
                <span>SEO</span>
              </NavLink>
              <NavLink
                to="/admin/settings"
                onClick={() => setMobileSidebarOpen(false)}
                className={subNavLinkClass}
              >
                <Settings className="w-3.5 h-3.5 shrink-0" />
                <span>Website Settings</span>
              </NavLink>
            </div>
          </nav>

          {/* User Profile & Actions at Footer */}
          <div className="p-4 border-t border-[#B08A62]/20 space-y-3 bg-[#3d332f]">
            <div className="flex items-center justify-between text-xs">
              <div className="truncate">
                <p className="font-semibold text-white truncate">
                  {adminUser?.name || 'Administrator'}
                </p>
                <p className="text-[10px] text-[#E3CAAB]/70 truncate">
                  {adminUser?.email || 'admin@afurn.com'}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-1">
              <Link
                to="/"
                target="_blank"
                className="py-1.5 px-2 bg-white/10 hover:bg-white/20 text-[#E3CAAB] hover:text-white text-[11px] font-medium flex items-center justify-center gap-1.5 transition-colors"
                title="View customer-facing storefront"
              >
                <Home className="w-3 h-3" />
                <span>View Store</span>
              </Link>
              <button
                onClick={handleLogout}
                className="py-1.5 px-2 bg-red-900/40 hover:bg-red-800 text-red-200 hover:text-white text-[11px] font-medium flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                title="Sign out of Admin Dashboard"
              >
                <LogOut className="w-3 h-3" />
                <span>Logout</span>
              </button>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-y-auto">
        {/* Desktop Top Bar */}
        <header className="hidden md:flex bg-white border-b border-[#E3CAAB]/60 px-8 py-3.5 items-center justify-between sticky top-0 z-30 shadow-xs">
          <div className="flex items-center gap-3">
            <span className="text-xs font-semibold uppercase tracking-[0.2em] text-[#B08A62]">
              AFURN MANAGEMENT CONSOLE
            </span>
            <span className="text-xs text-[#473C38]/40">·</span>
            <span className="text-xs text-[#473C38]/70">Danilimda Workshop, Ahmedabad</span>
          </div>

          <div className="flex items-center gap-5">
            <Link
              to="/"
              target="_blank"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#F7F3EE] hover:bg-[#E3CAAB]/30 text-[#473C38] text-xs font-semibold tracking-wider border border-[#E3CAAB] transition-colors"
            >
              <ExternalLink className="w-3.5 h-3.5 text-[#B08A62]" />
              <span>PREVIEW PUBLIC STORE</span>
            </Link>

            {totalPending > 0 && (
              <Link
                to="/admin/enquiries"
                className="relative p-2 text-[#473C38] hover:text-[#B08A62] transition-colors"
                title={`${totalPending} new customer inquiries waiting`}
              >
                <Bell className="w-4 h-4" />
                <span className="absolute top-1 right-1 w-2 h-2 bg-amber-600 rounded-full" />
              </Link>
            )}

            <div className="text-right border-l border-[#E3CAAB]/50 pl-5">
              <p className="text-xs font-semibold text-[#292522]">
                {adminUser?.name || 'Store Master'}
              </p>
              <p className="text-[10px] text-[#B08A62] font-medium uppercase tracking-wider">
                Full Access
              </p>
            </div>
          </div>
        </header>

        {/* Dynamic Route Content */}
        <main className="p-4 sm:p-6 lg:p-8 flex-1">
          <Outlet />
        </main>
      </div>

    </div>
  );
}
