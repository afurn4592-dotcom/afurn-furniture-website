import React, { useState } from 'react';
import {
  Globe,
  Search,
  Share2,
  CheckCircle2,
  Save,
  HelpCircle,
  ExternalLink,
  Sparkles,
  Smartphone,
  Monitor
} from 'lucide-react';
import { useData } from '../../context/DataContext';
import { SEOSettings } from '../../types/furniture';
import heroImg from '../../assets/images/hero_luxury_living_1791199438602.jpg';

export default function AdminSEO() {
  const { settings, updateSEO } = useData();

  const [formData, setFormData] = useState<SEOSettings>({
    siteTitle: settings.seo?.siteTitle || 'AFURN - Premium Home Furniture Manufacturer | Ahmedabad',
    metaDescription:
      settings.seo?.metaDescription ||
      'AFURN is a premier home furniture manufacturer in Ahmedabad, Gujarat, crafting luxury sofas, dining sets, tables, chairs, wooden swings, and bespoke custom furniture with 15+ years of excellence.',
    keywords:
      settings.seo?.keywords ||
      'furniture ahmedabad, custom sofa, teak dining table, wooden swing jhula, danilimda furniture, direct manufacturer',
    homeTitle:
      settings.seo?.homeTitle || 'AFURN | Handcrafted Solid Teak & Metal Furniture Ahmedabad',
    homeDescription:
      settings.seo?.homeDescription ||
      'Discover luxury sofas, dining suites, and swings handcrafted in Danilimda, Ahmedabad. Direct factory pricing with 15+ years experience.',
    socialImage: settings.seo?.socialImage || heroImg,
  });

  const [savedSuccess, setSavedSuccess] = useState(false);
  const [previewMode, setPreviewMode] = useState<'desktop' | 'mobile'>('desktop');

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateSEO(formData);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Top Header */}
      <div className="bg-white p-6 border border-[#E3CAAB] shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] tracking-[0.2em] uppercase font-bold text-[#B08A62]">
            SEARCH ENGINE OPTIMIZATION
          </span>
          <h1 className="text-2xl font-serif font-medium text-[#292522] mt-0.5">
            SEO & Social Sharing Management
          </h1>
          <p className="text-xs text-[#473C38]/70 mt-1">
            Optimize titles, meta tags, and social cards for Google and WhatsApp without touching HTML code.
          </p>
        </div>

        <button
          type="button"
          onClick={handleSave}
          className="px-5 py-2.5 bg-[#473C38] text-white hover:bg-[#B08A62] text-xs font-semibold tracking-wider flex items-center justify-center gap-2 transition-colors shadow-xs cursor-pointer shrink-0"
        >
          <Save className="w-4 h-4" />
          <span>SAVE SEO SETTINGS</span>
        </button>
      </div>

      {savedSuccess && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2.5 animate-fade-in shadow-xs">
          <CheckCircle2 className="w-5 h-5 shrink-0 text-emerald-600" />
          <span>
            <strong>SEO Updated!</strong> Meta tags, page title, and social sharing cards are now live on your website.
          </span>
        </div>
      )}

      {/* Main Form & Previews */}
      <form onSubmit={handleSave} className="space-y-6">
        
        {/* Core Search Engine Metadata */}
        <div className="bg-white p-6 sm:p-8 border border-[#E3CAAB] shadow-xs space-y-5">
          <h2 className="font-serif text-lg font-medium text-[#292522] pb-3 border-b border-[#E3CAAB]/40 flex items-center gap-2">
            <Search className="w-4 h-4 text-[#B08A62]" />
            <span>Search Engine Meta Tags</span>
          </h2>

          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-semibold uppercase tracking-wider text-[#473C38]">
                  Website Browser Title & SERP Headline
                </label>
                <span className={`text-[11px] font-mono ${formData.siteTitle.length > 60 ? 'text-amber-600' : 'text-[#473C38]/60'}`}>
                  {formData.siteTitle.length} / 60 characters
                </span>
              </div>
              <input
                type="text"
                required
                value={formData.siteTitle}
                onChange={(e) => setFormData({ ...formData, siteTitle: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
              />
              <p className="text-[11px] text-[#473C38]/60 mt-1">
                Recommended: 50-60 characters including business name and location (Ahmedabad).
              </p>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-semibold uppercase tracking-wider text-[#473C38]">
                  Meta Description
                </label>
                <span className={`text-[11px] font-mono ${formData.metaDescription.length > 160 ? 'text-amber-600' : 'text-[#473C38]/60'}`}>
                  {formData.metaDescription.length} / 160 characters
                </span>
              </div>
              <textarea
                rows={3}
                required
                value={formData.metaDescription}
                onChange={(e) => setFormData({ ...formData, metaDescription: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
              />
              <p className="text-[11px] text-[#473C38]/60 mt-1">
                Displayed below your link on Google search results. Keep between 120-160 characters.
              </p>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                Target Search Keywords (Comma separated)
              </label>
              <input
                type="text"
                value={formData.keywords}
                onChange={(e) => setFormData({ ...formData, keywords: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
              />
              <p className="text-[11px] text-[#473C38]/60 mt-1">
                e.g., teakwood sofa, wooden swing ahmedabad, danilimda furniture manufacturer, modern dining table
              </p>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                Social Share Image (OpenGraph / WhatsApp Preview)
              </label>
              <input
                type="url"
                value={formData.socialImage}
                onChange={(e) => setFormData({ ...formData, socialImage: e.target.value })}
                placeholder="https://example.com/social-preview.jpg"
                className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
              />
              <p className="text-[11px] text-[#473C38]/60 mt-1">
                Image shown when your website link is shared on WhatsApp, Facebook, LinkedIn, or Twitter.
              </p>
            </div>
          </div>
        </div>

        {/* Live Google Search Preview Card */}
        <div className="bg-white p-6 sm:p-8 border border-[#E3CAAB] shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#E3CAAB]/40">
            <div>
              <h3 className="font-serif text-base font-semibold text-[#292522]">
                Google Search Results Preview
              </h3>
              <p className="text-xs text-[#473C38]/60">
                How AFURN appears to prospective customers on Google Search
              </p>
            </div>

            <div className="flex items-center gap-1 bg-[#F7F3EE] p-1 border border-[#E3CAAB]">
              <button
                type="button"
                onClick={() => setPreviewMode('desktop')}
                className={`p-1 text-xs flex items-center gap-1 px-2 cursor-pointer ${
                  previewMode === 'desktop' ? 'bg-white shadow-xs font-semibold text-[#473C38]' : 'text-[#473C38]/60'
                }`}
              >
                <Monitor className="w-3.5 h-3.5" />
                <span>Desktop</span>
              </button>
              <button
                type="button"
                onClick={() => setPreviewMode('mobile')}
                className={`p-1 text-xs flex items-center gap-1 px-2 cursor-pointer ${
                  previewMode === 'mobile' ? 'bg-white shadow-xs font-semibold text-[#473C38]' : 'text-[#473C38]/60'
                }`}
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span>Mobile</span>
              </button>
            </div>
          </div>

          {/* Realistic Google SERP snippet */}
          <div className="p-4 bg-white border border-neutral-200 rounded-md max-w-2xl font-sans">
            <div className="flex items-center gap-2 mb-1">
              <div className="w-6 h-6 rounded-full bg-[#473C38] text-white flex items-center justify-center text-[10px] font-bold">
                A
              </div>
              <div className="leading-tight">
                <span className="text-[12px] text-neutral-800 font-medium block">AFURN Furniture Ahmedabad</span>
                <span className="text-[11px] text-neutral-500 block truncate">
                  https://afurn.in › ahmedabad › furniture-manufacturer
                </span>
              </div>
            </div>

            <h4 className="text-[#1a0dab] hover:underline text-lg font-medium cursor-pointer leading-snug line-clamp-1">
              {formData.siteTitle}
            </h4>

            <p className="text-neutral-600 text-xs mt-1 leading-relaxed line-clamp-2">
              {formData.metaDescription}
            </p>

            <div className="flex items-center gap-3 mt-2 text-[11px] text-[#006621]">
              <span>★ 4.9 (180+ Reviews)</span>
              <span>·</span>
              <span>15+ Years Experience</span>
              <span>·</span>
              <span>Danilimda, Ahmedabad</span>
            </div>
          </div>
        </div>

        {/* Live Social Sharing Card Preview */}
        <div className="bg-white p-6 sm:p-8 border border-[#E3CAAB] shadow-xs space-y-4">
          <div className="pb-3 border-b border-[#E3CAAB]/40">
            <h3 className="font-serif text-base font-semibold text-[#292522] flex items-center gap-2">
              <Share2 className="w-4 h-4 text-[#B08A62]" />
              <span>Social Media & WhatsApp Share Card Preview</span>
            </h3>
            <p className="text-xs text-[#473C38]/60">
              When someone pastes your link into a WhatsApp message, iMessage, or Facebook
            </p>
          </div>

          <div className="border border-neutral-300 rounded-lg overflow-hidden max-w-md bg-[#F7F3EE]/30 shadow-xs">
            <div className="aspect-[1.91/1] bg-neutral-200 overflow-hidden relative">
              {formData.socialImage ? (
                <img
                  src={formData.socialImage}
                  alt="Social share preview"
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-[#473C38]/40 text-xs">
                  No social preview image specified
                </div>
              )}
            </div>

            <div className="p-3.5 bg-white border-t border-neutral-200 space-y-1">
              <span className="text-[10px] uppercase font-bold text-neutral-400 tracking-wider">
                AFURN.IN
              </span>
              <h5 className="text-xs font-semibold text-[#292522] line-clamp-1">
                {formData.siteTitle}
              </h5>
              <p className="text-[11px] text-neutral-600 line-clamp-2">
                {formData.metaDescription}
              </p>
            </div>
          </div>
        </div>

      </form>
    </div>
  );
}
