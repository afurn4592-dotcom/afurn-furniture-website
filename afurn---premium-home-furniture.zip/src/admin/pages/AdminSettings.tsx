import React, { useState } from 'react';
import {
  Settings,
  Save,
  CheckCircle2,
  Phone,
  MessageCircle,
  Mail,
  MapPin,
  Instagram,
  Facebook,
  Sparkles,
  Info
} from 'lucide-react';
import { useData } from '../../context/DataContext';

export default function AdminSettings() {
  const { settings, updateSettings, resetToDefaultData } = useData();

  // Settings form state
  const [formData, setFormData] = useState({
    businessName: settings.businessName || 'AFURN',
    tagline: settings.tagline || 'Crafted for Modern Living',
    experience: settings.experience || '15+ Years of Experience',
    phone: settings.phone || '7069469407',
    displayPhone: settings.displayPhone || '+91 7069469407',
    whatsappNumber: settings.whatsappNumber || '7069469407',
    email: settings.email || 'craftsofa277@gmail.com',
    address: settings.address || '',
    businessDescription: settings.businessDescription || '',
    instagramUrl: settings.instagramUrl || '',
    facebookUrl: settings.facebookUrl || '',
    workingHours: settings.workingHours || '',
    deliveryPromise: settings.deliveryPromise || '',

    // Hero Section
    heroLabel: settings.heroLabel || 'CRAFTED FOR MODERN LIVING',
    heroHeading: settings.heroHeading || 'FURNITURE THAT\nMAKES YOUR SPACE\nFEEL LIKE HOME.',
    heroDescription: settings.heroDescription || 'Discover beautifully crafted furniture designed for comfort, durability and timeless style.',
    heroButton1Text: settings.heroButton1Text || 'SHOP FURNITURE',
    heroButton2Text: settings.heroButton2Text || 'EXPLORE COLLECTION',
    heroTrustStatement: settings.heroTrustStatement || '15+ YEARS OF EXPERIENCE • PREMIUM QUALITY • CUSTOM DESIGNS',

    // About Section
    aboutUsTitle: settings.aboutUsTitle || 'ABOUT AFURN',
    aboutUsHeading: settings.aboutUsHeading || 'Rooted in Ahmedabad, Built for Generations',
    aboutUsText1: settings.aboutUsText1 || '',
    aboutUsText2: settings.aboutUsText2 || '',
  });

  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings({
      ...formData,
      whatsappUrl: `https://wa.me/91${formData.whatsappNumber.replace(/[^0-9]/g, '')}`,
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const handleResetData = () => {
    if (
      window.confirm(
        'WARNING: This will reset all products, categories, and settings back to default showroom state. Are you sure?'
      )
    ) {
      resetToDefaultData();
      alert('Data reset to default.');
      window.location.reload();
    }
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      
      {/* Top Header */}
      <div className="bg-white p-6 border border-[#E3CAAB] shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] tracking-[0.2em] uppercase font-bold text-[#B08A62]">
            GLOBAL CONFIGURATION
          </span>
          <h1 className="text-2xl font-serif font-medium text-[#292522] mt-0.5">
            Website & Brand Settings
          </h1>
          <p className="text-xs text-[#473C38]/70 mt-1">
            Customize business contact details, hero messaging, and workshop information without editing code.
          </p>
        </div>

        <button
          type="submit"
          form="settings-form"
          className="px-6 py-3 bg-[#473C38] text-white hover:bg-[#B08A62] text-xs font-semibold tracking-wider flex items-center justify-center gap-2 transition-colors shadow-xs cursor-pointer shrink-0"
        >
          <Save className="w-4 h-4" />
          <span>SAVE CHANGES</span>
        </button>
      </div>

      {savedSuccess && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2.5 animate-fade-in">
          <CheckCircle2 className="w-5 h-5 shrink-0 text-emerald-600" />
          <span>Settings successfully updated! All public website components now display the updated content.</span>
        </div>
      )}

      <form id="settings-form" onSubmit={handleSubmit} className="space-y-6">
        
        {/* Card 1: Business Identity & Contact */}
        <div className="bg-white p-6 sm:p-8 border border-[#E3CAAB] shadow-xs space-y-5">
          <h2 className="font-serif text-lg font-medium text-[#292522] pb-3 border-b border-[#E3CAAB]/40">
            Business Contact & Location Information
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                Business Name
              </label>
              <input
                type="text"
                required
                value={formData.businessName}
                onChange={(e) => setFormData({ ...formData, businessName: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                Experience Tagline
              </label>
              <input
                type="text"
                value={formData.experience}
                onChange={(e) => setFormData({ ...formData, experience: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                Phone Number (Calls)
              </label>
              <input
                type="text"
                required
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value, displayPhone: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                WhatsApp Number
              </label>
              <input
                type="text"
                required
                value={formData.whatsappNumber}
                onChange={(e) => setFormData({ ...formData, whatsappNumber: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                Contact Email
              </label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
              Factory / Showroom Full Address
            </label>
            <textarea
              rows={2}
              value={formData.address}
              onChange={(e) => setFormData({ ...formData, address: e.target.value })}
              className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                Working Hours
              </label>
              <input
                type="text"
                value={formData.workingHours}
                onChange={(e) => setFormData({ ...formData, workingHours: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                Delivery Promise Text
              </label>
              <input
                type="text"
                value={formData.deliveryPromise}
                onChange={(e) => setFormData({ ...formData, deliveryPromise: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                Instagram URL
              </label>
              <input
                type="text"
                value={formData.instagramUrl}
                onChange={(e) => setFormData({ ...formData, instagramUrl: e.target.value })}
                placeholder="https://instagram.com/afurn.furniture"
                className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                Facebook URL
              </label>
              <input
                type="text"
                value={formData.facebookUrl}
                onChange={(e) => setFormData({ ...formData, facebookUrl: e.target.value })}
                placeholder="https://facebook.com/afurn.furniture"
                className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
              />
            </div>
          </div>
        </div>

        {/* Card 2: Hero Section Copywriting */}
        <div className="bg-white p-6 sm:p-8 border border-[#E3CAAB] shadow-xs space-y-5">
          <h2 className="font-serif text-lg font-medium text-[#292522] pb-3 border-b border-[#E3CAAB]/40">
            Hero Section Copywriting
          </h2>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
              Top Small Label
            </label>
            <input
              type="text"
              value={formData.heroLabel}
              onChange={(e) => setFormData({ ...formData, heroLabel: e.target.value })}
              className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
              Large Hero Heading (use Enter for line breaks)
            </label>
            <textarea
              rows={3}
              value={formData.heroHeading}
              onChange={(e) => setFormData({ ...formData, heroHeading: e.target.value })}
              className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-sm font-serif font-semibold text-[#292522] focus:outline-none focus:border-[#473C38]"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
              Supporting Text
            </label>
            <textarea
              rows={2}
              value={formData.heroDescription}
              onChange={(e) => setFormData({ ...formData, heroDescription: e.target.value })}
              className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                Primary Button Label
              </label>
              <input
                type="text"
                value={formData.heroButton1Text}
                onChange={(e) => setFormData({ ...formData, heroButton1Text: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                Secondary Button Label
              </label>
              <input
                type="text"
                value={formData.heroButton2Text}
                onChange={(e) => setFormData({ ...formData, heroButton2Text: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
              Trust Statement (Below Buttons)
            </label>
            <input
              type="text"
              value={formData.heroTrustStatement}
              onChange={(e) => setFormData({ ...formData, heroTrustStatement: e.target.value })}
              className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
            />
          </div>
        </div>

        {/* Card 3: About Us Section Copywriting */}
        <div className="bg-white p-6 sm:p-8 border border-[#E3CAAB] shadow-xs space-y-5">
          <h2 className="font-serif text-lg font-medium text-[#292522] pb-3 border-b border-[#E3CAAB]/40">
            About AFURN Section Copywriting
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                Section Title
              </label>
              <input
                type="text"
                value={formData.aboutUsTitle}
                onChange={(e) => setFormData({ ...formData, aboutUsTitle: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                Section Heading
              </label>
              <input
                type="text"
                value={formData.aboutUsHeading}
                onChange={(e) => setFormData({ ...formData, aboutUsHeading: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
              First Paragraph
            </label>
            <textarea
              rows={3}
              value={formData.aboutUsText1}
              onChange={(e) => setFormData({ ...formData, aboutUsText1: e.target.value })}
              className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
              Second Paragraph (Workshop details)
            </label>
            <textarea
              rows={3}
              value={formData.aboutUsText2}
              onChange={(e) => setFormData({ ...formData, aboutUsText2: e.target.value })}
              className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
            />
          </div>
        </div>

        {/* Save Bar */}
        <div className="flex items-center justify-between pt-4">
          <button
            type="button"
            onClick={handleResetData}
            className="text-xs text-red-600 hover:text-red-800 underline cursor-pointer"
          >
            Reset All Sample Data to Factory Defaults
          </button>

          <button
            type="submit"
            className="px-8 py-3.5 bg-[#473C38] text-white hover:bg-[#B08A62] text-xs font-semibold tracking-wider flex items-center gap-2 transition-colors shadow-xs cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>SAVE WEBSITE SETTINGS</span>
          </button>
        </div>

      </form>

    </div>
  );
}
