import React, { useState } from 'react';
import {
  Sliders,
  Eye,
  EyeOff,
  CheckCircle2,
  Info,
  ArrowUp,
  ArrowDown,
  RotateCcw,
  Sparkles,
  Save,
  Image as ImageIcon,
  Layout,
  FileText,
  Award
} from 'lucide-react';
import { useData } from '../../context/DataContext';
import { SectionVisibility, HeroSettings, AboutSettings, WhyChooseUsCard } from '../../types/furniture';

const SECTION_METADATA: Record<string, { title: string; description: string; anchor: string }> = {
  hero: {
    title: 'Hero Showcase Section',
    description: 'Top landing screen with main headline, living room visual, and primary CTA buttons.',
    anchor: '#home',
  },
  categories: {
    title: 'Shop by Category Grid',
    description: 'The 7 curated category cards (Sofas, Dining, Tables, Chairs, Lounge Chairs, Wooden Swings, Centre Tables).',
    anchor: '#categories',
  },
  featuredProducts: {
    title: 'Product Catalog & Bestsellers',
    description: 'The filterable showroom catalog with price sorting, quick view, and cart controls.',
    anchor: '#shop',
  },
  whyChooseUs: {
    title: 'Why Choose AFURN (Value Pillars)',
    description: '6 core manufacturer guarantees: 15+ years experience, direct factory pricing, seasoned wood, custom design.',
    anchor: '#why-us',
  },
  customFurniture: {
    title: 'Custom Furniture Studio',
    description: 'The interactive bespoke configurator for homeowners, architects, and interior designers.',
    anchor: '#custom',
  },
  b2bSection: {
    title: 'B2B & Commercial Bulk Orders',
    description: 'Trade partnership section for Architects, Cafes, Restaurants, and Hotels across Gujarat.',
    anchor: '#b2b',
  },
  aboutSection: {
    title: 'About AFURN & 15+ Years Story',
    description: 'Workshop history, Danilimda factory highlights, seasoned wood & metal joinery.',
    anchor: '#about',
  },
  gallery: {
    title: 'Showroom & Installation Gallery',
    description: 'Visual showcase of real Ahmedabad installations and architectural projects.',
    anchor: '#gallery',
  },
  testimonials: {
    title: 'Customer Testimonials & Reviews',
    description: 'Genuine ratings and verified reviews from Ahmedabad architects and homeowners.',
    anchor: '#testimonials',
  },
  faqSection: {
    title: 'FAQ Accordion',
    description: 'Frequently asked questions regarding warranty, timber, and factory visits.',
    anchor: '#faq',
  },
  contactSection: {
    title: 'Factory Visit & Contact Form',
    description: 'Danilimda workshop address, direct WhatsApp button, and visit scheduler.',
    anchor: '#contact',
  },
};

export default function AdminHomepage() {
  const {
    settings,
    updateSectionVisibility,
    updateSectionOrder,
    updateHeroSettings,
    updateAboutSettings,
    updateWhyChooseUs,
  } = useData();

  const [activeTab, setActiveTab] = useState<'layout' | 'hero' | 'about' | 'why_choose_us'>('layout');
  const [savedNotice, setSavedNotice] = useState<string | null>(null);

  // Section Order state
  const [sectionOrder, setSectionOrder] = useState<string[]>(() => {
    return settings.sectionOrder && settings.sectionOrder.length > 0
      ? [...settings.sectionOrder]
      : [
          'hero',
          'categories',
          'featuredProducts',
          'whyChooseUs',
          'customFurniture',
          'b2bSection',
          'aboutSection',
          'gallery',
          'testimonials',
          'faqSection',
          'contactSection',
        ];
  });

  // Hero form state
  const [heroForm, setHeroForm] = useState<HeroSettings>(() => ({
    smallHeading: settings.hero?.smallHeading || settings.heroLabel || 'CRAFTED FOR MODERN LIVING',
    mainHeading: settings.hero?.mainHeading || settings.heroHeading || 'FURNITURE THAT\nMAKES YOUR SPACE\nFEEL LIKE HOME.',
    description: settings.hero?.description || settings.heroDescription || 'Discover beautifully crafted furniture designed for comfort, durability and timeless style.',
    button1Text: settings.hero?.button1Text || settings.heroButton1Text || 'SHOP FURNITURE',
    button1Link: settings.hero?.button1Link || '#shop',
    button2Text: settings.hero?.button2Text || settings.heroButton2Text || 'EXPLORE COLLECTION',
    button2Link: settings.hero?.button2Link || '#categories',
    heroImage: settings.hero?.heroImage || '',
    textAlignment: settings.hero?.textAlignment || 'left',
    imagePosition: settings.hero?.imagePosition || 'right',
    overlayStrength: settings.hero?.overlayStrength || 25,
    showButtons: settings.hero?.showButtons !== false,
    trustStatement: settings.hero?.trustStatement || settings.heroTrustStatement || '15+ YEARS OF EXPERIENCE • PREMIUM QUALITY • CUSTOM DESIGNS',
  }));

  // About form state
  const [aboutForm, setAboutForm] = useState<AboutSettings>(() => ({
    heading: settings.about?.heading || settings.aboutUsHeading || 'Rooted in Ahmedabad, Built for Generations',
    subheading: settings.about?.subheading || settings.aboutUsTitle || 'ABOUT AFURN',
    description1: settings.about?.description1 || settings.aboutUsText1 || 'Founded on the bedrock of authentic Indian craftsmanship, AFURN has spent over 15 years shaping living rooms, dining spaces, and architectural interiors across Gujarat.',
    description2: settings.about?.description2 || settings.aboutUsText2 || 'Unlike generic retail showrooms that sell imported composite boards, our factory at Danilimda, Ahmedabad works exclusively with seasoned natural wood and structural heavy-gauge steel. From heritage Gujarat swings (Jhulas) with solid brass chains to sculptural Italian-inspired curved sectionals, every piece is built to endure decades of real family life.',
    experienceNumber: settings.about?.experienceNumber || '15+',
    experienceLabel: settings.about?.experienceLabel || 'Years of Master Craftsmanship',
    customerNumber: settings.about?.customerNumber || '3,500+',
    customerLabel: settings.about?.customerLabel || 'Happy Homes Furnished',
    productsNumber: settings.about?.productsNumber || '1,000+',
    productsLabel: settings.about?.productsLabel || 'Bespoke Furniture Pieces',
    image: settings.about?.image || '',
  }));

  // Why Choose Us cards state
  const [whyChooseUsCards, setWhyChooseUsCards] = useState<WhyChooseUsCard[]>(() => {
    return settings.whyChooseUsCards || [];
  });

  // Reorder Sections
  const handleMoveUp = (index: number) => {
    if (index === 0) return;
    const nextOrder = [...sectionOrder];
    const temp = nextOrder[index];
    nextOrder[index] = nextOrder[index - 1];
    nextOrder[index - 1] = temp;
    setSectionOrder(nextOrder);
    updateSectionOrder(nextOrder);
    showNotice('Section order updated!');
  };

  const handleMoveDown = (index: number) => {
    if (index === sectionOrder.length - 1) return;
    const nextOrder = [...sectionOrder];
    const temp = nextOrder[index];
    nextOrder[index] = nextOrder[index + 1];
    nextOrder[index + 1] = temp;
    setSectionOrder(nextOrder);
    updateSectionOrder(nextOrder);
    showNotice('Section order updated!');
  };

  const handleToggleSectionVisibility = (key: keyof SectionVisibility) => {
    const currentState = settings.sections[key] !== false;
    updateSectionVisibility(key, !currentState);
    showNotice(`"${key}" is now ${!currentState ? 'VISIBLE' : 'HIDDEN'}`);
  };

  const handleResetSectionOrder = () => {
    const defaultOrder = [
      'hero',
      'categories',
      'featuredProducts',
      'whyChooseUs',
      'customFurniture',
      'b2bSection',
      'aboutSection',
      'gallery',
      'testimonials',
      'faqSection',
      'contactSection',
    ];
    setSectionOrder(defaultOrder);
    updateSectionOrder(defaultOrder);
    showNotice('Reset section ordering to showroom default.');
  };

  const showNotice = (msg: string) => {
    setSavedNotice(msg);
    setTimeout(() => setSavedNotice(null), 3000);
  };

  const handleSaveHero = (e: React.FormEvent) => {
    e.preventDefault();
    updateHeroSettings(heroForm);
    showNotice('Hero section content saved successfully!');
  };

  const handleSaveAbout = (e: React.FormEvent) => {
    e.preventDefault();
    updateAboutSettings(aboutForm);
    showNotice('About AFURN story updated successfully!');
  };

  const handleSaveWhyChooseUs = () => {
    updateWhyChooseUs(whyChooseUsCards);
    showNotice('Why Choose Us cards saved successfully!');
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Top Header */}
      <div className="bg-white p-6 border border-[#E3CAAB] shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] tracking-[0.2em] uppercase font-bold text-[#B08A62]">
            PAGE LAYOUT & COPYWRITING
          </span>
          <h1 className="text-2xl font-serif font-medium text-[#292522] mt-0.5">
            Homepage Content & Section Arrangement
          </h1>
          <p className="text-xs text-[#473C38]/70 mt-1">
            Reorder sections, toggle visibility, and customize headline text, story paragraphs, and value proposition cards.
          </p>
        </div>
      </div>

      {savedNotice && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2.5 animate-fade-in shadow-xs">
          <CheckCircle2 className="w-5 h-5 shrink-0 text-emerald-600" />
          <span>
            <strong>Success:</strong> {savedNotice}
          </span>
        </div>
      )}

      {/* Tabs */}
      <div className="flex border-b border-[#E3CAAB] bg-white">
        <button
          type="button"
          onClick={() => setActiveTab('layout')}
          className={`px-5 py-3 text-xs font-semibold tracking-wider uppercase transition-colors flex items-center gap-2 cursor-pointer ${
            activeTab === 'layout'
              ? 'border-b-2 border-[#B08A62] text-[#473C38] bg-[#F7F3EE]/50 font-bold'
              : 'text-[#473C38]/60 hover:text-[#473C38]'
          }`}
        >
          <Layout className="w-4 h-4" />
          <span>Section Order & Visibility</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('hero')}
          className={`px-5 py-3 text-xs font-semibold tracking-wider uppercase transition-colors flex items-center gap-2 cursor-pointer ${
            activeTab === 'hero'
              ? 'border-b-2 border-[#B08A62] text-[#473C38] bg-[#F7F3EE]/50 font-bold'
              : 'text-[#473C38]/60 hover:text-[#473C38]'
          }`}
        >
          <Sparkles className="w-4 h-4" />
          <span>Hero Showcase</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('about')}
          className={`px-5 py-3 text-xs font-semibold tracking-wider uppercase transition-colors flex items-center gap-2 cursor-pointer ${
            activeTab === 'about'
              ? 'border-b-2 border-[#B08A62] text-[#473C38] bg-[#F7F3EE]/50 font-bold'
              : 'text-[#473C38]/60 hover:text-[#473C38]'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>About AFURN Story</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('why_choose_us')}
          className={`px-5 py-3 text-xs font-semibold tracking-wider uppercase transition-colors flex items-center gap-2 cursor-pointer ${
            activeTab === 'why_choose_us'
              ? 'border-b-2 border-[#B08A62] text-[#473C38] bg-[#F7F3EE]/50 font-bold'
              : 'text-[#473C38]/60 hover:text-[#473C38]'
          }`}
        >
          <Award className="w-4 h-4" />
          <span>Why Choose Us Cards</span>
        </button>
      </div>

      {/* TAB 1: SECTION ORDER & VISIBILITY */}
      {activeTab === 'layout' && (
        <div className="space-y-4">
          <div className="bg-white p-4 border border-[#E3CAAB] shadow-xs flex items-center justify-between">
            <span className="text-xs text-[#473C38]/70">
              Drag or use arrows to change the vertical flow of your homepage. Toggle switches to hide or reveal sections.
            </span>
            <button
              type="button"
              onClick={handleResetSectionOrder}
              className="px-3 py-1.5 bg-white border border-[#473C38] text-[#473C38] hover:bg-[#F7F3EE] text-xs font-semibold tracking-wider flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>RESET ORDER</span>
            </button>
          </div>

          <div className="bg-white border border-[#E3CAAB] shadow-xs divide-y divide-[#E3CAAB]/40">
            {sectionOrder.map((sectionKey, index) => {
              const meta = SECTION_METADATA[sectionKey] || {
                title: sectionKey,
                description: 'Homepage section',
                anchor: `#${sectionKey}`,
              };
              const isVisible = settings.sections[sectionKey] !== false;

              return (
                <div
                  key={sectionKey}
                  className={`p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition-colors ${
                    !isVisible ? 'bg-neutral-50/70 opacity-60' : 'hover:bg-[#F7F3EE]/20'
                  }`}
                >
                  <div className="flex items-center gap-3.5">
                    {/* Order Controls */}
                    <div className="flex items-center gap-1 shrink-0">
                      <span className="w-6 text-center text-xs font-mono font-bold text-[#473C38]/70">
                        {index + 1}
                      </span>
                      <div className="flex flex-col">
                        <button
                          type="button"
                          onClick={() => handleMoveUp(index)}
                          disabled={index === 0}
                          className="p-1 text-[#473C38] hover:text-[#B08A62] disabled:opacity-20 cursor-pointer disabled:cursor-not-allowed"
                          title="Move Section Up"
                        >
                          <ArrowUp className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleMoveDown(index)}
                          disabled={index === sectionOrder.length - 1}
                          className="p-1 text-[#473C38] hover:text-[#B08A62] disabled:opacity-20 cursor-pointer disabled:cursor-not-allowed"
                          title="Move Section Down"
                        >
                          <ArrowDown className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    {/* Section Info */}
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2">
                        <h3 className="font-serif text-base font-semibold text-[#292522]">
                          {meta.title}
                        </h3>
                        <span className="text-[10px] font-mono text-[#473C38]/50">
                          {meta.anchor}
                        </span>
                      </div>
                      <p className="text-xs text-[#473C38]/70">{meta.description}</p>
                    </div>
                  </div>

                  {/* Toggle Visibility */}
                  <div className="flex items-center gap-3 shrink-0 self-end sm:self-center">
                    <span
                      className={`text-xs font-bold uppercase tracking-wider ${
                        isVisible ? 'text-emerald-700' : 'text-neutral-400'
                      }`}
                    >
                      {isVisible ? 'VISIBLE' : 'HIDDEN'}
                    </span>

                    <button
                      type="button"
                      onClick={() => handleToggleSectionVisibility(sectionKey as keyof SectionVisibility)}
                      className={`w-12 h-6 flex items-center rounded-full p-1 cursor-pointer transition-colors duration-200 ${
                        isVisible ? 'bg-[#473C38]' : 'bg-neutral-300'
                      }`}
                      title={`Click to ${isVisible ? 'hide' : 'show'} this section`}
                    >
                      <div
                        className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform duration-200 ${
                          isVisible ? 'translate-x-6' : 'translate-x-0'
                        }`}
                      />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 2: HERO SHOWCASE CONTENT */}
      {activeTab === 'hero' && (
        <form onSubmit={handleSaveHero} className="bg-white p-6 sm:p-8 border border-[#E3CAAB] shadow-xs space-y-5">
          <div className="flex items-center justify-between pb-3 border-b border-[#E3CAAB]/40">
            <div>
              <h2 className="font-serif text-lg font-medium text-[#292522]">
                Hero Landing Screen Content
              </h2>
              <p className="text-xs text-[#473C38]/70">
                The primary focal point of the AFURN showroom when customers first visit.
              </p>
            </div>

            <button
              type="submit"
              className="px-5 py-2.5 bg-[#473C38] text-white hover:bg-[#B08A62] text-xs font-semibold tracking-wider flex items-center gap-2 transition-colors cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>SAVE HERO</span>
            </button>
          </div>

          <div className="space-y-4 text-xs">
            <div>
              <label className="block font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                Small Tagline / Pre-Heading
              </label>
              <input
                type="text"
                required
                value={heroForm.smallHeading}
                onChange={(e) => setHeroForm({ ...heroForm, smallHeading: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-[#292522] focus:outline-none focus:border-[#473C38]"
              />
            </div>

            <div>
              <label className="block font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                Main Headline (Supports line breaks for editorial styling)
              </label>
              <textarea
                rows={3}
                required
                value={heroForm.mainHeading}
                onChange={(e) => setHeroForm({ ...heroForm, mainHeading: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] font-serif text-base text-[#292522] focus:outline-none focus:border-[#473C38]"
              />
            </div>

            <div>
              <label className="block font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                Supporting Paragraph
              </label>
              <textarea
                rows={2}
                required
                value={heroForm.description}
                onChange={(e) => setHeroForm({ ...heroForm, description: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-[#292522] focus:outline-none focus:border-[#473C38]"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                  Primary Button Text
                </label>
                <input
                  type="text"
                  required
                  value={heroForm.button1Text}
                  onChange={(e) => setHeroForm({ ...heroForm, button1Text: e.target.value })}
                  className="w-full px-3 py-2 bg-[#F7F3EE]/50 border border-[#E3CAAB]"
                />
              </div>

              <div>
                <label className="block font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                  Secondary Button Text
                </label>
                <input
                  type="text"
                  required
                  value={heroForm.button2Text}
                  onChange={(e) => setHeroForm({ ...heroForm, button2Text: e.target.value })}
                  className="w-full px-3 py-2 bg-[#F7F3EE]/50 border border-[#E3CAAB]"
                />
              </div>
            </div>

            <div>
              <label className="block font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                Trust Statement (Footer line under hero)
              </label>
              <input
                type="text"
                value={heroForm.trustStatement}
                onChange={(e) => setHeroForm({ ...heroForm, trustStatement: e.target.value })}
                className="w-full px-3.5 py-2 bg-[#F7F3EE]/50 border border-[#E3CAAB] font-mono text-[#292522]"
              />
            </div>
          </div>
        </form>
      )}

      {/* TAB 3: ABOUT AFURN STORY */}
      {activeTab === 'about' && (
        <form onSubmit={handleSaveAbout} className="bg-white p-6 sm:p-8 border border-[#E3CAAB] shadow-xs space-y-5">
          <div className="flex items-center justify-between pb-3 border-b border-[#E3CAAB]/40">
            <div>
              <h2 className="font-serif text-lg font-medium text-[#292522]">
                About AFURN & 15+ Years Craftsmanship
              </h2>
              <p className="text-xs text-[#473C38]/70">
                Share your manufacturing legacy, Danilimda workshop roots, and master carpenter expertise.
              </p>
            </div>

            <button
              type="submit"
              className="px-5 py-2.5 bg-[#473C38] text-white hover:bg-[#B08A62] text-xs font-semibold tracking-wider flex items-center gap-2 transition-colors cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>SAVE ABOUT STORY</span>
            </button>
          </div>

          <div className="space-y-4 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                  Section Subheading
                </label>
                <input
                  type="text"
                  required
                  value={aboutForm.subheading}
                  onChange={(e) => setAboutForm({ ...aboutForm, subheading: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB]"
                />
              </div>

              <div>
                <label className="block font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                  Main Headline
                </label>
                <input
                  type="text"
                  required
                  value={aboutForm.heading}
                  onChange={(e) => setAboutForm({ ...aboutForm, heading: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] font-serif text-sm"
                />
              </div>
            </div>

            <div>
              <label className="block font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                Story Paragraph 1 (Heritage & Factory Background)
              </label>
              <textarea
                rows={3}
                required
                value={aboutForm.description1}
                onChange={(e) => setAboutForm({ ...aboutForm, description1: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB]"
              />
            </div>

            <div>
              <label className="block font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                Story Paragraph 2 (Materials & Solid Timber Craft)
              </label>
              <textarea
                rows={3}
                required
                value={aboutForm.description2}
                onChange={(e) => setAboutForm({ ...aboutForm, description2: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB]"
              />
            </div>

            {/* Counters */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
              <div className="p-3 border border-[#E3CAAB] bg-[#F7F3EE]/30 space-y-1.5">
                <label className="block font-semibold uppercase tracking-wider text-[#473C38]">
                  Experience Counter
                </label>
                <input
                  type="text"
                  value={aboutForm.experienceNumber}
                  onChange={(e) => setAboutForm({ ...aboutForm, experienceNumber: e.target.value })}
                  className="w-full px-3 py-1.5 bg-white border border-[#E3CAAB] font-serif font-bold text-sm"
                />
                <input
                  type="text"
                  value={aboutForm.experienceLabel}
                  onChange={(e) => setAboutForm({ ...aboutForm, experienceLabel: e.target.value })}
                  className="w-full px-3 py-1 bg-white border border-[#E3CAAB] text-[11px]"
                />
              </div>

              <div className="p-3 border border-[#E3CAAB] bg-[#F7F3EE]/30 space-y-1.5">
                <label className="block font-semibold uppercase tracking-wider text-[#473C38]">
                  Customer Homes Furnished
                </label>
                <input
                  type="text"
                  value={aboutForm.customerNumber}
                  onChange={(e) => setAboutForm({ ...aboutForm, customerNumber: e.target.value })}
                  className="w-full px-3 py-1.5 bg-white border border-[#E3CAAB] font-serif font-bold text-sm"
                />
                <input
                  type="text"
                  value={aboutForm.customerLabel}
                  onChange={(e) => setAboutForm({ ...aboutForm, customerLabel: e.target.value })}
                  className="w-full px-3 py-1 bg-white border border-[#E3CAAB] text-[11px]"
                />
              </div>

              <div className="p-3 border border-[#E3CAAB] bg-[#F7F3EE]/30 space-y-1.5">
                <label className="block font-semibold uppercase tracking-wider text-[#473C38]">
                  Bespoke Pieces Built
                </label>
                <input
                  type="text"
                  value={aboutForm.productsNumber}
                  onChange={(e) => setAboutForm({ ...aboutForm, productsNumber: e.target.value })}
                  className="w-full px-3 py-1.5 bg-white border border-[#E3CAAB] font-serif font-bold text-sm"
                />
                <input
                  type="text"
                  value={aboutForm.productsLabel}
                  onChange={(e) => setAboutForm({ ...aboutForm, productsLabel: e.target.value })}
                  className="w-full px-3 py-1 bg-white border border-[#E3CAAB] text-[11px]"
                />
              </div>
            </div>
          </div>
        </form>
      )}

      {/* TAB 4: WHY CHOOSE US CARDS */}
      {activeTab === 'why_choose_us' && (
        <div className="bg-white p-6 sm:p-8 border border-[#E3CAAB] shadow-xs space-y-5">
          <div className="flex items-center justify-between pb-3 border-b border-[#E3CAAB]/40">
            <div>
              <h2 className="font-serif text-lg font-medium text-[#292522]">
                Why Choose AFURN Value Propositions
              </h2>
              <p className="text-xs text-[#473C38]/70">
                The 6 core selling points that convince homeowners and architects to choose AFURN.
              </p>
            </div>

            <button
              type="button"
              onClick={handleSaveWhyChooseUs}
              className="px-5 py-2.5 bg-[#473C38] text-white hover:bg-[#B08A62] text-xs font-semibold tracking-wider flex items-center gap-2 transition-colors cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>SAVE VALUE CARDS</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {whyChooseUsCards.map((card, idx) => (
              <div key={card.id} className="p-4 border border-[#E3CAAB] bg-[#F7F3EE]/20 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] uppercase font-bold tracking-wider text-[#B08A62]">
                    Value Card #{idx + 1}
                  </span>
                  <label className="flex items-center gap-1.5 text-[11px] font-semibold text-[#473C38] cursor-pointer">
                    <input
                      type="checkbox"
                      checked={card.isVisible}
                      onChange={(e) => {
                        const updated = [...whyChooseUsCards];
                        updated[idx].isVisible = e.target.checked;
                        setWhyChooseUsCards(updated);
                      }}
                      className="w-3.5 h-3.5"
                    />
                    <span>Visible</span>
                  </label>
                </div>

                <div>
                  <input
                    type="text"
                    value={card.title}
                    onChange={(e) => {
                      const updated = [...whyChooseUsCards];
                      updated[idx].title = e.target.value;
                      setWhyChooseUsCards(updated);
                    }}
                    className="w-full px-3 py-1.5 bg-white border border-[#E3CAAB] font-serif text-xs font-bold text-[#292522]"
                  />
                </div>

                <div>
                  <textarea
                    rows={2}
                    value={card.description}
                    onChange={(e) => {
                      const updated = [...whyChooseUsCards];
                      updated[idx].description = e.target.value;
                      setWhyChooseUsCards(updated);
                    }}
                    className="w-full px-3 py-1.5 bg-white border border-[#E3CAAB] text-xs text-[#473C38]"
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
