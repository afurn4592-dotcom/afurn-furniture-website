import React, { useState } from 'react';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import { Lock, Mail, ArrowRight, ShieldCheck, AlertCircle } from 'lucide-react';
import { useData } from '../../context/DataContext';

export default function AdminLogin() {
  const [email, setEmail] = useState('admin@afurn.com');
  const [password, setPassword] = useState('admin123');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const { loginAdmin, isAdminAuthenticated } = useData();
  const navigate = useNavigate();
  const location = useLocation();

  const from = (location.state as any)?.from?.pathname || '/admin/dashboard';

  // If already logged in, redirect
  React.useEffect(() => {
    if (isAdminAuthenticated) {
      navigate('/admin/dashboard', { replace: true });
    }
  }, [isAdminAuthenticated, navigate]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    setTimeout(() => {
      const res = loginAdmin(email, password);
      setLoading(false);
      if (res.success) {
        navigate(from, { replace: true });
      } else {
        setError(res.message || 'Invalid credentials');
      }
    }, 400);
  };

  return (
    <div className="min-h-screen bg-[#F7F3EE] flex flex-col justify-center py-12 sm:px-6 lg:px-8 antialiased">
      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center">
        <Link to="/" className="inline-block">
          <span className="text-4xl font-serif tracking-[0.25em] font-semibold text-[#473C38] block hover:text-[#B08A62] transition-colors">
            AFURN
          </span>
        </Link>
        <h2 className="mt-4 text-xl sm:text-2xl font-serif font-medium text-[#292522]">
          Store Management Console
        </h2>
        <p className="mt-1 text-xs text-[#473C38]/70">
          Enter your authorized credentials to manage inventory & orders
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md px-4">
        <div className="bg-white py-8 px-6 sm:px-10 border border-[#E3CAAB] shadow-xl">
          {error && (
            <div className="mb-6 p-3 bg-red-50 border border-red-200 text-red-800 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1.5">
                Admin Email
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#473C38]/50">
                  <Mail className="w-4 h-4" />
                </div>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="admin@afurn.com"
                  className="w-full pl-10 pr-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1.5">
                Password
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#473C38]/50">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-10 pr-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
                />
              </div>
            </div>

            <div className="pt-2 space-y-3">
              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 bg-[#473C38] text-white hover:bg-[#B08A62] text-xs font-semibold tracking-wider flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-sm disabled:opacity-70"
              >
                <span>{loading ? 'AUTHENTICATING...' : 'LOGIN TO ADMIN'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={() => {
                  loginAdmin('admin@afurn.com', 'admin123');
                  navigate('/admin/dashboard', { replace: true });
                }}
                className="w-full py-2.5 bg-[#B08A62] hover:bg-[#473C38] text-white text-xs font-bold tracking-wider flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-xs"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>1-CLICK QUICK ACCESS (DEVELOPMENT)</span>
              </button>
            </div>
          </form>

          {/* Quick Demo Credentials Tip */}
          <div className="mt-8 pt-6 border-t border-[#E3CAAB]/50 bg-[#F7F3EE]/50 p-4 border border-[#E3CAAB]/40">
            <div className="flex items-center gap-2 text-xs font-semibold text-[#473C38]">
              <ShieldCheck className="w-4 h-4 text-[#B08A62]" />
              <span>Default Store Credentials:</span>
            </div>
            <p className="text-[11px] text-[#473C38]/80 mt-1">
              <strong>Email:</strong> admin@afurn.com<br />
              <strong>Password:</strong> admin123
            </p>
          </div>
        </div>

        <div className="mt-6 text-center">
          <Link
            to="/"
            className="text-xs text-[#473C38]/70 hover:text-[#B08A62] underline transition-colors"
          >
            ← Return to Public Showroom
          </Link>
        </div>
      </div>
    </div>
  );
}
