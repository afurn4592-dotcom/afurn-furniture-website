import React from 'react';
import { Link } from 'react-router-dom';
import {
  Package,
  FolderTree,
  Star,
  CheckCircle2,
  AlertTriangle,
  MessageSquare,
  PlusCircle,
  ArrowRight,
  ExternalLink,
  Phone,
  MessageCircle,
  Eye,
  Sliders,
  Sparkles,
  Palette,
  Clock,
  Menu as MenuIcon,
  Globe
} from 'lucide-react';
import { useData } from '../../context/DataContext';

export default function AdminDashboard() {
  const { products, categories, enquiries, customOrders, settings, recentUpdates } = useData();

  // 6 Metrics specified in prompt
  const totalProducts = products.length;
  const totalCategories = categories.length;
  const activeProducts = products.filter((p) => p.status === 'active').length;
  const featuredProducts = products.filter((p) => p.featured).length;
  const totalEnquiries = enquiries.length;
  const customFurnitureRequests = customOrders.length;

  const recentProducts = products.slice(0, 5);
  const recentEnquiries = enquiries.slice(0, 4);

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      
      {/* Top Banner / Welcome */}
      <div className="bg-white p-6 sm:p-8 border border-[#E3CAAB] shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] tracking-[0.2em] uppercase font-bold text-[#B08A62]">
            OVERVIEW
          </span>
          <h1 className="text-2xl sm:text-3xl font-serif font-medium text-[#292522] mt-0.5">
            Store Performance & Catalog Overview
          </h1>
          <p className="text-xs text-[#473C38]/70 mt-1">
            Real-time management for AFURN furniture manufacturing, inventory, and customer leads.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <Link
            to="/admin/products/new"
            className="px-4 py-2.5 bg-[#473C38] text-white hover:bg-[#B08A62] text-xs font-semibold tracking-wider flex items-center gap-2 transition-colors shadow-xs"
          >
            <PlusCircle className="w-4 h-4" />
            <span>ADD NEW PRODUCT</span>
          </Link>
          <Link
            to="/admin/categories"
            className="px-4 py-2.5 bg-white border border-[#473C38] text-[#473C38] hover:bg-[#F7F3EE] text-xs font-semibold tracking-wider flex items-center gap-2 transition-colors"
          >
            <FolderTree className="w-4 h-4" />
            <span>CATEGORIES</span>
          </Link>
        </div>
      </div>

      {/* 6 Key Stat Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        {/* TOTAL PRODUCTS */}
        <div className="bg-white p-5 border border-[#E3CAAB] shadow-xs hover:border-[#B08A62] transition-colors">
          <div className="flex items-center justify-between">
            <span className="text-[10px] tracking-wider uppercase font-semibold text-[#473C38]/60">
              TOTAL PRODUCTS
            </span>
            <Package className="w-4 h-4 text-[#B08A62]" />
          </div>
          <p className="text-2xl font-serif font-bold text-[#292522] mt-2 tabular-nums">
            {totalProducts}
          </p>
          <Link
            to="/admin/products"
            className="mt-3 inline-flex items-center gap-1 text-[11px] text-[#B08A62] hover:text-[#473C38] font-medium"
          >
            <span>View all</span>
            <ArrowRight className="w-3 h-3" />
          </Link>
        </div>

        {/* TOTAL CATEGORIES */}
        <div className="bg-white p-5 border border-[#E3CAAB] shadow-xs hover:border-[#B08A62] transition-colors">
          <div className="flex items-center justify-between">
            <span className="text-[10px] tracking-wider uppercase font-semibold text-[#473C38]/60">
              TOTAL CATEGORIES
            </span>
            <FolderTree className="w-4 h-4 text-[#B08A62]" />
          </div>
          <p className="text-2xl font-serif font-bold text-[#292522] mt-2 tabular-nums">
            {totalCategories}
          </p>
          <Link
            to="/admin/categories"
            className="mt-3 inline-flex items-center gap-1 text-[11px] text-[#B08A62] hover:text-[#473C38] font-medium"
          >
            <span>Manage</span>
            <ArrowRight className="w-3 h-3" />
          </Link>
        </div>

        {/* ACTIVE PRODUCTS */}
        <div className="bg-white p-5 border border-[#E3CAAB] shadow-xs hover:border-[#B08A62] transition-colors">
          <div className="flex items-center justify-between">
            <span className="text-[10px] tracking-wider uppercase font-semibold text-[#473C38]/60">
              ACTIVE PRODUCTS
            </span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <p className="text-2xl font-serif font-bold text-emerald-700 mt-2 tabular-nums">
            {activeProducts}
          </p>
          <span className="mt-3 block text-[11px] text-emerald-600 font-medium">
            Live on Store
          </span>
        </div>

        {/* FEATURED PRODUCTS */}
        <div className="bg-white p-5 border border-[#E3CAAB] shadow-xs hover:border-[#B08A62] transition-colors">
          <div className="flex items-center justify-between">
            <span className="text-[10px] tracking-wider uppercase font-semibold text-[#473C38]/60">
              FEATURED PRODUCTS
            </span>
            <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
          </div>
          <p className="text-2xl font-serif font-bold text-[#292522] mt-2 tabular-nums">
            {featuredProducts}
          </p>
          <span className="mt-3 block text-[11px] text-[#473C38]/60 font-medium">
            Shown in Highlights
          </span>
        </div>

        {/* TOTAL ENQUIRIES */}
        <div className="bg-white p-5 border border-[#E3CAAB] shadow-xs hover:border-[#B08A62] transition-colors">
          <div className="flex items-center justify-between">
            <span className="text-[10px] tracking-wider uppercase font-semibold text-[#473C38]/60">
              TOTAL ENQUIRIES
            </span>
            <MessageSquare className="w-4 h-4 text-blue-600" />
          </div>
          <p className="text-2xl font-serif font-bold text-[#292522] mt-2 tabular-nums">
            {totalEnquiries}
          </p>
          <Link
            to="/admin/enquiries"
            className="mt-3 inline-flex items-center gap-1 text-[11px] text-blue-600 hover:text-blue-800 font-medium"
          >
            <span>View messages</span>
            <ArrowRight className="w-3 h-3" />
          </Link>
        </div>

        {/* CUSTOM FURNITURE REQUESTS */}
        <div className="bg-white p-5 border border-[#E3CAAB] shadow-xs hover:border-[#B08A62] transition-colors">
          <div className="flex items-center justify-between">
            <span className="text-[10px] tracking-wider uppercase font-semibold text-[#473C38]/60">
              CUSTOM REQUESTS
            </span>
            <Sparkles className="w-4 h-4 text-amber-600" />
          </div>
          <p className="text-2xl font-serif font-bold text-amber-700 mt-2 tabular-nums">
            {customFurnitureRequests}
          </p>
          <Link
            to="/admin/custom-orders"
            className="mt-3 inline-flex items-center gap-1 text-[11px] text-amber-700 hover:text-amber-900 font-medium"
          >
            <span>View custom orders</span>
            <ArrowRight className="w-3 h-3" />
          </Link>
        </div>
      </div>

      {/* Main Grid: Recent Products (Left) & Recent Enquiries (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left: Recent Products Table */}
        <div className="lg:col-span-7 bg-white border border-[#E3CAAB] shadow-xs p-6">
          <div className="flex items-center justify-between pb-4 border-b border-[#E3CAAB]/50">
            <div>
              <h2 className="font-serif text-lg font-medium text-[#292522]">
                Recent Products
              </h2>
              <p className="text-[11px] text-[#473C38]/60">
                Latest additions to your catalog
              </p>
            </div>
            <Link
              to="/admin/products"
              className="text-xs text-[#B08A62] hover:text-[#473C38] font-semibold flex items-center gap-1"
            >
              <span>View All</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          <div className="divide-y divide-[#E3CAAB]/30 mt-2 overflow-x-auto">
            {recentProducts.map((p) => (
              <div key={p.id} className="py-3 flex items-center justify-between gap-4">
                <div className="flex items-center gap-3 min-w-0">
                  <img
                    src={p.image}
                    alt={p.name}
                    className="w-12 h-12 object-cover bg-[#F7F3EE] shrink-0 border border-[#E3CAAB]/60"
                  />
                  <div className="truncate">
                    <p className="text-xs font-semibold text-[#292522] truncate">
                      {p.name}
                    </p>
                    <p className="text-[10px] text-[#473C38]/60">
                      {p.categoryLabel || p.categoryId} • SKU: {p.sku}
                    </p>
                    <p className="text-xs font-serif font-bold text-[#473C38] mt-0.5 tabular-nums">
                      ₹{p.price.toLocaleString('en-IN')}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3 shrink-0">
                  <span
                    className={`px-2 py-0.5 text-[10px] font-semibold tracking-wider uppercase ${
                      p.status === 'active'
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        : 'bg-neutral-100 text-neutral-600 border border-neutral-300'
                    }`}
                  >
                    {p.status}
                  </span>
                  <Link
                    to={`/admin/products/edit/${p.id}`}
                    className="px-2.5 py-1 text-xs border border-[#473C38] text-[#473C38] hover:bg-[#473C38] hover:text-white transition-colors"
                  >
                    Edit
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right: Recent Enquiries */}
        <div className="lg:col-span-5 bg-white border border-[#E3CAAB] shadow-xs p-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-[#E3CAAB]/50">
              <div>
                <h2 className="font-serif text-lg font-medium text-[#292522]">
                  Recent Inquiries
                </h2>
                <p className="text-[11px] text-[#473C38]/60">
                  Customer messages & WhatsApp quote requests
                </p>
              </div>
              <Link
                to="/admin/enquiries"
                className="text-xs text-[#B08A62] hover:text-[#473C38] font-semibold flex items-center gap-1"
              >
                <span>All Leads</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>

            <div className="divide-y divide-[#E3CAAB]/30 mt-2">
              {recentEnquiries.map((enq) => (
                <div key={enq.id} className="py-3">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <p className="text-xs font-semibold text-[#292522]">
                        {enq.customerName}
                      </p>
                      <p className="text-[11px] text-[#473C38]/70">
                        {enq.phone} • {enq.type}
                      </p>
                    </div>
                    <span
                      className={`px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider ${
                        enq.status === 'NEW'
                          ? 'bg-amber-100 text-amber-800'
                          : enq.status === 'CONTACTED'
                          ? 'bg-blue-100 text-blue-800'
                          : 'bg-emerald-100 text-emerald-800'
                      }`}
                    >
                      {enq.status}
                    </span>
                  </div>
                  <p className="text-xs text-[#473C38]/85 mt-1 line-clamp-2 italic bg-[#F7F3EE]/60 p-2 border border-[#E3CAAB]/30">
                    "{enq.message}"
                  </p>
                  <div className="mt-2 flex items-center gap-3 text-xs">
                    <a
                      href={`https://wa.me/91${enq.phone.replace(/[^0-9]/g, '')}`}
                      target="_blank"
                      rel="noreferrer"
                      className="text-emerald-700 hover:text-emerald-800 font-medium inline-flex items-center gap-1"
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                      <span>WhatsApp</span>
                    </a>
                    <a
                      href={`tel:${enq.phone}`}
                      className="text-[#473C38] hover:text-[#B08A62] font-medium inline-flex items-center gap-1"
                    >
                      <Phone className="w-3.5 h-3.5" />
                      <span>Call</span>
                    </a>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="pt-4 border-t border-[#E3CAAB]/40 mt-4">
            <Link
              to="/admin/custom-orders"
              className="w-full py-2 bg-[#F7F3EE] hover:bg-[#E3CAAB]/30 text-[#473C38] text-xs font-semibold tracking-wider border border-[#E3CAAB] flex items-center justify-center gap-2 transition-colors"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#B08A62]" />
              <span>VIEW {customOrders.length} CUSTOM FURNITURE REQUESTS</span>
            </Link>
          </div>
        </div>

      </div>

      {/* Recently Updated Content */}
      <div className="bg-white border border-[#E3CAAB] shadow-xs p-6">
        <div className="flex items-center justify-between pb-4 border-b border-[#E3CAAB]/50">
          <div>
            <h2 className="font-serif text-lg font-medium text-[#292522] flex items-center gap-2">
              <Clock className="w-4 h-4 text-[#B08A62]" />
              <span>Recently Updated Content</span>
            </h2>
            <p className="text-[11px] text-[#473C38]/60">
              Audit log of changes across website sections, products, colors, and navigation
            </p>
          </div>
          <div className="flex items-center gap-2 text-xs">
            <Link
              to="/admin/customization"
              className="px-3 py-1.5 bg-[#F7F3EE] hover:bg-[#E3CAAB]/30 text-[#473C38] border border-[#E3CAAB] font-semibold text-[11px] flex items-center gap-1.5 transition-colors"
            >
              <Palette className="w-3.5 h-3.5 text-[#B08A62]" />
              <span>Customize Site</span>
            </Link>
          </div>
        </div>

        <div className="divide-y divide-[#E3CAAB]/30 mt-2">
          {recentUpdates.map((item) => (
            <div key={item.id} className="py-3 flex items-center justify-between gap-4 hover:bg-[#F7F3EE]/20 transition-colors">
              <div className="flex items-center gap-3">
                <span className="w-2 h-2 rounded-full bg-[#B08A62]" />
                <div>
                  <p className="text-xs font-semibold text-[#292522]">
                    {item.title}
                  </p>
                  <p className="text-[10px] text-[#473C38]/60">
                    Category: <span className="font-semibold text-[#473C38]">{item.category}</span>
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3 shrink-0">
                <span className="text-[10px] font-mono text-[#473C38]/60">
                  {item.timestamp}
                </span>
                <Link
                  to={
                    item.category === 'Customization'
                      ? '/admin/customization'
                      : item.category === 'Navigation'
                      ? '/admin/navigation'
                      : item.category === 'Banners'
                      ? '/admin/banners'
                      : item.category === 'SEO'
                      ? '/admin/seo'
                      : item.category === 'Products'
                      ? '/admin/products'
                      : '/admin/homepage'
                  }
                  className="px-2.5 py-1 text-[11px] border border-[#473C38] text-[#473C38] hover:bg-[#473C38] hover:text-white transition-colors"
                >
                  Manage
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Quick Website Controls Bar */}
      <div className="bg-[#473C38] text-white p-6 border border-[#B08A62] shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <h3 className="font-serif text-lg font-medium text-[#E3CAAB]">
            Ready to adjust your live storefront?
          </h3>
          <p className="text-xs text-white/80 mt-0.5">
            Turn sections on/off, customize colors, edit navigation links, or update SEO instantly.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Link
            to="/admin/customization"
            className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white text-xs font-semibold tracking-wider flex items-center gap-1.5 transition-colors border border-white/20"
          >
            <Palette className="w-3.5 h-3.5" />
            <span>CUSTOMIZATION</span>
          </Link>
          <Link
            to="/admin/homepage"
            className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white text-xs font-semibold tracking-wider flex items-center gap-1.5 transition-colors border border-white/20"
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>SECTIONS CONTROL</span>
          </Link>
          <Link
            to="/admin/settings"
            className="px-4 py-2 bg-[#B08A62] hover:bg-[#E3CAAB] hover:text-[#473C38] text-white text-xs font-semibold tracking-wider flex items-center gap-1.5 transition-colors"
          >
            <span>WEBSITE SETTINGS</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      </div>

    </div>
  );
}
