import React, { useState } from 'react';
import {
  Menu,
  Plus,
  Trash2,
  ArrowUp,
  ArrowDown,
  Eye,
  EyeOff,
  CheckCircle2,
  Save,
  RotateCcw,
  ExternalLink,
  Link as LinkIcon
} from 'lucide-react';
import { useData } from '../../context/DataContext';
import { NavItem } from '../../types/furniture';

export default function AdminNavigation() {
  const { settings, updateNavigation } = useData();

  const [navItems, setNavItems] = useState<NavItem[]>(() => {
    return settings.navigation && settings.navigation.length > 0
      ? [...settings.navigation]
      : [
          { id: 'nav-1', label: 'HOME', href: '#home', order: 1, isVisible: true },
          { id: 'nav-2', label: 'SHOP', href: '#shop', order: 2, isVisible: true },
          { id: 'nav-3', label: 'CATEGORIES', href: '#categories', order: 3, isVisible: true },
          { id: 'nav-4', label: 'ABOUT US', href: '#about', order: 4, isVisible: true },
          { id: 'nav-5', label: 'CUSTOM FURNITURE', href: '#custom', order: 5, isVisible: true },
          { id: 'nav-6', label: 'GALLERY', href: '#gallery', order: 6, isVisible: true },
          { id: 'nav-7', label: 'CONTACT', href: '#contact', order: 7, isVisible: true },
        ];
  });

  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [newLabel, setNewLabel] = useState('');
  const [newHref, setNewHref] = useState('');
  const [savedSuccess, setSavedSuccess] = useState(false);

  // Move Item Up
  const handleMoveUp = (index: number) => {
    if (index === 0) return;
    const items = [...navItems];
    const temp = items[index];
    items[index] = items[index - 1];
    items[index - 1] = temp;
    // update order numbers
    items.forEach((item, idx) => (item.order = idx + 1));
    setNavItems(items);
  };

  // Move Item Down
  const handleMoveDown = (index: number) => {
    if (index === navItems.length - 1) return;
    const items = [...navItems];
    const temp = items[index];
    items[index] = items[index + 1];
    items[index + 1] = temp;
    items.forEach((item, idx) => (item.order = idx + 1));
    setNavItems(items);
  };

  // Toggle Visibility
  const handleToggleVisibility = (id: string) => {
    setNavItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, isVisible: !item.isVisible } : item))
    );
  };

  // Edit Label or URL
  const handleUpdateItem = (id: string, field: 'label' | 'href', value: string) => {
    setNavItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, [field]: value } : item))
    );
  };

  // Delete Link
  const handleDeleteItem = (id: string) => {
    if (navItems.length <= 1) {
      alert('You must have at least one navigation item.');
      return;
    }
    if (window.confirm('Are you sure you want to remove this navigation link?')) {
      const filtered = navItems.filter((i) => i.id !== id);
      filtered.forEach((item, idx) => (item.order = idx + 1));
      setNavItems(filtered);
    }
  };

  // Add New Item
  const handleAddItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newLabel.trim() || !newHref.trim()) return;

    const newItem: NavItem = {
      id: `nav-${Date.now()}`,
      label: newLabel.trim().toUpperCase(),
      href: newHref.trim(),
      order: navItems.length + 1,
      isVisible: true,
      isCustom: true,
    };

    setNavItems((prev) => [...prev, newItem]);
    setNewLabel('');
    setNewHref('');
    setIsAddModalOpen(false);
  };

  // Save all to database
  const handleSave = () => {
    updateNavigation(navItems);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  // Reset to default
  const handleResetDefaults = () => {
    if (window.confirm('Reset navigation links back to default AFURN showroom menu?')) {
      const defaults: NavItem[] = [
        { id: 'nav-1', label: 'HOME', href: '#home', order: 1, isVisible: true },
        { id: 'nav-2', label: 'SHOP', href: '#shop', order: 2, isVisible: true },
        { id: 'nav-3', label: 'CATEGORIES', href: '#categories', order: 3, isVisible: true },
        { id: 'nav-4', label: 'ABOUT US', href: '#about', order: 4, isVisible: true },
        { id: 'nav-5', label: 'CUSTOM FURNITURE', href: '#custom', order: 5, isVisible: true },
        { id: 'nav-6', label: 'GALLERY', href: '#gallery', order: 6, isVisible: true },
        { id: 'nav-7', label: 'CONTACT', href: '#contact', order: 7, isVisible: true },
      ];
      setNavItems(defaults);
      updateNavigation(defaults);
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 3000);
    }
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Top Header */}
      <div className="bg-white p-6 border border-[#E3CAAB] shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] tracking-[0.2em] uppercase font-bold text-[#B08A62]">
            SITE STRUCTURE & LINKS
          </span>
          <h1 className="text-2xl font-serif font-medium text-[#292522] mt-0.5">
            Storefront Navigation Management
          </h1>
          <p className="text-xs text-[#473C38]/70 mt-1">
            Add, reorder, rename, or toggle visibility of navigation links across your header and menu.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={handleResetDefaults}
            className="px-3.5 py-2.5 bg-white border border-[#473C38] text-[#473C38] hover:bg-[#F7F3EE] text-xs font-semibold tracking-wider flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>RESET</span>
          </button>

          <button
            type="button"
            onClick={() => setIsAddModalOpen(true)}
            className="px-4 py-2.5 bg-white border border-[#B08A62] text-[#B08A62] hover:bg-[#B08A62] hover:text-white text-xs font-semibold tracking-wider flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>ADD LINK</span>
          </button>

          <button
            type="button"
            onClick={handleSave}
            className="px-5 py-2.5 bg-[#473C38] text-white hover:bg-[#B08A62] text-xs font-semibold tracking-wider flex items-center gap-2 transition-colors shadow-xs cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>SAVE NAVIGATION</span>
          </button>
        </div>
      </div>

      {savedSuccess && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2.5 animate-fade-in shadow-xs">
          <CheckCircle2 className="w-5 h-5 shrink-0 text-emerald-600" />
          <span>
            <strong>Updated!</strong> Navigation menu updated successfully. Storefront header now reflects the new link ordering and titles.
          </span>
        </div>
      )}

      {/* Simulated Live Navbar Preview */}
      <div className="bg-white p-5 border border-[#E3CAAB] shadow-xs space-y-3">
        <div className="flex items-center justify-between text-xs pb-3 border-b border-[#E3CAAB]/50">
          <span className="font-semibold text-[#473C38] uppercase tracking-wider">
            Live Header Navigation Preview
          </span>
          <span className="text-[11px] text-[#473C38]/60">
            {navItems.filter((i) => i.isVisible).length} active visible links
          </span>
        </div>

        <div className="p-4 bg-[#F7F3EE] border border-[#E3CAAB]/70 flex flex-wrap items-center justify-between gap-4">
          <span className="font-serif text-xl tracking-[0.2em] font-bold text-[#473C38]">
            {settings.businessName || 'AFURN'}
          </span>

          <div className="flex flex-wrap items-center gap-4 text-xs tracking-[0.14em] font-semibold text-[#292522]">
            {navItems
              .filter((item) => item.isVisible)
              .map((item) => (
                <span
                  key={item.id}
                  className="hover:text-[#B08A62] transition-colors py-1 cursor-default border-b-2 border-transparent hover:border-[#B08A62]"
                >
                  {item.label}
                </span>
              ))}
          </div>
        </div>
      </div>

      {/* Navigation Items Table / List */}
      <div className="bg-white border border-[#E3CAAB] shadow-xs divide-y divide-[#E3CAAB]/40">
        <div className="p-4 bg-[#F7F3EE]/40 text-xs font-semibold uppercase tracking-wider text-[#473C38] grid grid-cols-12 gap-3 items-center">
          <span className="col-span-1 text-center">Order</span>
          <span className="col-span-4">Menu Label</span>
          <span className="col-span-4">Target URL / Anchor</span>
          <span className="col-span-3 text-right">Actions</span>
        </div>

        {navItems.map((item, index) => (
          <div
            key={item.id}
            className={`p-4 grid grid-cols-12 gap-3 items-center transition-colors ${
              !item.isVisible ? 'bg-neutral-50/70 opacity-60' : 'hover:bg-[#F7F3EE]/20'
            }`}
          >
            {/* Reorder Buttons & Position */}
            <div className="col-span-1 flex items-center justify-center gap-1">
              <span className="text-xs font-mono font-bold text-[#473C38]/70 mr-1">
                {index + 1}
              </span>
              <div className="flex flex-col">
                <button
                  type="button"
                  onClick={() => handleMoveUp(index)}
                  disabled={index === 0}
                  className="p-0.5 text-[#473C38] hover:text-[#B08A62] disabled:opacity-20 cursor-pointer disabled:cursor-not-allowed"
                  title="Move Up"
                >
                  <ArrowUp className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => handleMoveDown(index)}
                  disabled={index === navItems.length - 1}
                  className="p-0.5 text-[#473C38] hover:text-[#B08A62] disabled:opacity-20 cursor-pointer disabled:cursor-not-allowed"
                  title="Move Down"
                >
                  <ArrowDown className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Label Input */}
            <div className="col-span-4">
              <input
                type="text"
                value={item.label}
                onChange={(e) => handleUpdateItem(item.id, 'label', e.target.value)}
                className="w-full px-3 py-1.5 bg-white border border-[#E3CAAB] text-xs font-semibold text-[#292522] focus:outline-none focus:border-[#473C38]"
              />
            </div>

            {/* URL / Anchor Input */}
            <div className="col-span-4 flex items-center gap-1.5">
              <LinkIcon className="w-3.5 h-3.5 text-[#473C38]/40 shrink-0" />
              <input
                type="text"
                value={item.href}
                onChange={(e) => handleUpdateItem(item.id, 'href', e.target.value)}
                placeholder="#section or https://"
                className="w-full px-3 py-1.5 bg-white border border-[#E3CAAB] text-xs font-mono text-[#292522] focus:outline-none focus:border-[#473C38]"
              />
            </div>

            {/* Actions: Visibility Toggle & Delete */}
            <div className="col-span-3 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => handleToggleVisibility(item.id)}
                className={`px-3 py-1 text-[11px] font-semibold tracking-wider uppercase border flex items-center gap-1.5 transition-colors cursor-pointer ${
                  item.isVisible
                    ? 'border-emerald-300 text-emerald-700 bg-emerald-50 hover:bg-emerald-100'
                    : 'border-neutral-300 text-neutral-500 bg-neutral-100 hover:bg-neutral-200'
                }`}
                title="Toggle Show / Hide in Header"
              >
                {item.isVisible ? (
                  <>
                    <Eye className="w-3 h-3" />
                    <span>VISIBLE</span>
                  </>
                ) : (
                  <>
                    <EyeOff className="w-3 h-3" />
                    <span>HIDDEN</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={() => handleDeleteItem(item.id)}
                className="p-1.5 text-red-500 hover:text-red-700 hover:bg-red-50 border border-transparent hover:border-red-200 transition-colors cursor-pointer"
                title="Delete Link"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Quick Section Anchor Helper */}
      <div className="bg-[#F7F3EE] p-4 border border-[#E3CAAB] text-xs space-y-2">
        <p className="font-semibold text-[#473C38] uppercase tracking-wider">
          Standard AFURN Page Anchor Targets:
        </p>
        <div className="flex flex-wrap gap-2 text-[11px] font-mono">
          {['#home', '#shop', '#categories', '#custom', '#about', '#gallery', '#testimonials', '#contact'].map(
            (anchor) => (
              <span key={anchor} className="bg-white px-2.5 py-1 border border-[#E3CAAB] text-[#473C38]">
                {anchor}
              </span>
            )
          )}
        </div>
      </div>

      {/* Add New Link Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white max-w-md w-full border border-[#E3CAAB] p-6 shadow-2xl space-y-5 animate-scale-in">
            <h3 className="font-serif text-lg font-medium text-[#292522]">
              Add Storefront Navigation Link
            </h3>

            <form onSubmit={handleAddItem} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                  Menu Label (e.g., DINING, OFFERS)
                </label>
                <input
                  type="text"
                  required
                  value={newLabel}
                  onChange={(e) => setNewLabel(e.target.value)}
                  placeholder="CUSTOM FURNITURE"
                  className="w-full px-3 py-2 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-[#292522] focus:outline-none focus:border-[#473C38]"
                />
              </div>

              <div>
                <label className="block font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                  Target Link / Anchor
                </label>
                <input
                  type="text"
                  required
                  value={newHref}
                  onChange={(e) => setNewHref(e.target.value)}
                  placeholder="#shop or https://..."
                  className="w-full px-3 py-2 bg-[#F7F3EE]/50 border border-[#E3CAAB] font-mono text-[#292522] focus:outline-none focus:border-[#473C38]"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#E3CAAB]/50">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 border border-[#473C38] text-[#473C38] hover:bg-[#F7F3EE] font-semibold cursor-pointer"
                >
                  CANCEL
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#473C38] text-white hover:bg-[#B08A62] font-semibold cursor-pointer"
                >
                  ADD TO MENU
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
