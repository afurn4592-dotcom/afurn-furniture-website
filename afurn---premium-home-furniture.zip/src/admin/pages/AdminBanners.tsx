import React, { useState } from 'react';
import {
  Megaphone,
  Plus,
  Trash2,
  Edit2,
  CheckCircle2,
  Save,
  Eye,
  EyeOff,
  Image as ImageIcon,
  ArrowRight,
  ExternalLink,
  RotateCcw
} from 'lucide-react';
import { useData } from '../../context/DataContext';
import { BannerItem } from '../../types/furniture';
import heroImg from '../../assets/images/hero_luxury_living_1791199438602.jpg';

export default function AdminBanners() {
  const { settings, updateBanners } = useData();

  const [banners, setBanners] = useState<BannerItem[]>(() => {
    return settings.banners && settings.banners.length > 0
      ? [...settings.banners]
      : [
          {
            id: 'banner-1',
            title: 'Festive Solid Teak Showcase 2026',
            subtitle: 'Direct factory pricing on handcrafted living room sets & dining suites in Ahmedabad.',
            image: heroImg,
            buttonText: 'EXPLORE OFFERS',
            buttonLink: '#shop',
            isActive: true,
            displayOrder: 1,
          },
          {
            id: 'banner-2',
            title: 'Free White-Glove Ahmedabad Delivery & Assembly',
            subtitle: 'Direct delivery from our Danilimda manufacturing unit with professional installation included.',
            image: '',
            buttonText: 'VISIT SHOWROOM',
            buttonLink: '#contact',
            isActive: true,
            displayOrder: 2,
          }
        ];
  });

  const [editingBanner, setEditingBanner] = useState<BannerItem | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);

  // New Banner Form State
  const [formData, setFormData] = useState<Omit<BannerItem, 'id'>>({
    title: '',
    subtitle: '',
    image: '',
    buttonText: 'SHOP NOW',
    buttonLink: '#shop',
    isActive: true,
    displayOrder: 1,
  });

  const handleToggleActive = (id: string) => {
    setBanners((prev) =>
      prev.map((b) => (b.id === id ? { ...b, isActive: !b.isActive } : b))
    );
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Are you sure you want to delete this promotional banner?')) {
      setBanners((prev) => prev.filter((b) => b.id !== id));
    }
  };

  const handleOpenAdd = () => {
    setFormData({
      title: '',
      subtitle: '',
      image: '',
      buttonText: 'SHOP NOW',
      buttonLink: '#shop',
      isActive: true,
      displayOrder: banners.length + 1,
    });
    setEditingBanner(null);
    setIsAddModalOpen(true);
  };

  const handleOpenEdit = (b: BannerItem) => {
    setEditingBanner(b);
    setFormData({
      title: b.title,
      subtitle: b.subtitle,
      image: b.image,
      buttonText: b.buttonText,
      buttonLink: b.buttonLink,
      isActive: b.isActive,
      displayOrder: b.displayOrder,
    });
    setIsAddModalOpen(true);
  };

  const handleSubmitForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingBanner) {
      setBanners((prev) =>
        prev.map((b) => (b.id === editingBanner.id ? { ...b, ...formData } : b))
      );
    } else {
      const newBanner: BannerItem = {
        id: `banner-${Date.now()}`,
        ...formData,
        displayOrder: banners.length + 1,
      };
      setBanners((prev) => [...prev, newBanner]);
    }
    setIsAddModalOpen(false);
  };

  const handleSaveToDb = () => {
    updateBanners(banners);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const handleResetDefaults = () => {
    if (window.confirm('Reset promotional banners back to showroom defaults?')) {
      const defaults: BannerItem[] = [
        {
          id: 'banner-1',
          title: 'Direct Factory Teakwood Collection',
          subtitle: 'Solid seasoned wood and heavy structural steel crafted in Danilimda, Ahmedabad.',
          image: heroImg,
          buttonText: 'SHOP FURNITURE',
          buttonLink: '#shop',
          isActive: true,
          displayOrder: 1,
        }
      ];
      setBanners(defaults);
      updateBanners(defaults);
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 3000);
    }
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Top Header */}
      <div className="bg-white p-6 border border-[#E3CAAB] shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] tracking-[0.2em] uppercase font-bold text-[#B08A62]">
            MARKETING & PROMOTIONS
          </span>
          <h1 className="text-2xl font-serif font-medium text-[#292522] mt-0.5">
            Promotional Banners & Announcements
          </h1>
          <p className="text-xs text-[#473C38]/70 mt-1">
            Display seasonal sale offers, factory discount announcements, and delivery perks on the storefront.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={handleResetDefaults}
            className="px-3.5 py-2.5 bg-white border border-[#473C38] text-[#473C38] hover:bg-[#F7F3EE] text-xs font-semibold tracking-wider flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>RESET</span>
          </button>

          <button
            type="button"
            onClick={handleOpenAdd}
            className="px-4 py-2.5 bg-white border border-[#B08A62] text-[#B08A62] hover:bg-[#B08A62] hover:text-white text-xs font-semibold tracking-wider flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>ADD BANNER</span>
          </button>

          <button
            type="button"
            onClick={handleSaveToDb}
            className="px-5 py-2.5 bg-[#473C38] text-white hover:bg-[#B08A62] text-xs font-semibold tracking-wider flex items-center gap-2 transition-colors shadow-xs cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>SAVE BANNERS</span>
          </button>
        </div>
      </div>

      {savedSuccess && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2.5 animate-fade-in shadow-xs">
          <CheckCircle2 className="w-5 h-5 shrink-0 text-emerald-600" />
          <span>
            <strong>Saved!</strong> Promotional banners updated successfully. Live storefront now displays your updated announcements.
          </span>
        </div>
      )}

      {/* Banners Grid */}
      <div className="space-y-4">
        {banners.map((banner) => (
          <div
            key={banner.id}
            className={`bg-white border transition-all ${
              banner.isActive ? 'border-[#E3CAAB] shadow-xs' : 'border-neutral-200 bg-neutral-50/70 opacity-60'
            }`}
          >
            <div className="p-6 flex flex-col md:flex-row md:items-center justify-between gap-6">
              
              {/* Left: Thumbnail & Content */}
              <div className="flex items-start gap-4">
                {banner.image ? (
                  <img
                    src={banner.image}
                    alt={banner.title}
                    className="w-24 h-24 object-cover border border-[#E3CAAB] bg-[#F7F3EE] shrink-0"
                  />
                ) : (
                  <div className="w-24 h-24 bg-[#E3CAAB]/30 border border-[#E3CAAB] flex flex-col items-center justify-center text-[#473C38]/60 shrink-0">
                    <Megaphone className="w-6 h-6 text-[#B08A62] mb-1" />
                    <span className="text-[10px] uppercase font-bold tracking-wider">Announcement</span>
                  </div>
                )}

                <div className="space-y-1.5 max-w-xl">
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 ${
                        banner.isActive
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-neutral-200 text-neutral-600'
                      }`}
                    >
                      {banner.isActive ? 'ACTIVE ON SITE' : 'INACTIVE (PAUSED)'}
                    </span>
                    <span className="text-[11px] text-[#473C38]/60">
                      Link: {banner.buttonLink}
                    </span>
                  </div>

                  <h3 className="font-serif text-lg font-semibold text-[#292522]">
                    {banner.title}
                  </h3>

                  <p className="text-xs text-[#473C38]/80 leading-relaxed">
                    {banner.subtitle}
                  </p>

                  <div className="pt-1">
                    <span className="inline-flex items-center gap-1 text-xs font-semibold text-[#B08A62]">
                      Button: "{banner.buttonText}"
                      <ArrowRight className="w-3 h-3" />
                    </span>
                  </div>
                </div>
              </div>

              {/* Right: Actions */}
              <div className="flex items-center gap-3 shrink-0 self-end md:self-center">
                <button
                  type="button"
                  onClick={() => handleToggleActive(banner.id)}
                  className={`px-3 py-1.5 text-xs font-semibold tracking-wider uppercase border flex items-center gap-1.5 transition-colors cursor-pointer ${
                    banner.isActive
                      ? 'border-emerald-300 text-emerald-800 bg-emerald-50 hover:bg-emerald-100'
                      : 'border-neutral-300 text-neutral-600 bg-neutral-100 hover:bg-neutral-200'
                  }`}
                >
                  {banner.isActive ? (
                    <>
                      <Eye className="w-3.5 h-3.5" />
                      <span>LIVE</span>
                    </>
                  ) : (
                    <>
                      <EyeOff className="w-3.5 h-3.5" />
                      <span>PAUSED</span>
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => handleOpenEdit(banner)}
                  className="px-3 py-1.5 border border-[#473C38] text-[#473C38] hover:bg-[#473C38] hover:text-white text-xs font-semibold tracking-wider flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                  <span>EDIT</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleDelete(banner.id)}
                  className="p-1.5 text-red-500 hover:text-red-700 hover:bg-red-50 border border-transparent hover:border-red-200 transition-colors cursor-pointer"
                  title="Delete Banner"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>

            </div>
          </div>
        ))}
      </div>

      {/* Add / Edit Banner Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white max-w-lg w-full border border-[#E3CAAB] p-6 shadow-2xl space-y-5 animate-scale-in">
            <h3 className="font-serif text-xl font-medium text-[#292522]">
              {editingBanner ? 'Edit Promotional Banner' : 'Add New Promotional Banner'}
            </h3>

            <form onSubmit={handleSubmitForm} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                  Banner Headline
                </label>
                <input
                  type="text"
                  required
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="Diwali Furniture Festival: Direct Factory Pricing"
                  className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-[#292522] focus:outline-none focus:border-[#473C38]"
                />
              </div>

              <div>
                <label className="block font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                  Subtitle / Promo Text
                </label>
                <textarea
                  rows={2}
                  required
                  value={formData.subtitle}
                  onChange={(e) => setFormData({ ...formData, subtitle: e.target.value })}
                  placeholder="Special pricing on teak dining tables, swings, and sofas with free delivery across Ahmedabad."
                  className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-[#292522] focus:outline-none focus:border-[#473C38]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                    Button Text
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.buttonText}
                    onChange={(e) => setFormData({ ...formData, buttonText: e.target.value })}
                    className="w-full px-3 py-2 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-[#292522]"
                  />
                </div>

                <div>
                  <label className="block font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                    Target Link / Anchor
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.buttonLink}
                    onChange={(e) => setFormData({ ...formData, buttonLink: e.target.value })}
                    placeholder="#shop or #contact"
                    className="w-full px-3 py-2 bg-[#F7F3EE]/50 border border-[#E3CAAB] font-mono text-[#292522]"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                  Banner Image URL (Optional)
                </label>
                <input
                  type="url"
                  value={formData.image}
                  onChange={(e) => setFormData({ ...formData, image: e.target.value })}
                  placeholder="https://... (leave blank for announcement card)"
                  className="w-full px-3.5 py-2 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-[#292522]"
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <input
                  type="checkbox"
                  id="banner-active"
                  checked={formData.isActive}
                  onChange={(e) => setFormData({ ...formData, isActive: e.target.checked })}
                  className="w-4 h-4 text-[#473C38] cursor-pointer"
                />
                <label htmlFor="banner-active" className="font-semibold text-[#473C38] cursor-pointer">
                  Activate banner on public website immediately
                </label>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#E3CAAB]/50">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 border border-[#473C38] text-[#473C38] hover:bg-[#F7F3EE] font-semibold cursor-pointer"
                >
                  CANCEL
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#473C38] text-white hover:bg-[#B08A62] font-semibold cursor-pointer"
                >
                  {editingBanner ? 'UPDATE BANNER' : 'ADD BANNER'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
