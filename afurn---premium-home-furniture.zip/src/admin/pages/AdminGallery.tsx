import React, { useState } from 'react';
import {
  ImageIcon,
  PlusCircle,
  Trash2,
  Edit,
  Eye,
  EyeOff,
  Upload,
  X,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { useData } from '../../context/DataContext';
import { GalleryItem } from '../../types/furniture';
import { optimizeImageFile } from '../../utils/imageUpload';
import { IMAGES } from '../../data/furnitureData';

export default function AdminGallery() {
  const { gallery, addGalleryItem, updateGalleryItem, deleteGalleryItem } = useData();

  const [modalOpen, setModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<GalleryItem | null>(null);

  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('Living Room');
  const [details, setDetails] = useState('');
  const [image, setImage] = useState('');
  const [displayOrder, setDisplayOrder] = useState<number>(1);
  const [status, setStatus] = useState<'active' | 'inactive'>('active');

  const [error, setError] = useState<string | null>(null);
  const [uploadLoading, setUploadLoading] = useState(false);

  const categoriesOptions = [
    'Residential',
    'Dining Spaces',
    'Lounge',
    'Wooden Jhula',
    'Living Room',
    'Workspace',
    'Custom Furniture',
    'Commercial / Cafe',
  ];

  const openAdd = () => {
    setEditingItem(null);
    setTitle('');
    setCategory('Residential');
    setDetails('');
    setImage(IMAGES.hero);
    setDisplayOrder(gallery.length + 1);
    setStatus('active');
    setError(null);
    setModalOpen(true);
  };

  const openEdit = (item: GalleryItem) => {
    setEditingItem(item);
    setTitle(item.title);
    setCategory(item.category);
    setDetails(item.details);
    setImage(item.image);
    setDisplayOrder(item.displayOrder || 1);
    setStatus(item.status || 'active');
    setError(null);
    setModalOpen(true);
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setUploadLoading(true);
      setError(null);
      const optimizedUrl = await optimizeImageFile(file);
      setImage(optimizedUrl);
    } catch (err: any) {
      setError(err.message || 'Failed to upload image.');
    } finally {
      setUploadLoading(false);
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setError('Title is required.');
      return;
    }
    if (!image) {
      setError('Image is required.');
      return;
    }

    const payload = {
      title: title.trim(),
      category: category.trim(),
      details: details.trim(),
      image,
      displayOrder: Number(displayOrder) || 1,
      status,
    };

    if (editingItem) {
      updateGalleryItem(editingItem.id, payload);
    } else {
      addGalleryItem(payload);
    }

    setModalOpen(false);
  };

  const handleToggleStatus = (item: GalleryItem) => {
    updateGalleryItem(item.id, {
      status: item.status === 'active' ? 'inactive' : 'active',
    });
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      
      {/* Top Header */}
      <div className="bg-white p-6 border border-[#E3CAAB] shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] tracking-[0.2em] uppercase font-bold text-[#B08A62]">
            VISUAL ASSETS
          </span>
          <h1 className="text-2xl font-serif font-medium text-[#292522] mt-0.5">
            Showroom Gallery Management ({gallery.length})
          </h1>
          <p className="text-xs text-[#473C38]/70 mt-1">
            Manage finished client homes, luxury villa projects, and showroom photographs.
          </p>
        </div>

        <button
          onClick={openAdd}
          className="px-5 py-3 bg-[#473C38] text-white hover:bg-[#B08A62] text-xs font-semibold tracking-wider flex items-center justify-center gap-2 transition-colors shadow-xs cursor-pointer shrink-0"
        >
          <PlusCircle className="w-4 h-4" />
          <span>ADD GALLERY PHOTO</span>
        </button>
      </div>

      {/* Gallery Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {gallery.map((item) => (
          <div
            key={item.id}
            className="bg-white border border-[#E3CAAB] shadow-xs overflow-hidden flex flex-col justify-between"
          >
            <div className="relative aspect-[4/3] bg-[#F7F3EE] overflow-hidden">
              <img
                src={item.image}
                alt={item.title}
                className="w-full h-full object-cover"
              />
              <span className="absolute top-2 left-2 bg-[#473C38] text-white text-[10px] font-semibold tracking-wider uppercase px-2 py-0.5">
                {item.category}
              </span>
              <span
                className={`absolute top-2 right-2 text-[10px] font-bold uppercase px-2 py-0.5 ${
                  item.status === 'active'
                    ? 'bg-emerald-600 text-white'
                    : 'bg-neutral-600 text-white'
                }`}
              >
                {item.status || 'active'}
              </span>
            </div>

            <div className="p-4 flex-1 flex flex-col justify-between">
              <div>
                <h3 className="font-serif text-base font-semibold text-[#292522]">
                  {item.title}
                </h3>
                <p className="text-xs text-[#473C38]/70 mt-1 line-clamp-2">
                  {item.details}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-[#E3CAAB]/40 flex items-center justify-between">
                <button
                  onClick={() => handleToggleStatus(item)}
                  className="text-xs font-medium text-[#473C38] hover:text-[#B08A62] flex items-center gap-1 cursor-pointer"
                >
                  {item.status === 'active' ? (
                    <>
                      <Eye className="w-3.5 h-3.5 text-emerald-700" />
                      <span>Visible</span>
                    </>
                  ) : (
                    <>
                      <EyeOff className="w-3.5 h-3.5 text-neutral-400" />
                      <span>Hidden</span>
                    </>
                  )}
                </button>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => openEdit(item)}
                    className="p-1.5 text-[#473C38] hover:text-[#B08A62] transition-colors cursor-pointer"
                    title="Edit Item"
                  >
                    <Edit className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => {
                      if (window.confirm('Delete this gallery photo?')) {
                        deleteGalleryItem(item.id);
                      }
                    }}
                    className="p-1.5 text-[#473C38]/50 hover:text-red-600 transition-colors cursor-pointer"
                    title="Delete Item"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Add / Edit Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in overflow-y-auto">
          <div className="bg-white p-6 sm:p-8 max-w-lg w-full border border-[#E3CAAB] shadow-2xl space-y-4 my-8">
            <div className="flex items-center justify-between pb-3 border-b border-[#E3CAAB]/50">
              <h2 className="font-serif text-xl font-medium text-[#292522]">
                {editingItem ? 'Edit Gallery Photo' : 'Add Showcase Photo'}
              </h2>
              <button
                onClick={() => setModalOpen(false)}
                className="text-[#473C38] hover:text-[#B08A62] p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {error && (
              <div className="p-3 bg-red-50 border border-red-200 text-red-800 text-xs">
                {error}
              </div>
            )}

            <form onSubmit={handleSave} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                  Title / Room Name *
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Minimalist Villa Living in Bodakdev"
                  className="w-full px-3.5 py-2 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                    Category Tag
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full px-3 py-2 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38] cursor-pointer"
                  >
                    {categoriesOptions.map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                    Display Order
                  </label>
                  <input
                    type="number"
                    value={displayOrder}
                    onChange={(e) => setDisplayOrder(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                  Description / Furniture Included
                </label>
                <input
                  type="text"
                  value={details}
                  onChange={(e) => setDetails(e.target.value)}
                  placeholder="e.g. Custom curved sectional and fluted wood nesting tables"
                  className="w-full px-3.5 py-2 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
                />
              </div>

              {/* Image Uploader */}
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                  Photograph *
                </label>
                <div className="flex items-center gap-3">
                  {image && (
                    <img
                      src={image}
                      alt="Preview"
                      className="w-16 h-16 object-cover border border-[#E3CAAB]"
                    />
                  )}
                  <label className="flex-1 border border-dashed border-[#E3CAAB] hover:border-[#B08A62] p-3 text-center cursor-pointer bg-[#F7F3EE]/40">
                    <span className="text-xs font-medium text-[#473C38]">
                      {image ? 'Replace Photo' : 'Upload Showroom Photo'}
                    </span>
                    <input
                      type="file"
                      accept="image/jpeg,image/png,image/webp"
                      onChange={handleImageUpload}
                      className="hidden"
                    />
                  </label>
                </div>
                {uploadLoading && (
                  <p className="text-[10px] text-[#B08A62] mt-1">Uploading...</p>
                )}
              </div>

              <div className="pt-3 flex items-center justify-end gap-3 border-t border-[#E3CAAB]/50">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 border border-[#E3CAAB] text-xs font-semibold text-[#473C38] hover:bg-[#F7F3EE] cursor-pointer"
                >
                  CANCEL
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#473C38] text-white hover:bg-[#B08A62] text-xs font-semibold tracking-wider transition-colors cursor-pointer"
                >
                  SAVE PHOTO
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
