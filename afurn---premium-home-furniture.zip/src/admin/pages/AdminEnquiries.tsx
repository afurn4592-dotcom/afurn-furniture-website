import React, { useState } from 'react';
import {
  MessageSquare,
  Phone,
  MessageCircle,
  Eye,
  Trash2,
  Filter,
  CheckCircle,
  Clock,
  X,
  Mail
} from 'lucide-react';
import { useData } from '../../context/DataContext';
import { Enquiry, EnquiryStatus } from '../../types/furniture';

export default function AdminEnquiries() {
  const { enquiries, updateEnquiryStatus, deleteEnquiry } = useData();
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [selectedEnquiry, setSelectedEnquiry] = useState<Enquiry | null>(null);

  const filteredEnquiries = enquiries.filter((e) => {
    if (filterStatus === 'all') return true;
    return e.status === filterStatus;
  });

  const handleStatusChange = (id: string, status: EnquiryStatus) => {
    updateEnquiryStatus(id, status);
    if (selectedEnquiry && selectedEnquiry.id === id) {
      setSelectedEnquiry({ ...selectedEnquiry, status });
    }
  };

  const getCleanPhone = (phone: string) => phone.replace(/[^0-9]/g, '');

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      
      {/* Top Header */}
      <div className="bg-white p-6 border border-[#E3CAAB] shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] tracking-[0.2em] uppercase font-bold text-[#B08A62]">
            CUSTOMER RELATIONSHIPS
          </span>
          <h1 className="text-2xl font-serif font-medium text-[#292522] mt-0.5">
            Customer Inquiries & Leads ({enquiries.length})
          </h1>
          <p className="text-xs text-[#473C38]/70 mt-1">
            Submissions from website product quote buttons, contact forms, and inquiries.
          </p>
        </div>

        {/* Filter Pills */}
        <div className="flex flex-wrap items-center gap-2">
          {['all', 'NEW', 'CONTACTED', 'FOLLOW-UP', 'COMPLETED'].map((st) => (
            <button
              key={st}
              onClick={() => setFilterStatus(st)}
              className={`px-3 py-1.5 text-xs font-semibold uppercase tracking-wider transition-colors cursor-pointer ${
                filterStatus === st
                  ? 'bg-[#473C38] text-white shadow-xs'
                  : 'bg-[#F7F3EE] text-[#473C38] hover:bg-[#E3CAAB]/40 border border-[#E3CAAB]/60'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Inquiries Table */}
      <div className="bg-white border border-[#E3CAAB] shadow-xs overflow-hidden">
        {filteredEnquiries.length === 0 ? (
          <div className="py-16 text-center">
            <MessageSquare className="w-10 h-10 text-[#E3CAAB] mx-auto mb-2" />
            <p className="font-serif text-lg text-[#473C38]">No inquiries match this filter</p>
            <p className="text-xs text-[#473C38]/60 mt-1">
              New customer inquiries from the website will automatically appear here.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#F7F3EE] text-[#473C38] border-b border-[#E3CAAB] uppercase text-[10px] tracking-wider font-semibold">
                <tr>
                  <th className="p-3">Customer</th>
                  <th className="p-3">Inquiry Type</th>
                  <th className="p-3">Product / Topic</th>
                  <th className="p-3">Date</th>
                  <th className="p-3 text-center">Status</th>
                  <th className="p-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E3CAAB]/40">
                {filteredEnquiries.map((enq) => {
                  const cleanPhone = getCleanPhone(enq.phone);
                  return (
                    <tr key={enq.id} className="hover:bg-[#F7F3EE]/50 transition-colors">
                      {/* Customer Name & Contacts */}
                      <td className="p-3">
                        <p className="font-semibold text-sm text-[#292522]">
                          {enq.customerName}
                        </p>
                        <div className="text-[11px] text-[#473C38]/70 flex items-center gap-2 mt-0.5">
                          <span>{enq.phone}</span>
                          {enq.email && (
                            <>
                              <span aria-hidden="true">·</span>
                              <span className="truncate max-w-[150px]">{enq.email}</span>
                            </>
                          )}
                        </div>
                      </td>

                      {/* Type */}
                      <td className="p-3">
                        <span className="inline-block px-2 py-0.5 bg-[#F7F3EE] border border-[#E3CAAB] text-[10px] font-semibold text-[#473C38]">
                          {enq.type}
                        </span>
                      </td>

                      {/* Product / Message Snippet */}
                      <td className="p-3 max-w-xs">
                        {enq.productName && (
                          <p className="font-medium text-[#B08A62] truncate">
                            {enq.productName}
                          </p>
                        )}
                        <p className="text-[#473C38]/80 truncate italic">
                          "{enq.message}"
                        </p>
                      </td>

                      {/* Date */}
                      <td className="p-3 text-[#473C38]/70 whitespace-nowrap">
                        {new Date(enq.date).toLocaleDateString()}
                      </td>

                      {/* Status Dropdown */}
                      <td className="p-3 text-center">
                        <select
                          value={enq.status}
                          onChange={(e) => handleStatusChange(enq.id, e.target.value as EnquiryStatus)}
                          className={`px-2 py-1 text-[10px] font-bold uppercase tracking-wider border cursor-pointer ${
                            enq.status === 'NEW'
                              ? 'bg-amber-100 text-amber-900 border-amber-300'
                              : enq.status === 'CONTACTED'
                              ? 'bg-blue-100 text-blue-900 border-blue-300'
                              : enq.status === 'FOLLOW-UP'
                              ? 'bg-purple-100 text-purple-900 border-purple-300'
                              : 'bg-emerald-100 text-emerald-900 border-emerald-300'
                          }`}
                        >
                          <option value="NEW">NEW</option>
                          <option value="CONTACTED">CONTACTED</option>
                          <option value="FOLLOW-UP">FOLLOW-UP</option>
                          <option value="COMPLETED">COMPLETED</option>
                        </select>
                      </td>

                      {/* Actions: View Details, WhatsApp, Call */}
                      <td className="p-3 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => setSelectedEnquiry(enq)}
                            className="p-1.5 text-[#473C38] hover:text-[#B08A62] hover:bg-[#F7F3EE] transition-colors cursor-pointer"
                            title="View Full Details"
                          >
                            <Eye className="w-4 h-4" />
                          </button>

                          <a
                            href={`https://wa.me/91${cleanPhone}?text=${encodeURIComponent(
                              `Hello ${enq.customerName}, this is AFURN Furniture Ahmedabad regarding your inquiry. How may we assist you today?`
                            )}`}
                            target="_blank"
                            rel="noreferrer"
                            className="p-1.5 text-emerald-700 hover:text-emerald-800 hover:bg-emerald-50 transition-colors"
                            title="Chat on WhatsApp"
                          >
                            <MessageCircle className="w-4 h-4" />
                          </a>

                          <a
                            href={`tel:${enq.phone}`}
                            className="p-1.5 text-[#473C38] hover:text-[#B08A62] hover:bg-[#F7F3EE] transition-colors"
                            title="Call Customer"
                          >
                            <Phone className="w-4 h-4" />
                          </a>

                          <button
                            onClick={() => {
                              if (window.confirm('Delete this inquiry?')) {
                                deleteEnquiry(enq.id);
                              }
                            }}
                            className="p-1.5 text-[#473C38]/40 hover:text-red-600 hover:bg-red-50 transition-colors cursor-pointer"
                            title="Delete"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* View Details Modal */}
      {selectedEnquiry && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white p-6 sm:p-8 max-w-lg w-full border border-[#E3CAAB] shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#E3CAAB]/50">
              <div>
                <span className="text-[10px] tracking-wider uppercase text-[#B08A62] font-semibold">
                  {selectedEnquiry.type}
                </span>
                <h2 className="font-serif text-xl font-medium text-[#292522]">
                  {selectedEnquiry.customerName}
                </h2>
              </div>
              <button
                onClick={() => setSelectedEnquiry(null)}
                className="text-[#473C38] hover:text-[#B08A62] p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs text-[#473C38]">
              <div className="flex items-center justify-between bg-[#F7F3EE] p-3 border border-[#E3CAAB]/50">
                <div>
                  <p className="font-bold text-[#292522]">{selectedEnquiry.phone}</p>
                  {selectedEnquiry.email && <p className="text-[11px]">{selectedEnquiry.email}</p>}
                </div>
                <div className="flex items-center gap-2">
                  <a
                    href={`https://wa.me/91${getCleanPhone(selectedEnquiry.phone)}`}
                    target="_blank"
                    rel="noreferrer"
                    className="px-3 py-1.5 bg-emerald-700 text-white font-semibold flex items-center gap-1"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>WhatsApp</span>
                  </a>
                  <a
                    href={`tel:${selectedEnquiry.phone}`}
                    className="px-3 py-1.5 bg-[#473C38] text-white font-semibold flex items-center gap-1"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    <span>Call</span>
                  </a>
                </div>
              </div>

              {selectedEnquiry.productName && (
                <div>
                  <span className="font-semibold block uppercase text-[10px] text-[#473C38]/70">
                    Product Inquired:
                  </span>
                  <span className="text-sm font-serif font-semibold text-[#B08A62]">
                    {selectedEnquiry.productName}
                  </span>
                </div>
              )}

              <div>
                <span className="font-semibold block uppercase text-[10px] text-[#473C38]/70 mb-1">
                  Full Customer Message:
                </span>
                <div className="p-3 bg-[#F7F3EE]/80 border border-[#E3CAAB] text-xs leading-relaxed italic text-[#292522]">
                  "{selectedEnquiry.message}"
                </div>
              </div>

              <div>
                <span className="font-semibold block uppercase text-[10px] text-[#473C38]/70 mb-1">
                  Update Lead Status:
                </span>
                <select
                  value={selectedEnquiry.status}
                  onChange={(e) => handleStatusChange(selectedEnquiry.id, e.target.value as EnquiryStatus)}
                  className="w-full px-3 py-2 bg-white border border-[#E3CAAB] text-xs text-[#292522] cursor-pointer"
                >
                  <option value="NEW">NEW - Unread Lead</option>
                  <option value="CONTACTED">CONTACTED - Sent WhatsApp/Called</option>
                  <option value="FOLLOW-UP">FOLLOW-UP - Sent Quote/Samples</option>
                  <option value="COMPLETED">COMPLETED - Order Finalized</option>
                </select>
              </div>
            </div>

            <div className="pt-3 border-t border-[#E3CAAB]/50 flex justify-end">
              <button
                onClick={() => setSelectedEnquiry(null)}
                className="px-4 py-2 bg-[#473C38] text-white text-xs font-semibold"
              >
                CLOSE
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
