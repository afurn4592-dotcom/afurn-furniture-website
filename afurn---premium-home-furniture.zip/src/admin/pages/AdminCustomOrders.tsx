import React, { useState } from 'react';
import {
  Sparkles,
  Phone,
  MessageCircle,
  Eye,
  Trash2,
  X,
  Ruler,
  Hammer,
  Image as ImageIcon
} from 'lucide-react';
import { useData } from '../../context/DataContext';
import { CustomOrder } from '../../types/furniture';

export default function AdminCustomOrders() {
  const { customOrders, updateCustomOrderStatus, deleteCustomOrder } = useData();
  const [selectedOrder, setSelectedOrder] = useState<CustomOrder | null>(null);
  const [viewImageModal, setViewImageModal] = useState<string | null>(null);

  const getCleanPhone = (phone: string) => phone.replace(/[^0-9]/g, '');

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      
      {/* Top Header */}
      <div className="bg-white p-6 border border-[#E3CAAB] shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] tracking-[0.2em] uppercase font-bold text-[#B08A62]">
            BESPOKE WORKSHOP LEADS
          </span>
          <h1 className="text-2xl font-serif font-medium text-[#292522] mt-0.5">
            Custom Furniture Requests ({customOrders.length})
          </h1>
          <p className="text-xs text-[#473C38]/70 mt-1">
            Tailored inquiries submitted from the Custom Furniture Studio configurator by homeowners, architects, and designers.
          </p>
        </div>
      </div>

      {/* Orders Table */}
      <div className="bg-white border border-[#E3CAAB] shadow-xs overflow-hidden">
        {customOrders.length === 0 ? (
          <div className="py-16 text-center">
            <Sparkles className="w-10 h-10 text-[#E3CAAB] mx-auto mb-2" />
            <p className="font-serif text-lg text-[#473C38]">No custom furniture orders yet</p>
            <p className="text-xs text-[#473C38]/60 mt-1">
              Custom design submissions from the public configurator will be captured here.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#F7F3EE] text-[#473C38] border-b border-[#E3CAAB] uppercase text-[10px] tracking-wider font-semibold">
                <tr>
                  <th className="p-3">Customer</th>
                  <th className="p-3">Furniture Type</th>
                  <th className="p-3">Dimensions / Specs</th>
                  <th className="p-3">Material & Color</th>
                  <th className="p-3 text-center">Reference</th>
                  <th className="p-3 text-center">Status</th>
                  <th className="p-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E3CAAB]/40">
                {customOrders.map((order) => {
                  const cleanPhone = getCleanPhone(order.phone);
                  return (
                    <tr key={order.id} className="hover:bg-[#F7F3EE]/50 transition-colors">
                      {/* Customer */}
                      <td className="p-3">
                        <p className="font-semibold text-sm text-[#292522]">
                          {order.customerName}
                        </p>
                        <div className="text-[11px] text-[#473C38]/70 mt-0.5">
                          <span>{order.phone}</span>
                          {order.city && (
                            <span className="block text-[10px] text-[#B08A62]">
                              {order.city} • {order.projectType || 'Client'}
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Furniture Type */}
                      <td className="p-3">
                        <span className="font-serif font-medium text-xs text-[#292522]">
                          {order.furnitureType}
                        </span>
                        {order.budgetRange && (
                          <span className="block text-[10px] text-[#473C38]/60 mt-0.5">
                            Budget: {order.budgetRange}
                          </span>
                        )}
                      </td>

                      {/* Dimensions */}
                      <td className="p-3 max-w-xs text-[#473C38]">
                        <p className="truncate font-medium">{order.size || 'Custom dimensions'}</p>
                      </td>

                      {/* Material & Color */}
                      <td className="p-3 text-[#473C38]">
                        <p className="font-medium truncate max-w-[160px]">{order.material}</p>
                        <p className="text-[10px] text-[#473C38]/60 truncate">{order.color}</p>
                      </td>

                      {/* Reference Image */}
                      <td className="p-3 text-center">
                        {order.referenceImage ? (
                          <button
                            onClick={() => setViewImageModal(order.referenceImage!)}
                            className="p-1 border border-[#E3CAAB] hover:border-[#B08A62] inline-block cursor-pointer"
                            title="Click to view reference image"
                          >
                            <img
                              src={order.referenceImage}
                              alt="Ref"
                              className="w-10 h-10 object-cover"
                            />
                          </button>
                        ) : (
                          <span className="text-[10px] text-[#473C38]/40">None</span>
                        )}
                      </td>

                      {/* Status */}
                      <td className="p-3 text-center">
                        <select
                          value={order.status}
                          onChange={(e) => updateCustomOrderStatus(order.id, e.target.value as any)}
                          className={`px-2 py-1 text-[10px] font-bold uppercase tracking-wider border cursor-pointer ${
                            order.status === 'NEW'
                              ? 'bg-amber-100 text-amber-900 border-amber-300'
                              : order.status === 'CONTACTED'
                              ? 'bg-blue-100 text-blue-900 border-blue-300'
                              : order.status === 'IN_PRODUCTION'
                              ? 'bg-purple-100 text-purple-900 border-purple-300'
                              : 'bg-emerald-100 text-emerald-900 border-emerald-300'
                          }`}
                        >
                          <option value="NEW">NEW</option>
                          <option value="CONTACTED">CONTACTED</option>
                          <option value="IN_PRODUCTION">IN PRODUCTION</option>
                          <option value="COMPLETED">COMPLETED</option>
                        </select>
                      </td>

                      {/* Actions */}
                      <td className="p-3 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => setSelectedOrder(order)}
                            className="p-1.5 text-[#473C38] hover:text-[#B08A62] hover:bg-[#F7F3EE] transition-colors cursor-pointer"
                            title="View Full Specifications"
                          >
                            <Eye className="w-4 h-4" />
                          </button>

                          <a
                            href={`https://wa.me/91${cleanPhone}?text=${encodeURIComponent(
                              `Hello ${order.customerName}, this is AFURN Ahmedabad regarding your custom order for "${order.furnitureType}". We have reviewed your specifications.`
                            )}`}
                            target="_blank"
                            rel="noreferrer"
                            className="p-1.5 text-emerald-700 hover:text-emerald-800 hover:bg-emerald-50 transition-colors"
                            title="WhatsApp Customer"
                          >
                            <MessageCircle className="w-4 h-4" />
                          </a>

                          <a
                            href={`tel:${order.phone}`}
                            className="p-1.5 text-[#473C38] hover:text-[#B08A62] hover:bg-[#F7F3EE] transition-colors"
                            title="Call Customer"
                          >
                            <Phone className="w-4 h-4" />
                          </a>

                          <button
                            onClick={() => {
                              if (window.confirm('Delete this custom furniture request?')) {
                                deleteCustomOrder(order.id);
                              }
                            }}
                            className="p-1.5 text-[#473C38]/40 hover:text-red-600 hover:bg-red-50 transition-colors cursor-pointer"
                            title="Delete"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* View Full Custom Order Details Modal */}
      {selectedOrder && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in overflow-y-auto">
          <div className="bg-white p-6 sm:p-8 max-w-lg w-full border border-[#E3CAAB] shadow-2xl space-y-4 my-8">
            <div className="flex items-center justify-between pb-3 border-b border-[#E3CAAB]/50">
              <div>
                <span className="text-[10px] tracking-wider uppercase text-[#B08A62] font-semibold">
                  Custom Order Specs
                </span>
                <h2 className="font-serif text-xl font-medium text-[#292522]">
                  {selectedOrder.furnitureType}
                </h2>
              </div>
              <button
                onClick={() => setSelectedOrder(null)}
                className="text-[#473C38] hover:text-[#B08A62] p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs text-[#473C38]">
              <div className="p-3 bg-[#F7F3EE] border border-[#E3CAAB]">
                <p className="font-bold text-sm text-[#292522]">{selectedOrder.customerName}</p>
                <p className="mt-0.5">{selectedOrder.phone} • {selectedOrder.city || 'Ahmedabad'}</p>
                <p className="text-[11px] text-[#B08A62] font-semibold mt-0.5">Role: {selectedOrder.projectType || 'Homeowner'}</p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="p-2.5 bg-white border border-[#E3CAAB]/60">
                  <span className="text-[10px] uppercase font-semibold text-[#473C38]/60 block">Size / Dimensions:</span>
                  <span className="font-medium text-[#292522]">{selectedOrder.size || 'Standard'}</span>
                </div>
                <div className="p-2.5 bg-white border border-[#E3CAAB]/60">
                  <span className="text-[10px] uppercase font-semibold text-[#473C38]/60 block">Budget:</span>
                  <span className="font-medium text-[#292522]">{selectedOrder.budgetRange || 'Flexible'}</span>
                </div>
              </div>

              <div className="p-2.5 bg-white border border-[#E3CAAB]/60">
                <span className="text-[10px] uppercase font-semibold text-[#473C38]/60 block">Material Preference:</span>
                <span className="font-medium text-[#292522]">{selectedOrder.material}</span>
              </div>

              <div className="p-2.5 bg-white border border-[#E3CAAB]/60">
                <span className="text-[10px] uppercase font-semibold text-[#473C38]/60 block">Color / Upholstery:</span>
                <span className="font-medium text-[#292522]">{selectedOrder.color}</span>
              </div>

              {selectedOrder.message && (
                <div>
                  <span className="text-[10px] uppercase font-semibold text-[#473C38]/60 block mb-1">Customer Notes:</span>
                  <p className="p-3 bg-[#F7F3EE] italic border border-[#E3CAAB] leading-relaxed">
                    "{selectedOrder.message}"
                  </p>
                </div>
              )}

              {selectedOrder.referenceImage && (
                <div>
                  <span className="text-[10px] uppercase font-semibold text-[#473C38]/60 block mb-1">Attached Reference Image:</span>
                  <img
                    src={selectedOrder.referenceImage}
                    alt="Ref"
                    className="max-h-48 w-full object-cover border border-[#E3CAAB]"
                  />
                </div>
              )}
            </div>

            <div className="pt-3 border-t border-[#E3CAAB]/50 flex justify-between items-center">
              <a
                href={`https://wa.me/91${getCleanPhone(selectedOrder.phone)}`}
                target="_blank"
                rel="noreferrer"
                className="px-4 py-2 bg-emerald-700 text-white font-semibold text-xs flex items-center gap-1.5"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span>Discuss on WhatsApp</span>
              </a>

              <button
                onClick={() => setSelectedOrder(null)}
                className="px-4 py-2 bg-[#473C38] text-white text-xs font-semibold"
              >
                CLOSE
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Image Zoom Modal */}
      {viewImageModal && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4 animate-fade-in">
          <div className="relative max-w-3xl w-full bg-black p-2 border border-[#E3CAAB]">
            <button
              onClick={() => setViewImageModal(null)}
              className="absolute top-4 right-4 p-2 bg-black/60 text-white hover:text-[#B08A62]"
            >
              <X className="w-6 h-6" />
            </button>
            <img
              src={viewImageModal}
              alt="Reference"
              className="w-full h-auto max-h-[80vh] object-contain mx-auto"
            />
          </div>
        </div>
      )}

    </div>
  );
}
