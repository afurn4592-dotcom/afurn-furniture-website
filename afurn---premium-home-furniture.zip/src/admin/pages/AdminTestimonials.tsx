import React, { useState } from 'react';
import {
  Star,
  PlusCircle,
  Edit,
  Trash2,
  X,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { useData } from '../../context/DataContext';
import { Testimonial } from '../../types/furniture';

export default function AdminTestimonials() {
  const { testimonials, addTestimonial, updateTestimonial, deleteTestimonial } = useData();

  const [modalOpen, setModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<Testimonial | null>(null);

  const [name, setName] = useState('');
  const [role, setRole] = useState('Homeowner');
  const [location, setLocation] = useState('Satellite, Ahmedabad');
  const [quote, setQuote] = useState('');
  const [rating, setRating] = useState<number>(5);
  const [project, setProject] = useState('');
  const [status, setStatus] = useState<'active' | 'inactive'>('active');

  const [error, setError] = useState<string | null>(null);

  const openAdd = () => {
    setEditingItem(null);
    setName('');
    setRole('Homeowner');
    setLocation('Bodakdev, Ahmedabad');
    setQuote('');
    setRating(5);
    setProject('Living & Dining Furniture Set');
    setStatus('active');
    setError(null);
    setModalOpen(true);
  };

  const openEdit = (item: Testimonial) => {
    setEditingItem(item);
    setName(item.name);
    setRole(item.role);
    setLocation(item.location);
    setQuote(item.quote);
    setRating(item.rating);
    setProject(item.project);
    setStatus(item.status || 'active');
    setError(null);
    setModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !quote.trim()) {
      setError('Client Name and Review Quote are required.');
      return;
    }

    const payload = {
      name: name.trim(),
      role: role.trim(),
      location: location.trim(),
      quote: quote.trim(),
      rating: Number(rating) || 5,
      project: project.trim(),
      status,
      displayOrder: editingItem ? editingItem.displayOrder : testimonials.length + 1,
    };

    if (editingItem) {
      updateTestimonial(editingItem.id, payload);
    } else {
      addTestimonial(payload);
    }

    setModalOpen(false);
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      
      {/* Top Header */}
      <div className="bg-white p-6 border border-[#E3CAAB] shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] tracking-[0.2em] uppercase font-bold text-[#B08A62]">
            SOCIAL PROOF
          </span>
          <h1 className="text-2xl font-serif font-medium text-[#292522] mt-0.5">
            Customer Reviews & Testimonials ({testimonials.length})
          </h1>
          <p className="text-xs text-[#473C38]/70 mt-1">
            Manage architect testimonials and client feedback shown on the public site.
          </p>
        </div>

        <button
          onClick={openAdd}
          className="px-5 py-3 bg-[#473C38] text-white hover:bg-[#B08A62] text-xs font-semibold tracking-wider flex items-center justify-center gap-2 transition-colors shadow-xs cursor-pointer shrink-0"
        >
          <PlusCircle className="w-4 h-4" />
          <span>ADD TESTIMONIAL</span>
        </button>
      </div>

      {/* Testimonials Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {testimonials.map((item) => (
          <div
            key={item.id}
            className="bg-white border border-[#E3CAAB] shadow-xs p-6 flex flex-col justify-between"
          >
            <div>
              {/* Stars & Status */}
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center text-[#B08A62]">
                  {[...Array(item.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-current" />
                  ))}
                </div>
                <span
                  className={`px-2 py-0.5 text-[9px] font-bold uppercase ${
                    item.status === 'active' ? 'bg-emerald-100 text-emerald-800' : 'bg-neutral-200 text-neutral-600'
                  }`}
                >
                  {item.status || 'active'}
                </span>
              </div>

              {/* Quote */}
              <p className="text-xs text-[#473C38]/85 italic leading-relaxed">
                "{item.quote}"
              </p>
            </div>

            <div className="mt-6 pt-4 border-t border-[#E3CAAB]/50 flex items-end justify-between">
              <div>
                <p className="text-sm font-semibold text-[#292522]">{item.name}</p>
                <p className="text-[11px] text-[#B08A62] font-medium">{item.role}</p>
                <p className="text-[10px] text-[#473C38]/60 mt-0.5">{item.location} • {item.project}</p>
              </div>

              <div className="flex items-center gap-1">
                <button
                  onClick={() => openEdit(item)}
                  className="p-1.5 text-[#473C38] hover:text-[#B08A62] transition-colors cursor-pointer"
                  title="Edit"
                >
                  <Edit className="w-4 h-4" />
                </button>
                <button
                  onClick={() => {
                    if (window.confirm('Delete this testimonial?')) {
                      deleteTestimonial(item.id);
                    }
                  }}
                  className="p-1.5 text-[#473C38]/50 hover:text-red-600 transition-colors cursor-pointer"
                  title="Delete"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Add / Edit Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in overflow-y-auto">
          <div className="bg-white p-6 sm:p-8 max-w-lg w-full border border-[#E3CAAB] shadow-2xl space-y-4 my-8">
            <div className="flex items-center justify-between pb-3 border-b border-[#E3CAAB]/50">
              <h2 className="font-serif text-xl font-medium text-[#292522]">
                {editingItem ? 'Edit Testimonial' : 'Add Testimonial'}
              </h2>
              <button
                onClick={() => setModalOpen(false)}
                className="text-[#473C38] hover:text-[#B08A62] p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {error && (
              <div className="p-3 bg-red-50 border border-red-200 text-red-800 text-xs">
                {error}
              </div>
            )}

            <form onSubmit={handleSave} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                  Customer / Architect Name *
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Ar. Hiren Patel"
                  className="w-full px-3.5 py-2 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                    Role / Company
                  </label>
                  <input
                    type="text"
                    value={role}
                    onChange={(e) => setRole(e.target.value)}
                    placeholder="e.g. Lead Architect, Studio Ahmedabad"
                    className="w-full px-3.5 py-2 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                    Location in Ahmedabad
                  </label>
                  <input
                    type="text"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    placeholder="e.g. Bodakdev, Ahmedabad"
                    className="w-full px-3.5 py-2 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                    Project Tag
                  </label>
                  <input
                    type="text"
                    value={project}
                    onChange={(e) => setProject(e.target.value)}
                    placeholder="e.g. Custom Dining & Living"
                    className="w-full px-3.5 py-2 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                    Rating (1-5 stars)
                  </label>
                  <select
                    value={rating}
                    onChange={(e) => setRating(Number(e.target.value))}
                    className="w-full px-3.5 py-2 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] cursor-pointer"
                  >
                    <option value={5}>5 Stars (★★★★★)</option>
                    <option value={4}>4 Stars (★★★★☆)</option>
                    <option value={3}>3 Stars (★★★☆☆)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                  Testimonial Quote *
                </label>
                <textarea
                  rows={4}
                  required
                  value={quote}
                  onChange={(e) => setQuote(e.target.value)}
                  placeholder="Share the client's words on timber quality, custom fabrication, and delivery..."
                  className="w-full px-3.5 py-2 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
                />
              </div>

              <div className="pt-3 flex items-center justify-end gap-3 border-t border-[#E3CAAB]/50">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 border border-[#E3CAAB] text-xs font-semibold text-[#473C38] hover:bg-[#F7F3EE] cursor-pointer"
                >
                  CANCEL
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#473C38] text-white hover:bg-[#B08A62] text-xs font-semibold tracking-wider transition-colors cursor-pointer"
                >
                  SAVE TESTIMONIAL
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
