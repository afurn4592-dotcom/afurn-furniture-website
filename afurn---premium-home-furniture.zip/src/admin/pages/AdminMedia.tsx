import React, { useState } from 'react';
import {
  Image as ImageIcon,
  Plus,
  Trash2,
  Copy,
  Check,
  Search,
  ExternalLink,
  Filter,
  CheckCircle2,
  HardDrive
} from 'lucide-react';
import { IMAGES } from '../../data/furnitureData';

interface MediaAsset {
  id: string;
  name: string;
  url: string;
  category: 'Products' | 'Banners' | 'Workshop' | 'Categories';
  dimensions: string;
  size: string;
  uploadedDate: string;
}

const INITIAL_MEDIA_ASSETS: MediaAsset[] = [
  {
    id: 'med-1',
    name: 'Hero Luxury Living Room Showcase',
    url: IMAGES.hero,
    category: 'Banners',
    dimensions: '1920 × 1080',
    size: '420 KB',
    uploadedDate: '2026-02-10',
  },
  {
    id: 'med-2',
    name: 'Modular Italian Curved Sofa Collection',
    url: IMAGES.sofa,
    category: 'Products',
    dimensions: '1200 × 900',
    size: '310 KB',
    uploadedDate: '2026-02-12',
  },
  {
    id: 'med-3',
    name: 'Handcrafted Teak Dining Table & Chairs',
    url: IMAGES.dining,
    category: 'Products',
    dimensions: '1200 × 900',
    size: '345 KB',
    uploadedDate: '2026-02-14',
  },
  {
    id: 'med-4',
    name: 'Cognac Leather Sculpted Lounge Chair',
    url: IMAGES.lounge,
    category: 'Products',
    dimensions: '1200 × 900',
    size: '280 KB',
    uploadedDate: '2026-02-15',
  },
  {
    id: 'med-5',
    name: 'Fluted Drum Centre Table Set',
    url: IMAGES.centreTable,
    category: 'Products',
    dimensions: '1200 × 900',
    size: '295 KB',
    uploadedDate: '2026-02-16',
  },
  {
    id: 'med-6',
    name: 'Executive Solid Oak Study Desk',
    url: IMAGES.studyTable,
    category: 'Products',
    dimensions: '1200 × 900',
    size: '315 KB',
    uploadedDate: '2026-02-18',
  },
  {
    id: 'med-7',
    name: 'Heritage Danilimda Teak Swing (Jhula)',
    url: IMAGES.woodenSwing,
    category: 'Products',
    dimensions: '1200 × 900',
    size: '380 KB',
    uploadedDate: '2026-02-20',
  },
  {
    id: 'med-8',
    name: 'Cane Webbing Dining Accent Chairs',
    url: IMAGES.accentChairs,
    category: 'Products',
    dimensions: '1200 × 900',
    size: '290 KB',
    uploadedDate: '2026-02-22',
  },
];

export default function AdminMedia() {
  const [mediaList, setMediaList] = useState<MediaAsset[]>(() => {
    try {
      const stored = localStorage.getItem('afurn_media_library');
      return stored ? JSON.parse(stored) : INITIAL_MEDIA_ASSETS;
    } catch {
      return INITIAL_MEDIA_ASSETS;
    }
  });

  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [newAsset, setNewAsset] = useState<{ name: string; url: string; category: MediaAsset['category'] }>({
    name: '',
    url: '',
    category: 'Products',
  });
  const [savedSuccess, setSavedSuccess] = useState(false);

  // Sync to localStorage
  const saveAssets = (assets: MediaAsset[]) => {
    setMediaList(assets);
    try {
      localStorage.setItem('afurn_media_library', JSON.stringify(assets));
    } catch (e) {
      console.error(e);
    }
  };

  const handleCopyUrl = (id: string, url: string) => {
    navigator.clipboard.writeText(url);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Are you sure you want to remove this media asset?')) {
      const updated = mediaList.filter((m) => m.id !== id);
      saveAssets(updated);
    }
  };

  const handleAddAsset = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAsset.name.trim() || !newAsset.url.trim()) return;

    const asset: MediaAsset = {
      id: `med-${Date.now()}`,
      name: newAsset.name.trim(),
      url: newAsset.url.trim(),
      category: newAsset.category,
      dimensions: '1200 × 900',
      size: '300 KB',
      uploadedDate: new Date().toISOString().split('T')[0],
    };

    const next = [asset, ...mediaList];
    saveAssets(next);
    setNewAsset({ name: '', url: '', category: 'Products' });
    setIsUploadOpen(false);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const filteredAssets = mediaList.filter((item) => {
    const matchesSearch = item.name.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || item.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Top Header */}
      <div className="bg-white p-6 border border-[#E3CAAB] shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] tracking-[0.2em] uppercase font-bold text-[#B08A62]">
            ASSET REPOSITORY
          </span>
          <h1 className="text-2xl font-serif font-medium text-[#292522] mt-0.5">
            Media Library & Image Manager
          </h1>
          <p className="text-xs text-[#473C38]/70 mt-1">
            Central repository for product photography, showroom installations, and hero banners.
          </p>
        </div>

        <button
          type="button"
          onClick={() => setIsUploadOpen(true)}
          className="px-5 py-2.5 bg-[#473C38] text-white hover:bg-[#B08A62] text-xs font-semibold tracking-wider flex items-center gap-2 transition-colors shadow-xs cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>ADD MEDIA ASSET</span>
        </button>
      </div>

      {savedSuccess && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2.5 animate-fade-in shadow-xs">
          <CheckCircle2 className="w-5 h-5 shrink-0 text-emerald-600" />
          <span>
            <strong>Success:</strong> Media asset added to the repository. You can now use its URL in products, banners, or homepage sections.
          </span>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 border border-[#E3CAAB] shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#473C38]/50" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search images by name or keyword..."
            className="w-full pl-9 pr-4 py-2 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
          />
        </div>

        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-[#B08A62]" />
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="px-3 py-2 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs font-medium text-[#292522]"
          >
            <option value="all">All Categories ({mediaList.length})</option>
            <option value="Products">Products</option>
            <option value="Banners">Banners</option>
            <option value="Workshop">Workshop</option>
            <option value="Categories">Categories</option>
          </select>
        </div>
      </div>

      {/* Media Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
        {filteredAssets.map((asset) => (
          <div
            key={asset.id}
            className="bg-white border border-[#E3CAAB] hover:border-[#B08A62] shadow-xs transition-all duration-200 group flex flex-col justify-between overflow-hidden"
          >
            <div className="relative aspect-[4/3] bg-[#F7F3EE] overflow-hidden">
              <img
                src={asset.url}
                alt={asset.name}
                className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
              />
              <span className="absolute top-2 left-2 text-[9px] font-bold uppercase tracking-wider bg-[#473C38]/90 text-white px-2 py-0.5">
                {asset.category}
              </span>
            </div>

            <div className="p-3.5 space-y-2 flex-1 flex flex-col justify-between">
              <div>
                <h4 className="text-xs font-semibold text-[#292522] line-clamp-1 group-hover:text-[#B08A62]">
                  {asset.name}
                </h4>
                <div className="flex items-center justify-between text-[10px] text-[#473C38]/60 mt-1">
                  <span>{asset.dimensions}</span>
                  <span>{asset.size}</span>
                </div>
              </div>

              <div className="pt-2 border-t border-[#E3CAAB]/40 flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={() => handleCopyUrl(asset.id, asset.url)}
                  className={`flex-1 py-1.5 px-2 text-[10px] font-semibold tracking-wider uppercase border flex items-center justify-center gap-1 transition-colors cursor-pointer ${
                    copiedId === asset.id
                      ? 'border-emerald-500 bg-emerald-50 text-emerald-700'
                      : 'border-[#473C38] text-[#473C38] hover:bg-[#473C38] hover:text-white'
                  }`}
                  title="Copy direct image URL"
                >
                  {copiedId === asset.id ? (
                    <>
                      <Check className="w-3 h-3" />
                      <span>COPIED!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3 h-3" />
                      <span>COPY URL</span>
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => handleDelete(asset.id)}
                  className="p-1.5 text-red-500 hover:text-red-700 hover:bg-red-50 transition-colors cursor-pointer"
                  title="Delete asset"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredAssets.length === 0 && (
        <div className="bg-white p-12 text-center border border-[#E3CAAB] shadow-xs">
          <ImageIcon className="w-10 h-10 text-[#473C38]/30 mx-auto mb-2" />
          <p className="text-xs font-semibold text-[#292522]">No media assets found</p>
          <p className="text-[11px] text-[#473C38]/60 mt-1">Try clearing your search or add a new media asset.</p>
        </div>
      )}

      {/* Add Media Modal */}
      {isUploadOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white max-w-md w-full border border-[#E3CAAB] p-6 shadow-2xl space-y-5 animate-scale-in">
            <h3 className="font-serif text-lg font-medium text-[#292522]">
              Add New Media Asset
            </h3>

            <form onSubmit={handleAddAsset} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                  Asset Title / Description
                </label>
                <input
                  type="text"
                  required
                  value={newAsset.name}
                  onChange={(e) => setNewAsset({ ...newAsset, name: e.target.value })}
                  placeholder="e.g., Solid Teak 6-Seater Dining Suite"
                  className="w-full px-3 py-2 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-[#292522] focus:outline-none focus:border-[#473C38]"
                />
              </div>

              <div>
                <label className="block font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                  Image URL
                </label>
                <input
                  type="url"
                  required
                  value={newAsset.url}
                  onChange={(e) => setNewAsset({ ...newAsset, url: e.target.value })}
                  placeholder="https://images.unsplash.com/... or hosted URL"
                  className="w-full px-3 py-2 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-[#292522] focus:outline-none focus:border-[#473C38]"
                />
              </div>

              <div>
                <label className="block font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                  Category
                </label>
                <select
                  value={newAsset.category}
                  onChange={(e) => setNewAsset({ ...newAsset, category: e.target.value as any })}
                  className="w-full px-3 py-2 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-[#292522]"
                >
                  <option value="Products">Products</option>
                  <option value="Banners">Banners</option>
                  <option value="Workshop">Workshop</option>
                  <option value="Categories">Categories</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#E3CAAB]/50">
                <button
                  type="button"
                  onClick={() => setIsUploadOpen(false)}
                  className="px-4 py-2 border border-[#473C38] text-[#473C38] hover:bg-[#F7F3EE] font-semibold cursor-pointer"
                >
                  CANCEL
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#473C38] text-white hover:bg-[#B08A62] font-semibold cursor-pointer"
                >
                  SAVE ASSET
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
