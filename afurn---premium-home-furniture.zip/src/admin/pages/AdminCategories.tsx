import React, { useState } from 'react';
import {
  FolderTree,
  PlusCircle,
  Edit,
  Trash2,
  AlertTriangle,
  Upload,
  CheckCircle2,
  X,
  ArrowUpDown,
  Eye,
  EyeOff
} from 'lucide-react';
import { useData } from '../../context/DataContext';
import { Category } from '../../types/furniture';
import { optimizeImageFile } from '../../utils/imageUpload';
import { IMAGES } from '../../data/furnitureData';

export default function AdminCategories() {
  const {
    categories,
    addCategory,
    updateCategory,
    deleteCategory,
    getProductsInCategoryCount,
  } = useData();

  const [modalOpen, setModalOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);

  // Form states
  const [name, setName] = useState('');
  const [slug, setSlug] = useState('');
  const [description, setDescription] = useState('');
  const [image, setImage] = useState('');
  const [displayOrder, setDisplayOrder] = useState<number>(1);
  const [status, setStatus] = useState<'active' | 'inactive'>('active');

  const [error, setError] = useState<string | null>(null);
  const [uploadLoading, setUploadLoading] = useState(false);

  // Safe delete modal state
  const [deleteModalState, setDeleteModalState] = useState<{
    category: Category | null;
    warningMessage?: string;
    cannotDelete?: boolean;
  }>({ category: null });

  const openAddModal = () => {
    setEditingCategory(null);
    setName('');
    setSlug('');
    setDescription('');
    setImage(IMAGES.hero);
    setDisplayOrder(categories.length + 1);
    setStatus('active');
    setError(null);
    setModalOpen(true);
  };

  const openEditModal = (cat: Category) => {
    setEditingCategory(cat);
    setName(cat.name);
    setSlug(cat.slug);
    setDescription(cat.description || '');
    setImage(cat.image);
    setDisplayOrder(cat.displayOrder ?? 1);
    setStatus(cat.status || 'active');
    setError(null);
    setModalOpen(true);
  };

  const handleNameChange = (val: string) => {
    setName(val);
    if (!editingCategory) {
      setSlug(val.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''));
    }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setUploadLoading(true);
      setError(null);
      const optimizedUrl = await optimizeImageFile(file);
      setImage(optimizedUrl);
    } catch (err: any) {
      setError(err.message || 'Failed to upload image.');
    } finally {
      setUploadLoading(false);
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Category Name is required.');
      return;
    }

    const payload = {
      name: name.trim(),
      slug: slug.trim() || name.trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''),
      description: description.trim(),
      image: image || IMAGES.hero,
      displayOrder: Number(displayOrder) || 1,
      status,
    };

    if (editingCategory) {
      updateCategory(editingCategory.id, payload);
    } else {
      addCategory(payload);
    }

    setModalOpen(false);
  };

  const handleDeleteClick = (cat: Category) => {
    const productCount = getProductsInCategoryCount(cat.id);
    if (productCount > 0) {
      setDeleteModalState({
        category: cat,
        warningMessage: `This category contains ${productCount} product${
          productCount === 1 ? '' : 's'
        }. Please move these products to another category before deleting.`,
        cannotDelete: true,
      });
    } else {
      setDeleteModalState({
        category: cat,
        cannotDelete: false,
      });
    }
  };

  const confirmDelete = () => {
    if (deleteModalState.category && !deleteModalState.cannotDelete) {
      deleteCategory(deleteModalState.category.id);
      setDeleteModalState({ category: null });
    }
  };

  const sortedCategories = [...categories].sort((a, b) => (a.displayOrder || 0) - (b.displayOrder || 0));

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      
      {/* Header Bar */}
      <div className="bg-white p-6 border border-[#E3CAAB] shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] tracking-[0.2em] uppercase font-bold text-[#B08A62]">
            COLLECTIONS & NAVIGATION
          </span>
          <h1 className="text-2xl font-serif font-medium text-[#292522] mt-0.5">
            Category Management ({categories.length})
          </h1>
          <p className="text-xs text-[#473C38]/70 mt-1">
            Categories automatically appear in the main navigation, shop filters, and homepage collections.
          </p>
        </div>

        <button
          onClick={openAddModal}
          className="px-5 py-3 bg-[#473C38] text-white hover:bg-[#B08A62] text-xs font-semibold tracking-wider flex items-center justify-center gap-2 transition-colors shadow-xs cursor-pointer shrink-0"
        >
          <PlusCircle className="w-4 h-4" />
          <span>ADD NEW CATEGORY</span>
        </button>
      </div>

      {/* Categories Grid / Table */}
      <div className="bg-white border border-[#E3CAAB] shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#F7F3EE] text-[#473C38] border-b border-[#E3CAAB] uppercase text-[10px] tracking-wider font-semibold">
              <tr>
                <th className="p-3 w-14 text-center">Order</th>
                <th className="p-3">Category</th>
                <th className="p-3">Slug</th>
                <th className="p-3">Description</th>
                <th className="p-3 text-center">Products</th>
                <th className="p-3 text-center">Status</th>
                <th className="p-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#E3CAAB]/40">
              {sortedCategories.map((cat) => {
                const count = getProductsInCategoryCount(cat.id);
                return (
                  <tr key={cat.id} className="hover:bg-[#F7F3EE]/50 transition-colors">
                    {/* Order */}
                    <td className="p-3 text-center font-bold text-[#473C38]/70 tabular-nums">
                      {cat.displayOrder ?? '—'}
                    </td>

                    {/* Thumbnail & Name */}
                    <td className="p-3">
                      <div className="flex items-center gap-3">
                        <img
                          src={cat.image}
                          alt={cat.name}
                          className="w-12 h-12 object-cover bg-[#F7F3EE] border border-[#E3CAAB]/70 shrink-0"
                        />
                        <div>
                          <p className="font-semibold text-sm text-[#292522]">
                            {cat.name}
                          </p>
                          <span className="text-[10px] text-[#B08A62] uppercase tracking-wider font-medium">
                            ID: {cat.id}
                          </span>
                        </div>
                      </div>
                    </td>

                    {/* Slug */}
                    <td className="p-3 font-mono text-[11px] text-[#473C38]/80">
                      /{cat.slug}
                    </td>

                    {/* Description */}
                    <td className="p-3 max-w-xs text-[#473C38]/70 truncate">
                      {cat.description || '—'}
                    </td>

                    {/* Products Count */}
                    <td className="p-3 text-center">
                      <span className="inline-block px-2.5 py-0.5 bg-[#F7F3EE] border border-[#E3CAAB] text-xs font-bold text-[#473C38] tabular-nums">
                        {count} item{count === 1 ? '' : 's'}
                      </span>
                    </td>

                    {/* Status */}
                    <td className="p-3 text-center">
                      <span
                        className={`inline-block px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider ${
                          cat.status === 'active'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-neutral-200 text-neutral-600'
                        }`}
                      >
                        {cat.status || 'active'}
                      </span>
                    </td>

                    {/* Actions */}
                    <td className="p-3 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => openEditModal(cat)}
                          className="p-1.5 text-[#473C38] hover:text-[#B08A62] hover:bg-[#F7F3EE] transition-colors cursor-pointer"
                          title="Edit Category"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteClick(cat)}
                          className="p-1.5 text-[#473C38]/60 hover:text-red-600 hover:bg-red-50 transition-colors cursor-pointer"
                          title="Delete Category"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Category Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in overflow-y-auto">
          <div className="bg-white p-6 sm:p-8 max-w-lg w-full border border-[#E3CAAB] shadow-2xl space-y-4 my-8">
            <div className="flex items-center justify-between pb-3 border-b border-[#E3CAAB]/50">
              <h2 className="font-serif text-xl font-medium text-[#292522]">
                {editingCategory ? 'Edit Category' : 'Add New Category'}
              </h2>
              <button
                onClick={() => setModalOpen(false)}
                className="text-[#473C38] hover:text-[#B08A62] p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {error && (
              <div className="p-3 bg-red-50 border border-red-200 text-red-800 text-xs">
                {error}
              </div>
            )}

            <form onSubmit={handleSave} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                  Category Name *
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => handleNameChange(e.target.value)}
                  placeholder="e.g. PUFFY FURNITURE or LUXURY SWINGS"
                  className="w-full px-3.5 py-2 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                    Slug / URL identifier
                  </label>
                  <input
                    type="text"
                    required
                    value={slug}
                    onChange={(e) => setSlug(e.target.value)}
                    placeholder="e.g. puffy-furniture"
                    className="w-full px-3 py-2 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                    Display Order
                  </label>
                  <input
                    type="number"
                    value={displayOrder}
                    onChange={(e) => setDisplayOrder(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                  Description / Subtitle
                </label>
                <input
                  type="text"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="e.g. Modern cloud comfort and plush cushioned furniture"
                  className="w-full px-3.5 py-2 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
                />
              </div>

              {/* Category Image */}
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                  Category Banner Image
                </label>
                <div className="flex items-center gap-3">
                  {image && (
                    <img
                      src={image}
                      alt="Category preview"
                      className="w-16 h-16 object-cover border border-[#E3CAAB]"
                    />
                  )}
                  <label className="flex-1 border border-dashed border-[#E3CAAB] hover:border-[#B08A62] p-3 text-center cursor-pointer bg-[#F7F3EE]/40">
                    <span className="text-xs font-medium text-[#473C38]">
                      {image ? 'Replace Category Image' : 'Upload Category Image'}
                    </span>
                    <input
                      type="file"
                      accept="image/jpeg,image/png,image/webp"
                      onChange={handleImageUpload}
                      className="hidden"
                    />
                  </label>
                </div>
                {uploadLoading && (
                  <p className="text-[10px] text-[#B08A62] mt-1">Uploading...</p>
                )}
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                  Visibility Status
                </label>
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value as any)}
                  className="w-full px-3 py-2 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38] cursor-pointer"
                >
                  <option value="active">Active (Visible in nav & shop)</option>
                  <option value="inactive">Inactive (Hidden)</option>
                </select>
              </div>

              <div className="pt-3 flex items-center justify-end gap-3 border-t border-[#E3CAAB]/50">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 border border-[#E3CAAB] text-xs font-semibold text-[#473C38] hover:bg-[#F7F3EE] cursor-pointer"
                >
                  CANCEL
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#473C38] text-white hover:bg-[#B08A62] text-xs font-semibold tracking-wider transition-colors cursor-pointer"
                >
                  SAVE CATEGORY
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Safe Delete Category Modal */}
      {deleteModalState.category && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white p-6 max-w-md w-full border border-[#E3CAAB] shadow-2xl space-y-4">
            <div className="flex items-center gap-3 text-rose-600">
              <AlertTriangle className="w-6 h-6 shrink-0" />
              <h3 className="font-serif text-lg font-bold text-[#292522]">
                {deleteModalState.cannotDelete ? 'Cannot Delete Category' : 'Confirm Delete Category'}
              </h3>
            </div>

            {deleteModalState.cannotDelete ? (
              <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 text-xs leading-relaxed">
                {deleteModalState.warningMessage}
              </div>
            ) : (
              <p className="text-xs text-[#473C38]/85 leading-relaxed">
                Are you sure you want to delete the category{' '}
                <strong>"{deleteModalState.category.name}"</strong>? This will remove it from the navigation and shop filters.
              </p>
            )}

            <div className="pt-2 flex items-center justify-end gap-3">
              <button
                onClick={() => setDeleteModalState({ category: null })}
                className="px-4 py-2 border border-[#E3CAAB] text-xs font-semibold text-[#473C38] hover:bg-[#F7F3EE] cursor-pointer"
              >
                {deleteModalState.cannotDelete ? 'CLOSE' : 'CANCEL'}
              </button>
              {!deleteModalState.cannotDelete && (
                <button
                  onClick={confirmDelete}
                  className="px-4 py-2 bg-rose-700 text-white text-xs font-semibold hover:bg-rose-800 cursor-pointer shadow-sm"
                >
                  DELETE CATEGORY
                </button>
              )}
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
