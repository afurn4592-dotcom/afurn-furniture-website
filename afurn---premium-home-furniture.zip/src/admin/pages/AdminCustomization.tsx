import React, { useState } from 'react';
import {
  Palette,
  Type,
  Layers,
  Sparkles,
  Save,
  RotateCcw,
  CheckCircle2,
  Eye,
  Sliders,
  Image as ImageIcon
} from 'lucide-react';
import { useData } from '../../context/DataContext';
import { WebsiteCustomization } from '../../types/furniture';
import sofaImg from '../../assets/images/cat_sofa_collection_1791199454056.jpg';

const PRESET_PALETTES = [
  {
    name: 'AFURN Classic (Showroom Teak & Sandstone)',
    customization: {
      primaryColor: '#473C38',
      secondaryColor: '#E3CAAB',
      accentColor: '#B08A62',
      backgroundColor: '#F7F3EE',
      textColor: '#292522',
      buttonColor: '#473C38',
      buttonTextColor: '#FFFFFF',
    }
  },
  {
    name: 'Heritage Teak & Warm Amber',
    customization: {
      primaryColor: '#382A24',
      secondaryColor: '#DEC5A5',
      accentColor: '#C2935D',
      backgroundColor: '#FAF7F2',
      textColor: '#241D1A',
      buttonColor: '#382A24',
      buttonTextColor: '#FFFFFF',
    }
  },
  {
    name: 'Modern Architectural Slate & Linen',
    customization: {
      primaryColor: '#26292B',
      secondaryColor: '#DFDDD7',
      accentColor: '#8C7862',
      backgroundColor: '#F4F4F3',
      textColor: '#1E2022',
      buttonColor: '#26292B',
      buttonTextColor: '#FFFFFF',
    }
  },
  {
    name: 'Royal Indian Sheesham & Ochre',
    customization: {
      primaryColor: '#3D2B1F',
      secondaryColor: '#E8D3B9',
      accentColor: '#C68B45',
      backgroundColor: '#FDFBF7',
      textColor: '#2E1F16',
      buttonColor: '#3D2B1F',
      buttonTextColor: '#FFFFFF',
    }
  }
];

const HEADING_FONTS = [
  { label: 'Cormorant Garamond (Editorial Luxury Serif)', value: 'Cormorant Garamond' },
  { label: 'Playfair Display (Classic Elegant Serif)', value: 'Playfair Display' },
  { label: 'Cinzel (High-End Architectural Display)', value: 'Cinzel' },
  { label: 'Plus Jakarta Sans (Contemporary Clean)', value: 'Plus Jakarta Sans' },
  { label: 'Montserrat (Bold Modern Geometric)', value: 'Montserrat' },
  { label: 'Georgia (Traditional Timeless Serif)', value: 'Georgia' },
];

const BODY_FONTS = [
  { label: 'Plus Jakarta Sans (Modern Clean Sans)', value: 'Plus Jakarta Sans' },
  { label: 'Inter (Neutral Digital Sans)', value: 'Inter' },
  { label: 'Roboto (Balanced Readable Sans)', value: 'Roboto' },
  { label: 'Lato (Warm Humanist Sans)', value: 'Lato' },
];

export default function AdminCustomization() {
  const { settings, updateCustomization } = useData();

  const [formData, setFormData] = useState<WebsiteCustomization>({
    logoType: settings.customization?.logoType || 'text',
    logoText: settings.customization?.logoText || settings.businessName || 'AFURN',
    logoImage: settings.customization?.logoImage || '',
    favicon: settings.customization?.favicon || '',
    primaryColor: settings.customization?.primaryColor || '#473C38',
    secondaryColor: settings.customization?.secondaryColor || '#E3CAAB',
    accentColor: settings.customization?.accentColor || '#B08A62',
    backgroundColor: settings.customization?.backgroundColor || '#F7F3EE',
    textColor: settings.customization?.textColor || '#292522',
    buttonColor: settings.customization?.buttonColor || '#473C38',
    buttonTextColor: settings.customization?.buttonTextColor || '#FFFFFF',
    headingFont: settings.customization?.headingFont || 'Cormorant Garamond',
    bodyFont: settings.customization?.bodyFont || 'Plus Jakarta Sans',
    headingSize: settings.customization?.headingSize || 'lg',
    bodySize: settings.customization?.bodySize || 'md',
    borderRadius: settings.customization?.borderRadius || 'none',
    buttonStyle: settings.customization?.buttonStyle || 'sharp',
    cardStyle: settings.customization?.cardStyle || 'bordered',
  });

  const [savedSuccess, setSavedSuccess] = useState(false);
  const [activeTab, setActiveTab] = useState<'colors' | 'typography' | 'branding' | 'ui'>('colors');

  const handleApplyPreset = (presetCustomization: Partial<WebsiteCustomization>) => {
    setFormData((prev) => ({
      ...prev,
      ...presetCustomization,
    }));
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateCustomization(formData);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const handleResetDefaults = () => {
    if (window.confirm('Reset all website visual customization back to the default AFURN showroom appearance?')) {
      const defaultValues: WebsiteCustomization = {
        logoType: 'text',
        logoText: 'AFURN',
        logoImage: '',
        favicon: '',
        primaryColor: '#473C38',
        secondaryColor: '#E3CAAB',
        accentColor: '#B08A62',
        backgroundColor: '#F7F3EE',
        textColor: '#292522',
        buttonColor: '#473C38',
        buttonTextColor: '#FFFFFF',
        headingFont: 'Cormorant Garamond',
        bodyFont: 'Plus Jakarta Sans',
        headingSize: 'lg',
        bodySize: 'md',
        borderRadius: 'none',
        buttonStyle: 'sharp',
        cardStyle: 'bordered',
      };
      setFormData(defaultValues);
      updateCustomization(defaultValues);
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 3000);
    }
  };

  // Preview radius calculation
  const getRadiusClass = (radius: string) => {
    switch (radius) {
      case 'sm':
        return 'rounded-sm';
      case 'md':
        return 'rounded-md';
      case 'lg':
        return 'rounded-xl';
      default:
        return 'rounded-none';
    }
  };

  const getButtonRadiusClass = (style: string) => {
    switch (style) {
      case 'rounded':
        return 'rounded-full';
      case 'subtle':
        return 'rounded-md';
      default:
        return 'rounded-none';
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Top Header */}
      <div className="bg-white p-6 border border-[#E3CAAB] shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] tracking-[0.2em] uppercase font-bold text-[#B08A62]">
            DESIGN SYSTEM & STYLING
          </span>
          <h1 className="text-2xl font-serif font-medium text-[#292522] mt-0.5">
            Website Customization & Branding
          </h1>
          <p className="text-xs text-[#473C38]/70 mt-1">
            Customize the storefront logo, color palette, typography, and card aesthetic without writing code.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={handleResetDefaults}
            className="px-4 py-2.5 bg-white border border-[#473C38] text-[#473C38] hover:bg-[#F7F3EE] text-xs font-semibold tracking-wider flex items-center gap-2 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>RESET DEFAULTS</span>
          </button>

          <button
            type="button"
            onClick={handleSave}
            className="px-5 py-2.5 bg-[#473C38] text-white hover:bg-[#B08A62] text-xs font-semibold tracking-wider flex items-center gap-2 transition-colors shadow-xs cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>SAVE CUSTOMIZATION</span>
          </button>
        </div>
      </div>

      {savedSuccess && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2.5 animate-fade-in shadow-xs">
          <CheckCircle2 className="w-5 h-5 shrink-0 text-emerald-600" />
          <span>
            <strong>Success!</strong> Website customization saved. Your public website now reflects the updated branding, colors, and typography instantly!
          </span>
        </div>
      )}

      {/* Main 2-Column Layout: Controls (Left) & Real-time Live Preview (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Column: Form Controls */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Navigation Tabs */}
          <div className="flex border-b border-[#E3CAAB] bg-white">
            <button
              type="button"
              onClick={() => setActiveTab('colors')}
              className={`px-5 py-3 text-xs font-semibold tracking-wider uppercase transition-colors flex items-center gap-2 cursor-pointer ${
                activeTab === 'colors'
                  ? 'border-b-2 border-[#B08A62] text-[#473C38] bg-[#F7F3EE]/50 font-bold'
                  : 'text-[#473C38]/60 hover:text-[#473C38]'
              }`}
            >
              <Palette className="w-4 h-4" />
              <span>Colors</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('typography')}
              className={`px-5 py-3 text-xs font-semibold tracking-wider uppercase transition-colors flex items-center gap-2 cursor-pointer ${
                activeTab === 'typography'
                  ? 'border-b-2 border-[#B08A62] text-[#473C38] bg-[#F7F3EE]/50 font-bold'
                  : 'text-[#473C38]/60 hover:text-[#473C38]'
              }`}
            >
              <Type className="w-4 h-4" />
              <span>Typography</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('branding')}
              className={`px-5 py-3 text-xs font-semibold tracking-wider uppercase transition-colors flex items-center gap-2 cursor-pointer ${
                activeTab === 'branding'
                  ? 'border-b-2 border-[#B08A62] text-[#473C38] bg-[#F7F3EE]/50 font-bold'
                  : 'text-[#473C38]/60 hover:text-[#473C38]'
              }`}
            >
              <ImageIcon className="w-4 h-4" />
              <span>Logo & Favicon</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('ui')}
              className={`px-5 py-3 text-xs font-semibold tracking-wider uppercase transition-colors flex items-center gap-2 cursor-pointer ${
                activeTab === 'ui'
                  ? 'border-b-2 border-[#B08A62] text-[#473C38] bg-[#F7F3EE]/50 font-bold'
                  : 'text-[#473C38]/60 hover:text-[#473C38]'
              }`}
            >
              <Layers className="w-4 h-4" />
              <span>Buttons & Cards</span>
            </button>
          </div>

          {/* TAB 1: COLORS */}
          {activeTab === 'colors' && (
            <div className="bg-white p-6 border border-[#E3CAAB] shadow-xs space-y-6">
              <div>
                <h2 className="font-serif text-lg font-medium text-[#292522]">
                  Color Palette Customization
                </h2>
                <p className="text-xs text-[#473C38]/70 mt-0.5">
                  Pick individual hex codes or select from high-end furniture brand presets.
                </p>
              </div>

              {/* 1-Click Curated Presets */}
              <div className="space-y-2">
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38]">
                  Quick Showroom Presets
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {PRESET_PALETTES.map((p) => (
                    <button
                      key={p.name}
                      type="button"
                      onClick={() => handleApplyPreset(p.customization)}
                      className="p-3 text-left border border-[#E3CAAB] hover:border-[#B08A62] bg-[#F7F3EE]/30 hover:bg-[#F7F3EE] transition-all flex flex-col justify-between gap-2 cursor-pointer group"
                    >
                      <span className="text-xs font-semibold text-[#292522] group-hover:text-[#B08A62]">
                        {p.name}
                      </span>
                      <div className="flex items-center gap-1.5">
                        <span className="w-4 h-4 rounded-full border border-black/10" style={{ backgroundColor: p.customization.primaryColor }} title="Primary" />
                        <span className="w-4 h-4 rounded-full border border-black/10" style={{ backgroundColor: p.customization.secondaryColor }} title="Secondary" />
                        <span className="w-4 h-4 rounded-full border border-black/10" style={{ backgroundColor: p.customization.accentColor }} title="Accent" />
                        <span className="w-4 h-4 rounded-full border border-black/10" style={{ backgroundColor: p.customization.backgroundColor }} title="Canvas" />
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Color Pickers Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                {/* Primary Color */}
                <div className="p-3.5 border border-[#E3CAAB]/70 bg-[#F7F3EE]/20 space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-semibold text-[#473C38]">Primary Dark Color</label>
                    <span className="text-[11px] font-mono text-[#473C38]/70 uppercase">{formData.primaryColor}</span>
                  </div>
                  <p className="text-[11px] text-[#473C38]/60">Used for headers, dark badges, and prominent contrast elements.</p>
                  <div className="flex items-center gap-3">
                    <input
                      type="color"
                      value={formData.primaryColor}
                      onChange={(e) => setFormData({ ...formData, primaryColor: e.target.value })}
                      className="w-10 h-10 p-0 border border-[#E3CAAB] cursor-pointer bg-transparent"
                    />
                    <input
                      type="text"
                      value={formData.primaryColor}
                      onChange={(e) => setFormData({ ...formData, primaryColor: e.target.value })}
                      className="flex-1 px-3 py-1.5 text-xs font-mono uppercase bg-white border border-[#E3CAAB] focus:outline-none focus:border-[#473C38]"
                    />
                  </div>
                </div>

                {/* Secondary Color */}
                <div className="p-3.5 border border-[#E3CAAB]/70 bg-[#F7F3EE]/20 space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-semibold text-[#473C38]">Secondary Sandstone</label>
                    <span className="text-[11px] font-mono text-[#473C38]/70 uppercase">{formData.secondaryColor}</span>
                  </div>
                  <p className="text-[11px] text-[#473C38]/60">Used for borders, dividers, subtle highlight panels, and tags.</p>
                  <div className="flex items-center gap-3">
                    <input
                      type="color"
                      value={formData.secondaryColor}
                      onChange={(e) => setFormData({ ...formData, secondaryColor: e.target.value })}
                      className="w-10 h-10 p-0 border border-[#E3CAAB] cursor-pointer bg-transparent"
                    />
                    <input
                      type="text"
                      value={formData.secondaryColor}
                      onChange={(e) => setFormData({ ...formData, secondaryColor: e.target.value })}
                      className="flex-1 px-3 py-1.5 text-xs font-mono uppercase bg-white border border-[#E3CAAB] focus:outline-none focus:border-[#473C38]"
                    />
                  </div>
                </div>

                {/* Accent Color */}
                <div className="p-3.5 border border-[#E3CAAB]/70 bg-[#F7F3EE]/20 space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-semibold text-[#473C38]">Accent Teak Color</label>
                    <span className="text-[11px] font-mono text-[#473C38]/70 uppercase">{formData.accentColor}</span>
                  </div>
                  <p className="text-[11px] text-[#473C38]/60">Used for category tags, stars, active badges, and hover links.</p>
                  <div className="flex items-center gap-3">
                    <input
                      type="color"
                      value={formData.accentColor}
                      onChange={(e) => setFormData({ ...formData, accentColor: e.target.value })}
                      className="w-10 h-10 p-0 border border-[#E3CAAB] cursor-pointer bg-transparent"
                    />
                    <input
                      type="text"
                      value={formData.accentColor}
                      onChange={(e) => setFormData({ ...formData, accentColor: e.target.value })}
                      className="flex-1 px-3 py-1.5 text-xs font-mono uppercase bg-white border border-[#E3CAAB] focus:outline-none focus:border-[#473C38]"
                    />
                  </div>
                </div>

                {/* Background Canvas Color */}
                <div className="p-3.5 border border-[#E3CAAB]/70 bg-[#F7F3EE]/20 space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-semibold text-[#473C38]">Main Background Canvas</label>
                    <span className="text-[11px] font-mono text-[#473C38]/70 uppercase">{formData.backgroundColor}</span>
                  </div>
                  <p className="text-[11px] text-[#473C38]/60">Primary page backdrop color (warm linen/cream recommended).</p>
                  <div className="flex items-center gap-3">
                    <input
                      type="color"
                      value={formData.backgroundColor}
                      onChange={(e) => setFormData({ ...formData, backgroundColor: e.target.value })}
                      className="w-10 h-10 p-0 border border-[#E3CAAB] cursor-pointer bg-transparent"
                    />
                    <input
                      type="text"
                      value={formData.backgroundColor}
                      onChange={(e) => setFormData({ ...formData, backgroundColor: e.target.value })}
                      className="flex-1 px-3 py-1.5 text-xs font-mono uppercase bg-white border border-[#E3CAAB] focus:outline-none focus:border-[#473C38]"
                    />
                  </div>
                </div>

                {/* Text Color */}
                <div className="p-3.5 border border-[#E3CAAB]/70 bg-[#F7F3EE]/20 space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-semibold text-[#473C38]">Body Text Color</label>
                    <span className="text-[11px] font-mono text-[#473C38]/70 uppercase">{formData.textColor}</span>
                  </div>
                  <p className="text-[11px] text-[#473C38]/60">Main reading text and description typography.</p>
                  <div className="flex items-center gap-3">
                    <input
                      type="color"
                      value={formData.textColor}
                      onChange={(e) => setFormData({ ...formData, textColor: e.target.value })}
                      className="w-10 h-10 p-0 border border-[#E3CAAB] cursor-pointer bg-transparent"
                    />
                    <input
                      type="text"
                      value={formData.textColor}
                      onChange={(e) => setFormData({ ...formData, textColor: e.target.value })}
                      className="flex-1 px-3 py-1.5 text-xs font-mono uppercase bg-white border border-[#E3CAAB] focus:outline-none focus:border-[#473C38]"
                    />
                  </div>
                </div>

                {/* Button Color & Button Text Color */}
                <div className="p-3.5 border border-[#E3CAAB]/70 bg-[#F7F3EE]/20 space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-semibold text-[#473C38]">Primary Button Color</label>
                    <span className="text-[11px] font-mono text-[#473C38]/70 uppercase">{formData.buttonColor}</span>
                  </div>
                  <p className="text-[11px] text-[#473C38]/60">Main Call-to-Action button background.</p>
                  <div className="flex items-center gap-3">
                    <input
                      type="color"
                      value={formData.buttonColor}
                      onChange={(e) => setFormData({ ...formData, buttonColor: e.target.value })}
                      className="w-10 h-10 p-0 border border-[#E3CAAB] cursor-pointer bg-transparent"
                    />
                    <input
                      type="text"
                      value={formData.buttonColor}
                      onChange={(e) => setFormData({ ...formData, buttonColor: e.target.value })}
                      className="flex-1 px-3 py-1.5 text-xs font-mono uppercase bg-white border border-[#E3CAAB] focus:outline-none focus:border-[#473C38]"
                    />
                  </div>

                  <div className="pt-2 flex items-center justify-between">
                    <span className="text-[11px] font-semibold text-[#473C38]">Button Text Color:</span>
                    <div className="flex items-center gap-2">
                      <input
                        type="color"
                        value={formData.buttonTextColor}
                        onChange={(e) => setFormData({ ...formData, buttonTextColor: e.target.value })}
                        className="w-6 h-6 border border-[#E3CAAB] cursor-pointer"
                      />
                      <span className="text-[10px] font-mono uppercase">{formData.buttonTextColor}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: TYPOGRAPHY */}
          {activeTab === 'typography' && (
            <div className="bg-white p-6 border border-[#E3CAAB] shadow-xs space-y-6">
              <div>
                <h2 className="font-serif text-lg font-medium text-[#292522]">
                  Typography & Font Family
                </h2>
                <p className="text-xs text-[#473C38]/70 mt-0.5">
                  Select heading and body typefaces suited to high-end furniture aesthetics.
                </p>
              </div>

              <div className="space-y-4">
                {/* Heading Font */}
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1.5">
                    Heading Font (Headlines, Titles, Logos)
                  </label>
                  <select
                    value={formData.headingFont}
                    onChange={(e) => setFormData({ ...formData, headingFont: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
                  >
                    {HEADING_FONTS.map((font) => (
                      <option key={font.value} value={font.value}>
                        {font.label}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Body Font */}
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1.5">
                    Body Font (Paragraphs, Product Specs, Buttons)
                  </label>
                  <select
                    value={formData.bodyFont}
                    onChange={(e) => setFormData({ ...formData, bodyFont: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
                  >
                    {BODY_FONTS.map((font) => (
                      <option key={font.value} value={font.value}>
                        {font.label}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Sizes */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1.5">
                      Heading Scale Size
                    </label>
                    <select
                      value={formData.headingSize}
                      onChange={(e) => setFormData({ ...formData, headingSize: e.target.value as any })}
                      className="w-full px-3.5 py-2 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522]"
                    >
                      <option value="sm">Small / Compact</option>
                      <option value="md">Medium / Standard</option>
                      <option value="lg">Large / Editorial (Recommended)</option>
                      <option value="xl">Extra Large / Dramatic</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1.5">
                      Body Base Size
                    </label>
                    <select
                      value={formData.bodySize}
                      onChange={(e) => setFormData({ ...formData, bodySize: e.target.value as any })}
                      className="w-full px-3.5 py-2 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522]"
                    >
                      <option value="sm">Compact (14px)</option>
                      <option value="md">Standard (15px - Recommended)</option>
                      <option value="lg">Spacious (16px)</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: BRANDING (LOGO & FAVICON) */}
          {activeTab === 'branding' && (
            <div className="bg-white p-6 border border-[#E3CAAB] shadow-xs space-y-6">
              <div>
                <h2 className="font-serif text-lg font-medium text-[#292522]">
                  Storefront Logo & Favicon
                </h2>
                <p className="text-xs text-[#473C38]/70 mt-0.5">
                  Choose between a typographic luxury serif wordmark or an uploaded logo image.
                </p>
              </div>

              {/* Logo Type Selector */}
              <div className="space-y-3">
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38]">
                  Logo Display Type
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, logoType: 'text' })}
                    className={`p-3 text-left border text-xs font-semibold transition-colors cursor-pointer ${
                      formData.logoType === 'text'
                        ? 'border-[#B08A62] bg-[#F7F3EE] text-[#473C38]'
                        : 'border-[#E3CAAB] bg-white text-[#473C38]/70'
                    }`}
                  >
                    <span className="block font-serif text-lg tracking-[0.2em] font-bold">AFURN</span>
                    <span className="text-[10px] text-[#B08A62] font-sans font-medium mt-1 block">
                      Text Wordmark (Recommended)
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, logoType: 'image' })}
                    className={`p-3 text-left border text-xs font-semibold transition-colors cursor-pointer ${
                      formData.logoType === 'image'
                        ? 'border-[#B08A62] bg-[#F7F3EE] text-[#473C38]'
                        : 'border-[#E3CAAB] bg-white text-[#473C38]/70'
                    }`}
                  >
                    <span className="block text-sm font-sans font-bold flex items-center gap-1.5">
                      <ImageIcon className="w-4 h-4 text-[#B08A62]" />
                      Custom Logo Image
                    </span>
                    <span className="text-[10px] text-[#B08A62] font-sans font-medium mt-1 block">
                      PNG / SVG file URL
                    </span>
                  </button>
                </div>
              </div>

              {formData.logoType === 'text' ? (
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                    Brand Logo Wordmark Text
                  </label>
                  <input
                    type="text"
                    value={formData.logoText}
                    onChange={(e) => setFormData({ ...formData, logoText: e.target.value })}
                    placeholder="AFURN"
                    className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-sm font-serif tracking-[0.2em] font-bold text-[#292522] focus:outline-none focus:border-[#473C38]"
                  />
                  <p className="text-[11px] text-[#473C38]/60 mt-1">
                    Will be displayed in high-end uppercase typography on the sticky navigation header.
                  </p>
                </div>
              ) : (
                <div className="space-y-2">
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38]">
                    Logo Image URL
                  </label>
                  <input
                    type="url"
                    value={formData.logoImage}
                    onChange={(e) => setFormData({ ...formData, logoImage: e.target.value })}
                    placeholder="https://example.com/afurn-logo.png"
                    className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
                  />
                  <p className="text-[11px] text-[#473C38]/60">
                    Provide a transparent PNG or SVG logo image URL (recommended height: 40px - 60px).
                  </p>
                </div>
              )}

              {/* Favicon URL */}
              <div className="pt-2 border-t border-[#E3CAAB]/50 space-y-2">
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38]">
                  Website Favicon URL
                </label>
                <input
                  type="url"
                  value={formData.favicon}
                  onChange={(e) => setFormData({ ...formData, favicon: e.target.value })}
                  placeholder="https://example.com/favicon.ico"
                  className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
                />
                <p className="text-[11px] text-[#473C38]/60">
                  Icon that appears in browser tabs and bookmarks.
                </p>
              </div>
            </div>
          )}

          {/* TAB 4: BUTTONS & CARDS */}
          {activeTab === 'ui' && (
            <div className="bg-white p-6 border border-[#E3CAAB] shadow-xs space-y-6">
              <div>
                <h2 className="font-serif text-lg font-medium text-[#292522]">
                  Buttons, Corners & Card Architecture
                </h2>
                <p className="text-xs text-[#473C38]/70 mt-0.5">
                  Control the geometric personality of cards and buttons across the showroom.
                </p>
              </div>

              {/* Border Radius */}
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-2">
                  Global Border Radius
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  {[
                    { label: 'Sharp (0px)', value: 'none', note: 'Luxury Architectural' },
                    { label: 'Subtle (4px)', value: 'sm', note: 'Refined Contemporary' },
                    { label: 'Modern (8px)', value: 'md', note: 'Soft Modern' },
                    { label: 'Rounded (16px)', value: 'lg', note: 'Friendly Warm' },
                  ].map((r) => (
                    <button
                      key={r.value}
                      type="button"
                      onClick={() => setFormData({ ...formData, borderRadius: r.value as any })}
                      className={`p-3 text-center border text-xs transition-colors cursor-pointer ${
                        formData.borderRadius === r.value
                          ? 'border-[#B08A62] bg-[#F7F3EE] text-[#473C38] font-bold'
                          : 'border-[#E3CAAB] bg-white text-[#473C38]/70 hover:bg-[#F7F3EE]/30'
                      }`}
                    >
                      <span className="block font-semibold">{r.label}</span>
                      <span className="text-[10px] text-[#B08A62] block mt-0.5">{r.note}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Button Style */}
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-2">
                  CTA Button Style
                </label>
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { label: 'Sharp Rectangle', value: 'sharp', class: 'rounded-none' },
                    { label: 'Subtle Rounded', value: 'subtle', class: 'rounded-md' },
                    { label: 'Pill Rounded', value: 'rounded', class: 'rounded-full' },
                  ].map((b) => (
                    <button
                      key={b.value}
                      type="button"
                      onClick={() => setFormData({ ...formData, buttonStyle: b.value as any })}
                      className={`p-3 text-center border text-xs transition-colors cursor-pointer ${
                        formData.buttonStyle === b.value
                          ? 'border-[#B08A62] bg-[#F7F3EE] text-[#473C38] font-bold'
                          : 'border-[#E3CAAB] bg-white text-[#473C38]/70 hover:bg-[#F7F3EE]/30'
                      }`}
                    >
                      <div className={`mx-auto w-16 py-1.5 bg-[#473C38] text-white text-[10px] uppercase font-bold tracking-wider mb-2 ${b.class}`}>
                        BTN
                      </div>
                      <span className="block font-medium">{b.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Card Style */}
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-2">
                  Product Card Presentation
                </label>
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { label: 'Bordered (Showroom Clean)', value: 'bordered' },
                    { label: 'Elevated (Soft Shadow)', value: 'elevated' },
                    { label: 'Minimal (Borderless Canvas)', value: 'minimal' },
                  ].map((c) => (
                    <button
                      key={c.value}
                      type="button"
                      onClick={() => setFormData({ ...formData, cardStyle: c.value as any })}
                      className={`p-3 text-center border text-xs transition-colors cursor-pointer ${
                        formData.cardStyle === c.value
                          ? 'border-[#B08A62] bg-[#F7F3EE] text-[#473C38] font-bold'
                          : 'border-[#E3CAAB] bg-white text-[#473C38]/70 hover:bg-[#F7F3EE]/30'
                      }`}
                    >
                      <span className="block font-semibold">{c.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Right Column: Interactive Live Preview Card */}
        <div className="lg:col-span-5 sticky top-20 space-y-4">
          <div className="bg-white p-4 border border-[#E3CAAB] shadow-sm flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Eye className="w-4 h-4 text-[#B08A62]" />
              <span className="text-xs font-semibold uppercase tracking-wider text-[#473C38]">
                Real-Time Live Preview
              </span>
            </div>
            <span className="text-[10px] bg-emerald-100 text-emerald-800 font-semibold px-2 py-0.5 rounded-full">
              Instant Updates
            </span>
          </div>

          {/* Simulated Website Component Canvas */}
          <div
            className="p-6 border shadow-lg space-y-6 transition-all duration-200"
            style={{
              backgroundColor: formData.backgroundColor,
              color: formData.textColor,
              borderColor: formData.secondaryColor,
              fontFamily: formData.bodyFont,
            }}
          >
            {/* Header simulation */}
            <div
              className="pb-4 border-b flex items-center justify-between"
              style={{ borderColor: `${formData.secondaryColor}80` }}
            >
              <div>
                {formData.logoType === 'image' && formData.logoImage ? (
                  <img src={formData.logoImage} alt="Logo preview" className="h-7 object-contain" />
                ) : (
                  <span
                    className="text-xl tracking-[0.2em] font-bold"
                    style={{
                      fontFamily: formData.headingFont,
                      color: formData.primaryColor,
                    }}
                  >
                    {formData.logoText || 'AFURN'}
                  </span>
                )}
              </div>

              <div className="flex items-center gap-3 text-[11px] font-semibold tracking-wider">
                <span className="opacity-90">SHOP</span>
                <span className="opacity-90">ABOUT</span>
                <span
                  className="px-2 py-0.5 text-[10px] text-white"
                  style={{ backgroundColor: formData.accentColor }}
                >
                  NEW
                </span>
              </div>
            </div>

            {/* Typography Preview Section */}
            <div className="space-y-2">
              <span
                className="text-[10px] tracking-[0.2em] uppercase font-bold"
                style={{ color: formData.accentColor }}
              >
                CRAFTED FOR MODERN LIVING
              </span>
              <h3
                className={`font-medium leading-tight ${
                  formData.headingSize === 'xl'
                    ? 'text-2xl'
                    : formData.headingSize === 'lg'
                    ? 'text-xl'
                    : 'text-lg'
                }`}
                style={{
                  fontFamily: formData.headingFont,
                  color: formData.textColor,
                }}
              >
                Handcrafted Teakwood Living Room Collection
              </h3>
              <p
                className={`leading-relaxed opacity-80 ${
                  formData.bodySize === 'lg'
                    ? 'text-sm'
                    : formData.bodySize === 'sm'
                    ? 'text-xs'
                    : 'text-[13px]'
                }`}
              >
                Master carpenters in Danilimda, Ahmedabad crafting generational furniture with 15+ years of excellence.
              </p>
            </div>

            {/* Button Previews */}
            <div className="flex flex-wrap items-center gap-3 pt-1">
              <button
                type="button"
                className={`px-5 py-2.5 text-xs font-semibold tracking-wider uppercase transition-transform active:scale-95 shadow-xs ${getButtonRadiusClass(
                  formData.buttonStyle
                )}`}
                style={{
                  backgroundColor: formData.buttonColor,
                  color: formData.buttonTextColor,
                }}
              >
                EXPLORE CATALOG
              </button>

              <button
                type="button"
                className={`px-5 py-2.5 text-xs font-semibold tracking-wider uppercase border transition-colors ${getButtonRadiusClass(
                  formData.buttonStyle
                )}`}
                style={{
                  borderColor: formData.buttonColor,
                  color: formData.buttonColor,
                  backgroundColor: 'transparent',
                }}
              >
                CUSTOM ORDER
              </button>
            </div>

            {/* Product Card Preview */}
            <div
              className={`p-3 bg-white transition-all ${
                formData.cardStyle === 'elevated'
                  ? 'shadow-md border-0'
                  : formData.cardStyle === 'bordered'
                  ? 'border shadow-none'
                  : 'border-0 shadow-none bg-transparent'
              } ${getRadiusClass(formData.borderRadius)}`}
              style={{
                borderColor: formData.secondaryColor,
              }}
            >
              <div className="relative aspect-[4/3] bg-neutral-100 overflow-hidden mb-3">
                <img
                  src={sofaImg}
                  alt="Product preview"
                  className="w-full h-full object-cover"
                />
                <span
                  className="absolute top-2 left-2 text-[10px] font-bold uppercase tracking-wider text-white px-2 py-0.5"
                  style={{ backgroundColor: formData.accentColor }}
                >
                  Featured
                </span>
              </div>

              <div className="space-y-1">
                <p className="text-[10px] uppercase tracking-wider opacity-60">LIVING ROOM</p>
                <h4
                  className="text-sm font-semibold truncate"
                  style={{ fontFamily: formData.headingFont }}
                >
                  The Heritage Teak Lounge Chair
                </h4>
                <div className="flex items-center justify-between pt-1">
                  <span
                    className="text-sm font-bold font-serif"
                    style={{ color: formData.primaryColor }}
                  >
                    ₹34,500
                  </span>
                  <span
                    className="text-[11px] font-semibold tracking-wider underline cursor-pointer"
                    style={{ color: formData.accentColor }}
                  >
                    Quick Add +
                  </span>
                </div>
              </div>
            </div>

            {/* Color Swatches footer */}
            <div className="pt-3 border-t flex items-center justify-between text-[10px] opacity-75" style={{ borderColor: `${formData.secondaryColor}60` }}>
              <span>ACTIVE PALETTE:</span>
              <div className="flex items-center gap-1.5 font-mono">
                <span className="w-3.5 h-3.5 rounded-full" style={{ backgroundColor: formData.primaryColor }} />
                <span className="w-3.5 h-3.5 rounded-full" style={{ backgroundColor: formData.secondaryColor }} />
                <span className="w-3.5 h-3.5 rounded-full" style={{ backgroundColor: formData.accentColor }} />
                <span className="w-3.5 h-3.5 rounded-full" style={{ backgroundColor: formData.backgroundColor }} />
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
