import React, { useState, useEffect } from 'react';
import { useNavigate, useParams, Link } from 'react-router-dom';
import {
  Upload,
  X,
  Plus,
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  AlertCircle,
  Image as ImageIcon,
  Sparkles,
  Info,
  Star,
  MoveHorizontal,
  GripVertical,
  ChevronLeft,
  ChevronRight,
  Link as LinkIcon
} from 'lucide-react';
import { useData } from '../../context/DataContext';
import { Product, AvailabilityStatus, ProductStatus } from '../../types/furniture';
import { optimizeImageFile } from '../../utils/imageUpload';
import { IMAGES } from '../../data/furnitureData';

export default function AdminProductForm() {
  const { id } = useParams<{ id: string }>();
  const isEditing = Boolean(id);

  const { products, addProduct, updateProduct, categories } = useData();
  const navigate = useNavigate();

  // Form states
  const [name, setName] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const [shortDescription, setShortDescription] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState<number | ''>('');
  const [discountPrice, setDiscountPrice] = useState<number | ''>('');
  const [sku, setSku] = useState('');
  const [material, setMaterial] = useState('');
  const [colors, setColors] = useState<string[]>(['Natural Teak', 'Dark Walnut']);
  const [colorInput, setColorInput] = useState('');
  const [dimensions, setDimensions] = useState('');
  const [weight, setWeight] = useState('');
  const [availability, setAvailability] = useState<AvailabilityStatus>('In Stock');
  const [stock, setStock] = useState<number>(10);
  const [featured, setFeatured] = useState<boolean>(false);
  const [customizable, setCustomizable] = useState<boolean>(true);
  const [status, setStatus] = useState<ProductStatus>('active');

  // Multiple Images state
  const [images, setImages] = useState<string[]>([]);
  const [draggedIndex, setDraggedIndex] = useState<number | null>(null);
  const [isDraggingOverDropzone, setIsDraggingOverDropzone] = useState(false);
  const [imageUrlInput, setImageUrlInput] = useState('');
  const [showUrlInput, setShowUrlInput] = useState(false);

  const [uploadLoading, setUploadLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // If editing, load product data
  useEffect(() => {
    if (isEditing && id) {
      const prod = products.find((p) => p.id === id);
      if (prod) {
        setName(prod.name);
        setCategoryId(prod.categoryId);
        setShortDescription(prod.shortDescription || '');
        setDescription(prod.description);
        setPrice(prod.price);
        setDiscountPrice(prod.discountPrice || prod.originalPrice || '');
        setSku(prod.sku);
        setMaterial(prod.material || prod.materials || '');
        setColors(prod.colors && prod.colors.length > 0 ? prod.colors : prod.finishOptions || []);
        setDimensions(prod.dimensions);
        setWeight(prod.weight || '');
        setAvailability(prod.availability || 'In Stock');
        setStock(prod.stock ?? 10);
        setFeatured(prod.featured ?? prod.isBestSeller ?? false);
        setCustomizable(prod.customizable ?? true);
        setStatus(prod.status || 'active');

        // Load all existing images
        const existingImages: string[] = [];
        if (prod.images && prod.images.length > 0) {
          existingImages.push(...prod.images);
        } else if (prod.image) {
          existingImages.push(prod.image);
        }
        setImages(existingImages);
      } else {
        setError(`Product with ID "${id}" was not found.`);
      }
    } else if (categories.length > 0 && !categoryId) {
      setCategoryId(categories[0].id);
      // Auto-generate sample SKU for new product
      setSku(`AF-${categories[0].id.substring(0, 3).toUpperCase()}-${Math.floor(100 + Math.random() * 900)}`);
    }
  }, [isEditing, id, products, categories]);

  // When category changes, auto-suggest SKU prefix if adding new
  const handleCategoryChange = (newCatId: string) => {
    setCategoryId(newCatId);
    if (!isEditing && (!sku || sku.startsWith('AF-'))) {
      setSku(`AF-${newCatId.substring(0, 3).toUpperCase()}-${Math.floor(100 + Math.random() * 900)}`);
    }
  };

  // Color tag handlers
  const handleAddColor = () => {
    if (colorInput.trim() && !colors.includes(colorInput.trim())) {
      setColors([...colors, colorInput.trim()]);
      setColorInput('');
    }
  };

  const handleRemoveColor = (indexToRemove: number) => {
    setColors(colors.filter((_, idx) => idx !== indexToRemove));
  };

  // Multiple Image Upload Handler (Supports multiple files at once, appends to existing)
  const handleMultipleFilesUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    try {
      setUploadLoading(true);
      setError(null);
      const newUrls: string[] = [];

      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const isImage =
          (file.type && file.type.startsWith('image/')) ||
          (file.name && Boolean(file.name.match(/\.(jpe?g|png|webp)$/i)));

        if (isImage) {
          const optimized = await optimizeImageFile(file);
          newUrls.push(optimized);
        }
      }

      if (newUrls.length === 0) {
        setError('Please select valid image files (JPG, JPEG, PNG, or WEBP).');
        return;
      }

      // Append new images to existing without removing existing ones
      setImages((prev) => [...prev, ...newUrls]);
    } catch (err: any) {
      setError(err.message || 'Failed to process selected images.');
    } finally {
      setUploadLoading(false);
      // Reset input value so same files can be re-selected if desired
      e.target.value = '';
    }
  };

  // Drag and Drop File Upload
  const handleDropFiles = async (e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingOverDropzone(false);
    const files = e.dataTransfer.files;
    if (!files || files.length === 0) return;

    try {
      setUploadLoading(true);
      setError(null);
      const newUrls: string[] = [];

      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const isImage =
          (file.type && file.type.startsWith('image/')) ||
          (file.name && Boolean(file.name.match(/\.(jpe?g|png|webp)$/i)));

        if (isImage) {
          const optimized = await optimizeImageFile(file);
          newUrls.push(optimized);
        }
      }

      if (newUrls.length === 0) {
        setError('Please drop valid image files (JPG, JPEG, PNG, or WEBP).');
        return;
      }

      // Append to existing images
      setImages((prev) => [...prev, ...newUrls]);
    } catch (err: any) {
      setError(err.message || 'Failed to process dropped files.');
    } finally {
      setUploadLoading(false);
    }
  };

  // Add Image by URL
  const handleAddImageUrl = () => {
    if (!imageUrlInput.trim()) return;
    setImages((prev) => [...prev, imageUrlInput.trim()]);
    setImageUrlInput('');
    setShowUrlInput(false);
  };

  // Quick Add Showroom Sample Photo
  const handleAddSamplePhoto = (sampleUrl: string) => {
    if (!images.includes(sampleUrl)) {
      setImages((prev) => [...prev, sampleUrl]);
    }
  };

  // Remove Single Image
  const handleRemoveImage = (indexToRemove: number) => {
    setImages((prev) => prev.filter((_, idx) => idx !== indexToRemove));
  };

  // Set an image as the Main Image (Moves it to index 0)
  const handleSetAsMain = (indexToPromote: number) => {
    if (indexToPromote === 0) return;
    setImages((prev) => {
      const next = [...prev];
      const [promoted] = next.splice(indexToPromote, 1);
      next.unshift(promoted);
      return next;
    });
  };

  // Move image position Left
  const handleMoveLeft = (index: number) => {
    if (index === 0) return;
    setImages((prev) => {
      const next = [...prev];
      const temp = next[index];
      next[index] = next[index - 1];
      next[index - 1] = temp;
      return next;
    });
  };

  // Move image position Right
  const handleMoveRight = (index: number) => {
    if (index >= images.length - 1) return;
    setImages((prev) => {
      const next = [...prev];
      const temp = next[index];
      next[index] = next[index + 1];
      next[index + 1] = temp;
      return next;
    });
  };

  // HTML5 Drag and Drop Reordering
  const handleDragStart = (index: number) => {
    setDraggedIndex(index);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDropReorder = (targetIndex: number) => {
    if (draggedIndex === null || draggedIndex === targetIndex) {
      setDraggedIndex(null);
      return;
    }

    setImages((prev) => {
      const next = [...prev];
      const [draggedItem] = next.splice(draggedIndex, 1);
      next.splice(targetIndex, 0, draggedItem);
      return next;
    });
    setDraggedIndex(null);
  };

  // Validation
  const validateForm = () => {
    if (!name.trim()) return 'Product Name is required.';
    if (!categoryId) return 'Category is required.';
    if (!price || Number(price) <= 0) return 'Valid Price is required.';
    if (!dimensions.trim()) return 'Dimensions are required.';
    if (!material.trim()) return 'Material description is required.';
    if (images.length === 0) return 'At least one product image is required. Please upload or add images.';
    return null;
  };

  // Form Submit
  const handleSave = (addAnother = false) => {
    const validationError = validateForm();
    if (validationError) {
      setError(validationError);
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    const catObj = categories.find((c) => c.id === categoryId);
    const categoryLabel = catObj ? catObj.name : categoryId;

    // First image is always the primary main product image
    const mainImage = images[0];

    const productPayload = {
      name: name.trim(),
      slug: name.trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''),
      categoryId,
      categoryLabel,
      shortDescription: shortDescription.trim(),
      description: description.trim() || shortDescription.trim(),
      price: Number(price),
      discountPrice: discountPrice ? Number(discountPrice) : undefined,
      originalPrice: discountPrice ? Number(discountPrice) : undefined,
      sku: sku.trim() || `AF-${Date.now()}`,
      material: material.trim(),
      materials: material.trim(),
      colors,
      finishOptions: colors,
      dimensions: dimensions.trim(),
      weight: weight.trim() || 'N/A',
      availability,
      stock: Number(stock),
      inStock: availability !== 'Out of Stock' && Number(stock) > 0,
      featured,
      isBestSeller: featured,
      customizable,
      status,
      image: mainImage,
      images: images,
      leadTimeDays: availability === 'In Stock' ? 5 : 12,
    };

    if (isEditing && id) {
      updateProduct(id, productPayload);
      setSuccessMessage('Product updated successfully! Images and catalog changes are live.');
      setTimeout(() => {
        navigate('/admin/products');
      }, 1000);
    } else {
      addProduct(productPayload);
      if (addAnother) {
        setSuccessMessage('Product saved! You can now add another product.');
        // Reset form for next item
        setName('');
        setShortDescription('');
        setDescription('');
        setPrice('');
        setDiscountPrice('');
        setSku(`AF-${categoryId.substring(0, 3).toUpperCase()}-${Math.floor(100 + Math.random() * 900)}`);
        setDimensions('');
        setWeight('');
        setImages([]);
        window.scrollTo({ top: 0, behavior: 'smooth' });
      } else {
        setSuccessMessage('Product added successfully! It is now visible on the website.');
        setTimeout(() => {
          navigate('/admin/products');
        }, 1000);
      }
    }
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Top Header */}
      <div className="flex items-center justify-between pb-4 border-b border-[#E3CAAB]">
        <div className="flex items-center gap-3">
          <Link
            to="/admin/products"
            className="p-2 text-[#473C38] hover:bg-[#F7F3EE] rounded-none border border-[#E3CAAB] transition-colors"
            title="Back to products list"
          >
            <ArrowLeft className="w-4 h-4" />
          </Link>
          <div>
            <span className="text-[10px] tracking-[0.2em] uppercase font-bold text-[#B08A62]">
              {isEditing ? 'EDIT EXISTING PRODUCT' : 'NEW PRODUCT CREATION'}
            </span>
            <h1 className="text-2xl font-serif font-medium text-[#292522]">
              {isEditing ? `Edit: ${name || 'Product'}` : 'Add New Furniture Piece'}
            </h1>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <Link
            to="/admin/products"
            className="px-4 py-2 border border-[#473C38] text-[#473C38] hover:bg-[#F7F3EE] text-xs font-semibold tracking-wider transition-colors"
          >
            CANCEL
          </Link>
          <button
            type="button"
            onClick={() => handleSave(false)}
            className="px-5 py-2 bg-[#473C38] text-white hover:bg-[#B08A62] text-xs font-semibold tracking-wider transition-colors shadow-xs cursor-pointer"
          >
            {isEditing ? 'UPDATE PRODUCT' : 'SAVE PRODUCT'}
          </button>
        </div>
      </div>

      {/* Notifications */}
      {error && (
        <div className="p-4 bg-red-50 border border-red-200 text-red-800 text-xs flex items-center gap-2.5 animate-fade-in shadow-xs">
          <AlertCircle className="w-5 h-5 shrink-0 text-red-600" />
          <span>{error}</span>
        </div>
      )}

      {successMessage && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2.5 animate-fade-in shadow-xs">
          <CheckCircle2 className="w-5 h-5 shrink-0 text-emerald-600" />
          <span>{successMessage}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column (8 cols): Primary Details & MULTIPLE PRODUCT IMAGES */}
        <div className="lg:col-span-8 space-y-6">
          
          {/* Card 1: Basic Information */}
          <div className="bg-white p-6 border border-[#E3CAAB] shadow-xs space-y-4">
            <h2 className="font-serif text-base font-semibold text-[#292522] pb-2 border-b border-[#E3CAAB]/40">
              Basic Product Information
            </h2>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                Product Name *
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. The Sagwan Teakwood 3-Seater Living Room Sofa"
                className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                  Product Category *
                </label>
                <select
                  value={categoryId}
                  onChange={(e) => handleCategoryChange(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
                >
                  {categories.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                  SKU (Item Code) *
                </label>
                <input
                  type="text"
                  required
                  value={sku}
                  onChange={(e) => setSku(e.target.value)}
                  placeholder="e.g. AF-SOF-301"
                  className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs font-mono text-[#292522] focus:outline-none focus:border-[#473C38]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                Short Description (Card summary)
              </label>
              <input
                type="text"
                value={shortDescription}
                onChange={(e) => setShortDescription(e.target.value)}
                placeholder="e.g. Sculptural curved 3-seater sofa with warm oatmeal bouclé upholstery"
                className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                Full Description / Craftsmanship Notes
              </label>
              <textarea
                rows={4}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Detailed description of timber seasoning, internal framing, cushion firmness, joinery methods, and care guidelines..."
                className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
              />
            </div>
          </div>

          {/* ========================================================= */}
          {/* SECTION: PRODUCT IMAGES (Multiple Image Upload & Gallery) */}
          {/* ========================================================= */}
          <div className="bg-white p-6 border border-[#E3CAAB] shadow-xs space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-[#E3CAAB]/40 gap-2">
              <div>
                <h2 className="font-serif text-lg font-semibold text-[#292522] flex items-center gap-2">
                  <ImageIcon className="w-5 h-5 text-[#B08A62]" />
                  <span>PRODUCT IMAGES</span>
                </h2>
                <p className="text-xs text-[#473C38]/70 mt-0.5">
                  Select multiple images at once (JPG, JPEG, PNG, WEBP). Image #1 is automatically the Main Showcase Image.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold bg-[#F7F3EE] px-2.5 py-1 border border-[#E3CAAB] text-[#473C38] tabular-nums">
                  {images.length} {images.length === 1 ? 'Image' : 'Images'} Selected
                </span>
              </div>
            </div>

            {/* ADD IMAGES Dropzone & Actions */}
            <div
              onDragOver={(e) => {
                e.preventDefault();
                setIsDraggingOverDropzone(true);
              }}
              onDragLeave={() => setIsDraggingOverDropzone(false)}
              onDrop={handleDropFiles}
              className={`border-2 border-dashed p-6 sm:p-8 text-center transition-all ${
                isDraggingOverDropzone
                  ? 'border-[#B08A62] bg-[#E3CAAB]/20 scale-[0.99]'
                  : 'border-[#E3CAAB] bg-[#F7F3EE]/40 hover:bg-[#F7F3EE]/70 hover:border-[#B08A62]'
              }`}
            >
              <div className="max-w-md mx-auto space-y-3">
                <div className="w-12 h-12 mx-auto bg-white border border-[#E3CAAB] flex items-center justify-center text-[#B08A62] shadow-xs">
                  <Upload className="w-6 h-6 stroke-[1.8]" />
                </div>

                <div>
                  <label className="inline-flex items-center gap-2 px-5 py-2.5 bg-[#473C38] text-white hover:bg-[#B08A62] text-xs font-semibold tracking-wider uppercase cursor-pointer transition-colors shadow-xs">
                    <Plus className="w-4 h-4" />
                    <span>ADD IMAGES</span>
                    <input
                      type="file"
                      multiple
                      accept="image/jpeg,image/jpg,image/png,image/webp"
                      onChange={handleMultipleFilesUpload}
                      className="hidden"
                    />
                  </label>
                  <p className="text-xs text-[#473C38]/80 mt-2 font-medium">
                    or drag & drop images here from your computer or phone
                  </p>
                  <p className="text-[11px] text-[#473C38]/60 mt-0.5">
                    Supports <strong>JPG, JPEG, PNG, WEBP</strong>. No single-image limit.
                  </p>
                </div>

                {/* Secondary options: URL or Sample Photos */}
                <div className="pt-2 flex items-center justify-center gap-3 text-xs">
                  <button
                    type="button"
                    onClick={() => setShowUrlInput(!showUrlInput)}
                    className="text-[#B08A62] hover:text-[#473C38] font-semibold flex items-center gap-1 cursor-pointer"
                  >
                    <LinkIcon className="w-3.5 h-3.5" />
                    <span>{showUrlInput ? 'Hide URL Input' : 'Add via Image URL'}</span>
                  </button>

                  <span className="text-[#E3CAAB]">·</span>

                  <span className="text-[#473C38]/70">
                    Auto-optimizes resolution for fast customer loading
                  </span>
                </div>

                {/* Collapsible Image URL input */}
                {showUrlInput && (
                  <div className="pt-2 flex gap-2 max-w-sm mx-auto animate-fade-in">
                    <input
                      type="url"
                      value={imageUrlInput}
                      onChange={(e) => setImageUrlInput(e.target.value)}
                      placeholder="Paste direct https:// image URL..."
                      className="flex-1 px-3 py-1.5 bg-white border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
                    />
                    <button
                      type="button"
                      onClick={handleAddImageUrl}
                      className="px-3 py-1.5 bg-[#473C38] text-white text-xs font-semibold hover:bg-[#B08A62] cursor-pointer"
                    >
                      Add
                    </button>
                  </div>
                )}
              </div>
            </div>

            {uploadLoading && (
              <div className="p-3 bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-center gap-2 animate-pulse">
                <Sparkles className="w-4 h-4 text-amber-600 animate-spin" />
                <span>Processing and optimizing images... Please wait.</span>
              </div>
            )}

            {/* Quick Sample Selector for rapid catalog populating */}
            {images.length === 0 && (
              <div className="bg-[#F7F3EE]/50 p-4 border border-[#E3CAAB]/60 space-y-2">
                <span className="text-[11px] font-semibold uppercase tracking-wider text-[#473C38]">
                  Quick Showroom Samples (Click to add):
                </span>
                <div className="flex flex-wrap gap-2">
                  {[
                    { label: 'Living Room Sofa', url: IMAGES.sofa },
                    { label: 'Teak Dining Set', url: IMAGES.dining },
                    { label: 'Leather Lounge Chair', url: IMAGES.lounge },
                    { label: 'Centre Table', url: IMAGES.centreTable },
                    { label: 'Wooden Swing', url: IMAGES.woodenSwing },
                    { label: 'Study Table', url: IMAGES.studyTable },
                    { label: 'Accent Chairs', url: IMAGES.accentChairs },
                  ].map((sample) => (
                    <button
                      key={sample.label}
                      type="button"
                      onClick={() => handleAddSamplePhoto(sample.url)}
                      className="px-2.5 py-1 bg-white border border-[#E3CAAB] hover:border-[#B08A62] hover:bg-[#F7F3EE] text-[11px] text-[#473C38] font-medium transition-colors cursor-pointer flex items-center gap-1"
                    >
                      <Plus className="w-3 h-3 text-[#B08A62]" />
                      <span>{sample.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* IMAGE PREVIEW & REORDER GRID */}
            {images.length > 0 && (
              <div className="space-y-3 pt-1">
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-[#473C38] uppercase tracking-wider">
                      Selected Product Images ({images.length})
                    </span>
                    <span className="text-[11px] text-[#473C38]/60">
                      • Drag & drop cards or use arrows to reorder
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      if (window.confirm('Remove all selected product images?')) {
                        setImages([]);
                      }
                    }}
                    className="text-[11px] text-red-600 hover:underline cursor-pointer"
                  >
                    Clear All Images
                  </button>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                  {images.map((imgUrl, index) => {
                    const isMain = index === 0;
                    const isDraggingThis = draggedIndex === index;

                    return (
                      <div
                        key={`${imgUrl}-${index}`}
                        draggable
                        onDragStart={() => handleDragStart(index)}
                        onDragOver={handleDragOver}
                        onDrop={() => handleDropReorder(index)}
                        className={`relative bg-white border transition-all duration-200 group flex flex-col justify-between overflow-hidden ${
                          isMain
                            ? 'border-2 border-[#B08A62] shadow-md ring-2 ring-[#B08A62]/20'
                            : 'border-[#E3CAAB] hover:border-[#473C38] shadow-xs'
                        } ${isDraggingThis ? 'opacity-40 scale-95 border-dashed border-[#B08A62]' : 'opacity-100'}`}
                      >
                        {/* Drag Handle & Index Header */}
                        <div className="bg-[#F7F3EE] px-2 py-1 border-b border-[#E3CAAB]/60 flex items-center justify-between text-[10px] text-[#473C38]">
                          <div
                            className="flex items-center gap-1 cursor-grab active:cursor-grabbing font-medium"
                            title="Drag to reorder"
                          >
                            <GripVertical className="w-3.5 h-3.5 text-[#B08A62]" />
                            <span className="font-mono font-bold">Image {index + 1}</span>
                          </div>

                          <span className={`text-[9px] font-semibold px-1 py-0.2 uppercase ${
                            isMain ? 'text-[#B08A62]' : 'text-[#473C38]/70'
                          }`}>
                            {isMain ? 'Main Image' : 'Gallery'}
                          </span>
                        </div>

                        {/* Aspect Square Image Preview */}
                        <div className="relative aspect-square bg-[#F7F3EE] overflow-hidden cursor-grab active:cursor-grabbing">
                          <img
                            src={imgUrl}
                            alt={`Product preview ${index + 1}`}
                            className="w-full h-full object-cover"
                          />

                          {/* Delete X Button */}
                          <button
                            type="button"
                            onClick={() => handleRemoveImage(index)}
                            className="absolute top-2 right-2 p-1.5 bg-red-600/90 hover:bg-red-700 text-white rounded-none shadow-xs transition-transform active:scale-90 cursor-pointer"
                            title="Delete this image"
                            aria-label={`Delete image ${index + 1}`}
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>

                          {/* Reorder Arrows on hover */}
                          <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/75 via-black/40 to-transparent p-1.5 opacity-90 sm:opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-between">
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleMoveLeft(index);
                              }}
                              disabled={index === 0}
                              className="p-1 bg-white/90 hover:bg-white text-[#473C38] disabled:opacity-30 cursor-pointer disabled:cursor-not-allowed shadow-xs"
                              title="Move Left"
                            >
                              <ChevronLeft className="w-3.5 h-3.5" />
                            </button>

                            <span className="text-[10px] font-bold text-white uppercase tracking-wider">
                              {isMain ? '★ Main' : `#${index + 1}`}
                            </span>

                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleMoveRight(index);
                              }}
                              disabled={index === images.length - 1}
                              className="p-1 bg-white/90 hover:bg-white text-[#473C38] disabled:opacity-30 cursor-pointer disabled:cursor-not-allowed shadow-xs"
                              title="Move Right"
                            >
                              <ChevronRight className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                        {/* Card Footer: Set As Main OR Main Badge */}
                        <div className="p-2 bg-white border-t border-[#E3CAAB]/40 text-center">
                          {isMain ? (
                            <div className="py-1 px-2 bg-[#B08A62] text-white text-[10px] font-bold uppercase tracking-wider flex items-center justify-center gap-1 shadow-xs">
                              <Star className="w-3 h-3 fill-white" />
                              <span>MAIN IMAGE</span>
                            </div>
                          ) : (
                            <button
                              type="button"
                              onClick={() => handleSetAsMain(index)}
                              className="w-full py-1 px-2 border border-[#473C38] text-[#473C38] hover:bg-[#473C38] hover:text-white text-[10px] font-semibold uppercase tracking-wider transition-colors cursor-pointer flex items-center justify-center gap-1"
                              title="Set as the main showcase image"
                            >
                              <Star className="w-3 h-3 text-[#B08A62]" />
                              <span>SET AS MAIN</span>
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Helpful Instruction Tip */}
                <div className="bg-[#F7F3EE] p-3 border border-[#E3CAAB]/70 flex items-start gap-2 text-[11px] text-[#473C38]">
                  <Info className="w-4 h-4 text-[#B08A62] shrink-0 mt-0.5" />
                  <div>
                    <strong>Main Product Image:</strong> Image #1 is the primary image shown on the Homepage, Shop Catalog, Categories, and Search results.
                    Images #2 and onwards automatically form the interactive gallery strip on the Product Detail page.
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Card 2: Materials, Dimensions & Specifications */}
          <div className="bg-white p-6 border border-[#E3CAAB] shadow-xs space-y-4">
            <h2 className="font-serif text-base font-semibold text-[#292522] pb-2 border-b border-[#E3CAAB]/40">
              Dimensions & Material Specifications
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                  Dimensions (L x W x H) *
                </label>
                <input
                  type="text"
                  required
                  value={dimensions}
                  onChange={(e) => setDimensions(e.target.value)}
                  placeholder='e.g. 88"W x 38"D x 31"H'
                  className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                  Weight (approx)
                </label>
                <input
                  type="text"
                  value={weight}
                  onChange={(e) => setWeight(e.target.value)}
                  placeholder="e.g. 55 kg"
                  className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                Material Construction *
              </label>
              <input
                type="text"
                required
                value={material}
                onChange={(e) => setMaterial(e.target.value)}
                placeholder="e.g. Solid Sagwan (Teak) Frame, 40-Density Foam, Linen-Cotton Weave"
                className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
              />
            </div>

            {/* Colors / Finishes tags */}
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                Available Colors / Finishes
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={colorInput}
                  onChange={(e) => setColorInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleAddColor();
                    }
                  }}
                  placeholder="e.g. Warm Oatmeal, Dark Walnut, Teak Matte"
                  className="flex-1 px-3 py-2 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
                />
                <button
                  type="button"
                  onClick={handleAddColor}
                  className="px-4 py-2 bg-[#473C38] text-white text-xs font-semibold hover:bg-[#B08A62] cursor-pointer"
                >
                  Add Option
                </button>
              </div>

              {colors.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-2">
                  {colors.map((c, idx) => (
                    <span
                      key={idx}
                      className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-[#F7F3EE] border border-[#E3CAAB] text-xs text-[#473C38]"
                    >
                      <span>{c}</span>
                      <button
                        type="button"
                        onClick={() => handleRemoveColor(idx)}
                        className="text-[#473C38]/60 hover:text-red-600 cursor-pointer"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </span>
                  ))}
                </div>
              )}
            </div>
          </div>

        </div>

        {/* Right Column (4 cols): Pricing, Stock, Visibility */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* Card: Pricing */}
          <div className="bg-white p-6 border border-[#E3CAAB] shadow-xs space-y-4">
            <h2 className="font-serif text-base font-semibold text-[#292522] pb-2 border-b border-[#E3CAAB]/40">
              Pricing (INR ₹)
            </h2>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                Selling Price (₹) *
              </label>
              <input
                type="number"
                required
                min="0"
                value={price}
                onChange={(e) => setPrice(e.target.value === '' ? '' : Number(e.target.value))}
                placeholder="e.g. 48500"
                className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] font-serif text-base font-semibold text-[#292522] focus:outline-none focus:border-[#473C38]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                Discount / Original MRP (₹)
              </label>
              <input
                type="number"
                min="0"
                value={discountPrice}
                onChange={(e) => setDiscountPrice(e.target.value === '' ? '' : Number(e.target.value))}
                placeholder="e.g. 58000 (shown crossed out)"
                className="w-full px-3.5 py-2 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522]"
              />
              <p className="text-[10px] text-[#473C38]/60 mt-1">
                If provided, will show as discounted price to customers.
              </p>
            </div>
          </div>

          {/* Card: Inventory & Availability */}
          <div className="bg-white p-6 border border-[#E3CAAB] shadow-xs space-y-4">
            <h2 className="font-serif text-base font-semibold text-[#292522] pb-2 border-b border-[#E3CAAB]/40">
              Inventory & Availability
            </h2>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                Availability Status
              </label>
              <select
                value={availability}
                onChange={(e) => setAvailability(e.target.value as AvailabilityStatus)}
                className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522]"
              >
                <option value="In Stock">In Stock (Immediate Ahmedabad Delivery)</option>
                <option value="Made to Order">Made to Order (Crafted in Danilimda)</option>
                <option value="Out of Stock">Out of Stock</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#473C38] mb-1">
                Stock Quantity (Units)
              </label>
              <input
                type="number"
                value={stock}
                onChange={(e) => setStock(Number(e.target.value))}
                className="w-full px-3.5 py-2.5 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
              />
            </div>
          </div>

          {/* Card: Storefront Toggles */}
          <div className="bg-white p-6 border border-[#E3CAAB] shadow-xs space-y-4">
            <h2 className="font-serif text-base font-semibold text-[#292522] pb-2 border-b border-[#E3CAAB]/40">
              Storefront Toggles
            </h2>

            {/* Status Live/Hidden */}
            <div className="flex items-center justify-between py-2 border-b border-[#E3CAAB]/30">
              <div>
                <p className="text-xs font-semibold text-[#292522]">Live on Website</p>
                <p className="text-[10px] text-[#473C38]/60">
                  {status === 'active' ? 'Visible to public customers' : 'Hidden from public storefront'}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setStatus(status === 'active' ? 'inactive' : 'active')}
                className={`w-12 h-6 flex items-center rounded-full p-1 cursor-pointer transition-colors duration-200 ${
                  status === 'active' ? 'bg-[#473C38]' : 'bg-neutral-300'
                }`}
              >
                <div
                  className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform duration-200 ${
                    status === 'active' ? 'translate-x-6' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Featured / Bestseller */}
            <div className="flex items-center justify-between py-2 border-b border-[#E3CAAB]/30">
              <div>
                <p className="text-xs font-semibold text-[#292522]">Featured / Bestseller</p>
                <p className="text-[10px] text-[#473C38]/60">
                  Appears in "Featured Bestsellers" section
                </p>
              </div>
              <button
                type="button"
                onClick={() => setFeatured(!featured)}
                className={`w-12 h-6 flex items-center rounded-full p-1 cursor-pointer transition-colors duration-200 ${
                  featured ? 'bg-[#B08A62]' : 'bg-neutral-300'
                }`}
              >
                <div
                  className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform duration-200 ${
                    featured ? 'translate-x-6' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Customizable */}
            <div className="flex items-center justify-between py-2">
              <div>
                <p className="text-xs font-semibold text-[#292522]">Customizable Dimensions</p>
                <p className="text-[10px] text-[#473C38]/60">
                  Show "Custom sizing available" badge
                </p>
              </div>
              <button
                type="button"
                onClick={() => setCustomizable(!customizable)}
                className={`w-12 h-6 flex items-center rounded-full p-1 cursor-pointer transition-colors duration-200 ${
                  customizable ? 'bg-[#473C38]' : 'bg-neutral-300'
                }`}
              >
                <div
                  className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform duration-200 ${
                    customizable ? 'translate-x-6' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="bg-white p-6 border border-[#E3CAAB] shadow-xs space-y-3">
            <button
              type="button"
              onClick={() => handleSave(false)}
              className="w-full py-3 bg-[#473C38] text-white hover:bg-[#B08A62] text-xs font-semibold tracking-wider transition-colors shadow-xs cursor-pointer text-center block"
            >
              {isEditing ? 'UPDATE PRODUCT' : 'SAVE PRODUCT'}
            </button>

            {!isEditing && (
              <button
                type="button"
                onClick={() => handleSave(true)}
                className="w-full py-2.5 bg-[#F7F3EE] hover:bg-[#E3CAAB]/40 text-[#473C38] text-xs font-semibold tracking-wider border border-[#E3CAAB] transition-colors cursor-pointer text-center block"
              >
                SAVE & ADD ANOTHER
              </button>
            )}

            <Link
              to="/admin/products"
              className="w-full py-2 text-center text-xs text-[#473C38]/70 hover:text-red-600 block transition-colors"
            >
              Cancel & Discard Changes
            </Link>
          </div>

        </div>

      </div>

    </div>
  );
}
