import React, { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import {
  PlusCircle,
  Search,
  Filter,
  Trash2,
  Edit,
  Eye,
  Star,
  CheckCircle,
  XCircle,
  AlertTriangle,
  ArrowUpDown,
  CheckSquare,
  Square
} from 'lucide-react';
import { useData } from '../../context/DataContext';
import { Product } from '../../types/furniture';

type FilterType = 'all' | 'active' | 'inactive' | 'featured' | 'out_of_stock';

export default function AdminProducts() {
  const {
    products,
    deleteProduct,
    deleteProductsBulk,
    updateProduct,
    setProductsStatusBulk,
    setProductsFeaturedBulk,
    categories,
  } = useData();

  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<FilterType>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  
  // Single delete modal
  const [productToDelete, setProductToDelete] = useState<Product | null>(null);
  // Bulk delete modal
  const [showBulkDeleteModal, setShowBulkDeleteModal] = useState(false);

  // Filtered & Searched products
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      const matchesSearch =
        searchQuery === '' ||
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.sku.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (p.categoryLabel && p.categoryLabel.toLowerCase().includes(searchQuery.toLowerCase())) ||
        p.categoryId.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesCat = selectedCategory === 'all' || p.categoryId === selectedCategory;

      let matchesFilter = true;
      if (filterType === 'active') matchesFilter = p.status === 'active';
      if (filterType === 'inactive') matchesFilter = p.status === 'inactive';
      if (filterType === 'featured') matchesFilter = p.featured === true;
      if (filterType === 'out_of_stock') matchesFilter = p.availability === 'Out of Stock' || p.stock === 0;

      return matchesSearch && matchesCat && matchesFilter;
    });
  }, [products, searchQuery, selectedCategory, filterType]);

  // Selection handlers
  const handleSelectAll = () => {
    if (selectedIds.length === filteredProducts.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(filteredProducts.map((p) => p.id));
    }
  };

  const handleToggleSelect = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  // Quick Inline Status Toggles
  const handleToggleStatus = (p: Product) => {
    const nextStatus = p.status === 'active' ? 'inactive' : 'active';
    updateProduct(p.id, { status: nextStatus });
  };

  const handleToggleFeatured = (p: Product) => {
    updateProduct(p.id, { featured: !p.featured });
  };

  // Single Delete Confirmation
  const confirmDeleteSingle = () => {
    if (productToDelete) {
      deleteProduct(productToDelete.id);
      setSelectedIds((prev) => prev.filter((i) => i !== productToDelete.id));
      setProductToDelete(null);
    }
  };

  // Bulk Delete Confirmation
  const confirmDeleteBulk = () => {
    deleteProductsBulk(selectedIds);
    setSelectedIds([]);
    setShowBulkDeleteModal(false);
  };

  // Bulk Status/Featured
  const handleBulkActivate = () => {
    setProductsStatusBulk(selectedIds, 'active');
  };

  const handleBulkDeactivate = () => {
    setProductsStatusBulk(selectedIds, 'inactive');
  };

  const handleBulkMarkFeatured = () => {
    setProductsFeaturedBulk(selectedIds, true);
  };

  const handleBulkRemoveFeatured = () => {
    setProductsFeaturedBulk(selectedIds, false);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      
      {/* Header Bar */}
      <div className="bg-white p-6 border border-[#E3CAAB] shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] tracking-[0.2em] uppercase font-bold text-[#B08A62]">
            INVENTORY MANAGEMENT
          </span>
          <h1 className="text-2xl font-serif font-medium text-[#292522] mt-0.5">
            Products Catalog ({products.length})
          </h1>
          <p className="text-xs text-[#473C38]/70 mt-1">
            Manage your furniture pieces, stock availability, pricing, and live showroom status.
          </p>
        </div>

        <Link
          to="/admin/products/new"
          className="px-5 py-3 bg-[#473C38] text-white hover:bg-[#B08A62] text-xs font-semibold tracking-wider flex items-center justify-center gap-2 transition-colors shadow-xs shrink-0"
        >
          <PlusCircle className="w-4 h-4" />
          <span>ADD NEW PRODUCT</span>
        </Link>
      </div>

      {/* Search & Filter Bar */}
      <div className="bg-white p-5 border border-[#E3CAAB] shadow-xs space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3 items-center">
          {/* Search Input */}
          <div className="md:col-span-6 relative">
            <Search className="w-4 h-4 text-[#473C38]/50 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by product name, SKU, or category..."
              className="w-full pl-10 pr-4 py-2 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38]"
            />
          </div>

          {/* Category Dropdown */}
          <div className="md:col-span-3">
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full px-3 py-2 bg-[#F7F3EE]/50 border border-[#E3CAAB] text-xs text-[#292522] focus:outline-none focus:border-[#473C38] cursor-pointer"
            >
              <option value="all">All Categories</option>
              {categories.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          {/* Result Count Info */}
          <div className="md:col-span-3 text-right text-xs text-[#473C38]/70">
            Showing <strong className="text-[#292522] tabular-nums">{filteredProducts.length}</strong> of{' '}
            <strong className="text-[#292522] tabular-nums">{products.length}</strong> products
          </div>
        </div>

        {/* Filter Pills */}
        <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-[#E3CAAB]/40">
          {(
            [
              { id: 'all', label: 'All Products' },
              { id: 'active', label: 'Active (Live)' },
              { id: 'inactive', label: 'Inactive (Hidden)' },
              { id: 'featured', label: 'Featured (Bestsellers)' },
              { id: 'out_of_stock', label: 'Out of Stock' },
            ] as const
          ).map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilterType(tab.id)}
              className={`px-3 py-1.5 text-xs font-medium transition-colors cursor-pointer ${
                filterType === tab.id
                  ? 'bg-[#473C38] text-white shadow-xs'
                  : 'bg-[#F7F3EE] text-[#473C38] hover:bg-[#E3CAAB]/40 border border-[#E3CAAB]/60'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Bulk Actions Bar (if any selected) */}
      {selectedIds.length > 0 && (
        <div className="bg-[#473C38] text-white p-3.5 flex flex-wrap items-center justify-between gap-3 shadow-md border border-[#B08A62] animate-fade-in">
          <div className="flex items-center gap-2 text-xs">
            <span className="font-semibold text-[#E3CAAB]">{selectedIds.length}</span>
            <span>products selected</span>
          </div>

          <div className="flex flex-wrap items-center gap-2 text-xs">
            <button
              onClick={handleBulkActivate}
              className="px-3 py-1 bg-white/10 hover:bg-white/20 text-white rounded-none transition-colors"
            >
              Activate
            </button>
            <button
              onClick={handleBulkDeactivate}
              className="px-3 py-1 bg-white/10 hover:bg-white/20 text-white rounded-none transition-colors"
            >
              Deactivate
            </button>
            <button
              onClick={handleBulkMarkFeatured}
              className="px-3 py-1 bg-white/10 hover:bg-white/20 text-white rounded-none transition-colors"
            >
              Mark Featured
            </button>
            <button
              onClick={handleBulkRemoveFeatured}
              className="px-3 py-1 bg-white/10 hover:bg-white/20 text-white rounded-none transition-colors"
            >
              Remove Featured
            </button>
            <button
              onClick={() => setShowBulkDeleteModal(true)}
              className="px-3 py-1 bg-red-700 hover:bg-red-800 text-white rounded-none transition-colors"
            >
              Delete Selected
            </button>
          </div>
        </div>
      )}

      {/* Products Table */}
      <div className="bg-white border border-[#E3CAAB] shadow-xs overflow-hidden">
        {filteredProducts.length === 0 ? (
          <div className="py-16 text-center">
            <p className="font-serif text-lg text-[#473C38]">No products found</p>
            <p className="text-xs text-[#473C38]/60 mt-1">
              Try adjusting your search criteria or add a new furniture product.
            </p>
            <Link
              to="/admin/products/new"
              className="mt-4 inline-flex items-center gap-2 px-4 py-2 bg-[#473C38] text-white text-xs font-semibold tracking-wider hover:bg-[#B08A62] transition-colors"
            >
              <PlusCircle className="w-4 h-4" />
              <span>ADD PRODUCT</span>
            </Link>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#F7F3EE] text-[#473C38] border-b border-[#E3CAAB] uppercase text-[10px] tracking-wider font-semibold">
                <tr>
                  <th className="p-3 w-10 text-center">
                    <button
                      onClick={handleSelectAll}
                      className="text-[#473C38] hover:text-[#B08A62] cursor-pointer"
                      title={selectedIds.length === filteredProducts.length ? 'Deselect all' : 'Select all'}
                    >
                      {selectedIds.length === filteredProducts.length ? (
                        <CheckSquare className="w-4 h-4 text-[#B08A62]" />
                      ) : (
                        <Square className="w-4 h-4" />
                      )}
                    </button>
                  </th>
                  <th className="p-3">Product</th>
                  <th className="p-3">Category</th>
                  <th className="p-3">Price</th>
                  <th className="p-3">Stock / Availability</th>
                  <th className="p-3 text-center">Featured</th>
                  <th className="p-3 text-center">Status</th>
                  <th className="p-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E3CAAB]/40">
                {filteredProducts.map((p) => {
                  const isSelected = selectedIds.includes(p.id);
                  const cat = categories.find((c) => c.id === p.categoryId);

                  return (
                    <tr
                      key={p.id}
                      className={`hover:bg-[#F7F3EE]/50 transition-colors ${
                        isSelected ? 'bg-[#E3CAAB]/20' : ''
                      }`}
                    >
                      {/* Checkbox */}
                      <td className="p-3 text-center">
                        <button
                          onClick={() => handleToggleSelect(p.id)}
                          className="cursor-pointer text-[#473C38]"
                        >
                          {isSelected ? (
                            <CheckSquare className="w-4 h-4 text-[#B08A62]" />
                          ) : (
                            <Square className="w-4 h-4 text-[#473C38]/40" />
                          )}
                        </button>
                      </td>

                      {/* Product Thumbnail & Details */}
                      <td className="p-3">
                        <div className="flex items-center gap-3">
                          <div className="relative shrink-0">
                            <img
                              src={(p.images && p.images[0]) || p.image}
                              alt={p.name}
                              className="w-12 h-12 object-cover bg-[#F7F3EE] border border-[#E3CAAB]/70"
                            />
                            {p.images && p.images.length > 1 && (
                              <span
                                className="absolute -bottom-1 -right-1 bg-[#473C38] text-white text-[9px] font-mono px-1 py-0.2 shadow-xs"
                                title={`${p.images.length} photos in gallery`}
                              >
                                {p.images.length}
                              </span>
                            )}
                          </div>
                          <div className="min-w-0">
                            <p className="font-semibold text-[#292522] truncate max-w-xs sm:max-w-sm">
                              {p.name}
                            </p>
                            <div className="text-[10px] text-[#473C38]/60 flex items-center gap-2 mt-0.5">
                              <span>SKU: {p.sku}</span>
                              <span aria-hidden="true">·</span>
                              <span>{p.images?.length || 1} {(p.images?.length || 1) === 1 ? 'photo' : 'photos'}</span>
                              <span aria-hidden="true">·</span>
                              <span>Added {new Date(p.createdAt).toLocaleDateString()}</span>
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* Category */}
                      <td className="p-3 text-[#473C38]">
                        <span className="font-medium">{cat?.name || p.categoryLabel || p.categoryId}</span>
                      </td>

                      {/* Price */}
                      <td className="p-3">
                        <div className="font-serif font-bold text-sm text-[#292522] tabular-nums">
                          ₹{p.price.toLocaleString('en-IN')}
                        </div>
                        {p.discountPrice && p.discountPrice > p.price && (
                          <div className="text-[10px] text-[#473C38]/50 line-through tabular-nums">
                            ₹{p.discountPrice.toLocaleString('en-IN')}
                          </div>
                        )}
                      </td>

                      {/* Stock / Availability */}
                      <td className="p-3">
                        <span
                          className={`inline-block px-2 py-0.5 text-[10px] font-semibold tracking-wider ${
                            p.availability === 'Out of Stock' || p.stock === 0
                              ? 'bg-rose-50 text-rose-700 border border-rose-200'
                              : p.availability === 'Made to Order'
                              ? 'bg-amber-50 text-amber-800 border border-amber-200'
                              : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          }`}
                        >
                          {p.availability} ({p.stock} pcs)
                        </span>
                      </td>

                      {/* Featured Toggle */}
                      <td className="p-3 text-center">
                        <button
                          onClick={() => handleToggleFeatured(p)}
                          className="p-1 hover:scale-110 transition-transform cursor-pointer"
                          title={p.featured ? 'Featured on homepage (click to remove)' : 'Not featured (click to feature)'}
                        >
                          <Star
                            className={`w-4 h-4 ${
                              p.featured
                                ? 'text-amber-500 fill-amber-500'
                                : 'text-neutral-300 hover:text-amber-400'
                            }`}
                          />
                        </button>
                      </td>

                      {/* Active/Inactive Toggle */}
                      <td className="p-3 text-center">
                        <button
                          onClick={() => handleToggleStatus(p)}
                          className={`px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider cursor-pointer transition-colors ${
                            p.status === 'active'
                              ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'
                              : 'bg-neutral-200 text-neutral-700 hover:bg-neutral-300'
                          }`}
                          title={`Click to ${p.status === 'active' ? 'hide from' : 'show on'} website`}
                        >
                          {p.status}
                        </button>
                      </td>

                      {/* Actions */}
                      <td className="p-3 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <Link
                            to={`/admin/products/edit/${p.id}`}
                            className="p-1.5 text-[#473C38] hover:text-[#B08A62] hover:bg-[#F7F3EE] transition-colors"
                            title="Edit product"
                          >
                            <Edit className="w-4 h-4" />
                          </Link>
                          <button
                            onClick={() => setProductToDelete(p)}
                            className="p-1.5 text-[#473C38]/60 hover:text-red-600 hover:bg-red-50 transition-colors cursor-pointer"
                            title="Delete product"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Delete Confirmation Modal (Single) */}
      {productToDelete && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white p-6 max-w-md w-full border border-[#E3CAAB] shadow-2xl space-y-4">
            <div className="flex items-center gap-3 text-rose-600">
              <AlertTriangle className="w-6 h-6 shrink-0" />
              <h3 className="font-serif text-lg font-bold text-[#292522]">
                Confirm Delete Product
              </h3>
            </div>
            <p className="text-xs text-[#473C38]/85 leading-relaxed">
              Are you sure you want to delete <strong>"{productToDelete.name}"</strong>?
              This will remove it from the catalog and the public storefront immediately.
            </p>
            <div className="pt-2 flex items-center justify-end gap-3">
              <button
                onClick={() => setProductToDelete(null)}
                className="px-4 py-2 border border-[#E3CAAB] text-xs font-semibold text-[#473C38] hover:bg-[#F7F3EE] cursor-pointer"
              >
                CANCEL
              </button>
              <button
                onClick={confirmDeleteSingle}
                className="px-4 py-2 bg-rose-700 text-white text-xs font-semibold hover:bg-rose-800 cursor-pointer shadow-sm"
              >
                DELETE PRODUCT
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Bulk Delete Confirmation Modal */}
      {showBulkDeleteModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white p-6 max-w-md w-full border border-[#E3CAAB] shadow-2xl space-y-4">
            <div className="flex items-center gap-3 text-rose-600">
              <AlertTriangle className="w-6 h-6 shrink-0" />
              <h3 className="font-serif text-lg font-bold text-[#292522]">
                Delete Multiple Products
              </h3>
            </div>
            <p className="text-xs text-[#473C38]/85 leading-relaxed">
              Are you sure you want to permanently delete all{' '}
              <strong>{selectedIds.length}</strong> selected products?
            </p>
            <div className="pt-2 flex items-center justify-end gap-3">
              <button
                onClick={() => setShowBulkDeleteModal(false)}
                className="px-4 py-2 border border-[#E3CAAB] text-xs font-semibold text-[#473C38] hover:bg-[#F7F3EE] cursor-pointer"
              >
                CANCEL
              </button>
              <button
                onClick={confirmDeleteBulk}
                className="px-4 py-2 bg-rose-700 text-white text-xs font-semibold hover:bg-rose-800 cursor-pointer shadow-sm"
              >
                DELETE {selectedIds.length} PRODUCTS
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
