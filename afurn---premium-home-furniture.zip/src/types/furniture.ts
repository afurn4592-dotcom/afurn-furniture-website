export type ProductStatus = 'active' | 'inactive';
export type AvailabilityStatus = 'In Stock' | 'Made to Order' | 'Out of Stock';

export interface Product {
  id: string;
  name: string;
  slug: string;
  categoryId: string;
  categoryLabel?: string;
  description: string;
  shortDescription?: string;
  price: number;
  discountPrice?: number;
  originalPrice?: number; // legacy alias
  sku: string;
  image: string; // main image
  images: string[]; // gallery images including main
  material: string;
  materials?: string; // legacy alias
  colors: string[];
  finishOptions?: string[]; // legacy alias
  dimensions: string;
  weight?: string;
  availability: AvailabilityStatus;
  stock: number;
  inStock?: boolean; // legacy alias
  featured: boolean;
  isBestSeller?: boolean;
  isNew?: boolean;
  customizable: boolean;
  status: ProductStatus;
  leadTimeDays?: number;
  features?: string[];
  createdAt: string;
  updatedAt: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description: string;
  image: string;
  displayOrder: number;
  status: 'active' | 'inactive';
  itemCount?: number;
  createdAt: string;
}

export type CategoryInfo = Category & {
  title?: string;
  subtitle?: string;
};

export type EnquiryStatus = 'NEW' | 'CONTACTED' | 'FOLLOW-UP' | 'COMPLETED';
export type EnquiryType = 'Contact Form' | 'Product Enquiry' | 'Get Quote' | 'Custom Furniture Request';

export interface Enquiry {
  id: string;
  customerName: string;
  phone: string;
  email: string;
  productName?: string;
  productId?: string;
  message: string;
  type: EnquiryType;
  date: string;
  status: EnquiryStatus;
  notes?: string;
}

export interface CustomOrder {
  id: string;
  customerName: string;
  phone: string;
  email?: string;
  furnitureType: string;
  size: string; // dimensions
  material: string;
  color: string;
  quantity: number;
  budgetRange?: string;
  city?: string;
  projectType?: string;
  referenceImage?: string;
  message: string;
  date: string;
  status: 'NEW' | 'CONTACTED' | 'IN_PRODUCTION' | 'COMPLETED';
  notes?: string;
}

export interface GalleryItem {
  id: string;
  title: string;
  category: string;
  image: string;
  details: string;
  displayOrder: number;
  status: 'active' | 'inactive';
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  location: string;
  quote: string;
  rating: number;
  project: string;
  customerImage?: string;
  status: 'active' | 'inactive';
  displayOrder: number;
}

export interface NavItem {
  id: string;
  label: string;
  href: string;
  order: number;
  isVisible: boolean;
  isCustom?: boolean;
}

export interface BannerItem {
  id: string;
  title: string;
  subtitle: string;
  image: string;
  buttonText: string;
  buttonLink: string;
  startDate?: string;
  endDate?: string;
  isActive: boolean;
  displayOrder: number;
}

export interface WhyChooseUsCard {
  id: string;
  icon: string;
  title: string;
  description: string;
  displayOrder: number;
  isVisible: boolean;
}

export interface HeroSettings {
  smallHeading: string;
  mainHeading: string;
  description: string;
  button1Text: string;
  button1Link: string;
  button2Text: string;
  button2Link: string;
  heroImage: string;
  mobileHeroImage?: string;
  textAlignment: 'left' | 'center' | 'right';
  imagePosition: 'right' | 'left';
  overlayStrength: number; // 0 - 100
  showButtons: boolean;
  trustStatement: string;
}

export interface AboutSettings {
  heading: string;
  subheading: string;
  description1: string;
  description2: string;
  experienceNumber: string;
  experienceLabel: string;
  customerNumber: string;
  customerLabel: string;
  productsNumber: string;
  productsLabel: string;
  image: string;
}

export interface WebsiteCustomization {
  logoType: 'text' | 'image';
  logoText: string;
  logoImage?: string;
  favicon?: string;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  backgroundColor: string;
  textColor: string;
  buttonColor: string;
  buttonTextColor: string;
  headingFont: string;
  bodyFont: string;
  headingSize: 'sm' | 'md' | 'lg' | 'xl';
  bodySize: 'sm' | 'md' | 'lg';
  borderRadius: 'none' | 'sm' | 'md' | 'lg';
  buttonStyle: 'sharp' | 'subtle' | 'rounded';
  cardStyle: 'minimal' | 'bordered' | 'elevated';
}

export interface SEOSettings {
  siteTitle: string;
  metaDescription: string;
  keywords: string;
  homeTitle: string;
  homeDescription: string;
  socialImage: string;
}

export interface WhatsAppConfig {
  number: string;
  defaultMessage: string;
  enableFloatingButton: boolean;
}

export interface FooterConfig {
  description: string;
  copyrightText: string;
  customLinks: { id: string; label: string; href: string }[];
  showSocial: boolean;
}

export interface MediaItem {
  id: string;
  name: string;
  url: string;
  type: string;
  size: string;
  createdAt: string;
}

export interface SectionVisibility {
  hero: boolean;
  categories: boolean;
  featuredProducts: boolean;
  aboutSection: boolean;
  whyChooseUs: boolean;
  customFurniture: boolean;
  b2bSection: boolean;
  gallery: boolean;
  testimonials: boolean;
  faqSection: boolean;
  contactSection: boolean;
  [key: string]: boolean;
}

export interface WebsiteSettings {
  businessName: string;
  tagline: string;
  experience: string;
  phone: string;
  displayPhone: string;
  whatsappNumber: string;
  whatsappUrl: string;
  email: string;
  address: string;
  city: string;
  state: string;
  country: string;
  pinCode: string;
  businessDescription: string;
  instagramUrl: string;
  facebookUrl: string;
  youtubeUrl?: string;
  googleMapsUrl?: string;
  workingHours: string;
  deliveryPromise: string;

  // Customization
  customization: WebsiteCustomization;

  // Section Ordering (Array of section ids)
  sectionOrder: string[];
  sections: SectionVisibility;

  // Hero Section
  hero: HeroSettings;

  // About Section
  about: AboutSettings;

  // Navigation Items
  navigation: NavItem[];

  // Banners
  banners: BannerItem[];

  // Why Choose Us Cards
  whyChooseUsCards: WhyChooseUsCard[];

  // WhatsApp Config
  whatsapp: WhatsAppConfig;

  // Footer Config
  footer: FooterConfig;

  // SEO
  seo: SEOSettings;

  // Legacy mappings for backwards-compat
  heroLabel?: string;
  heroHeading?: string;
  heroDescription?: string;
  heroButton1Text?: string;
  heroButton2Text?: string;
  heroTrustStatement?: string;
  aboutUsTitle?: string;
  aboutUsHeading?: string;
  aboutUsText1?: string;
  aboutUsText2?: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
  selectedFinish?: string;
  customNotes?: string;
}

export interface CustomFurnitureForm {
  furnitureType: string;
  roomType: string;
  dimensions: string;
  materialPreference: string;
  frameType: string;
  upholsteryType: string;
  budgetRange: string;
  customerName: string;
  customerPhone: string;
  customerEmail?: string;
  city: string;
  projectType: 'Homeowner' | 'Interior Designer' | 'Architect' | 'Commercial / Cafe / Hotel' | 'Other';
  notes: string;
  referenceImage?: string;
}
